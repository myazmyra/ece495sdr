/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file   inner_CtrlStruc.js
*
* @brief  Control structure tab engine
*
******************************************************************************/
/******************************************************************************
* List of functions
******************************************************************************
* initLoadFormCascade() - init Cascade page paramters and constants  
* clickUpdateCtrlStruc() - calculates control constants based on input parameters
* writeCascadeHTMLOutput(prefix,xmlObject) - write selected constants to output preview page 
* writeCascadeHeaderOutput(str) - write selected constants to output header file
*******************************************************************************/

/***************************************************************************//*!
* @brief   The function check XML field ti not empty and try to read FM variable
* @param    
* @return  
* @remarks 
*******************************************************************************/   
function checkXMLvar()
{
  var tempXMLVar;
  // names of XML field used in CtrlScructure
  var xmlElements = new Array ('ControlStructureMethod', 
                               'onoff',
                               'SCALAR_VHZ_FACTOR_GAIN',
                               'Freq_req',
                               'Ud_req',
                               'Uq_req',
                               'Id_req',
                               'Iq_req',
                               'Speed_req');

  var errorFMread = '';
  var errorXMLfield = '';
  
  var MotorPrefix = getActiveMotor();  
                             
  var xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");   
    
    // check defined XML fields 
   for(var j=0;j<xmlElements.length;j++){
    tempXMLVar = xmlDoc.getElementsByTagName(MotorPrefix+ xmlElements[j])[0];
  
   if(tempXMLVar.childNodes.length!=0)
   {
     if(!(pcm.ReadVariable(tempXMLVar.childNodes[0].nodeValue)))
        errorFMread = errorFMread + '\n "' + tempXMLVar.childNodes[0].nodeValue + '"';
   }     
   else // XML field empty
     errorXMLfield = errorXMLfield + '\n"' +MotorPrefix+ xmlElements[j] + '" ';
   } 

   if(errorXMLfield!='')
     alert('Error: Empty XML field: '+ errorXMLfield); 
     
   if(errorFMread!='')
     alert('Read error of FM variables: '+ errorFMread);  
   
   if((errorXMLfield!='')||(errorFMread!=''))
    return (false);
   else       
    return (true);    
}
/***************************************************************************//*!
*
* @brief   The function creates code of for output constant
* @param   
* @return  None
* @remarks 
******************************************************************************/ 
var Timer_object;

// init load
function initLoadFormCascade()
{
    if(!pcm.IsCommPortOpen())
    {
      alert("Communication is stopped. Press Ctrl+K to start the communication");
    }

    else
    {
      // basic mode, disable some inputs
      // in basic mode, precalculate paramters
      if(getActiveMode()==0)
      {
        var prefixM = getActiveMotor();
      
         disableInputParamBox(prefixM+'scalar_ctrl_Input1'); 
         disableInputParamBox(prefixM+'volt_ctrl_Input1');
         disableInputParamBox(prefixM+'current_ctrl_Input1');
      }         
      
      // check all XML variables and proper FM communication
      if(checkXMLvar())
      {  
        Frm2TwStateReload();
        Frm2TwValuesReload();
        timeUpdate();
      }
  
      sensorTypeSelectInit();
    } 
}   
/***************************************************************************//*!
*
* @brief   Periodically call function
* @param   
* @return  None
* @remarks 
******************************************************************************/ 

// refresh event every 250ms
function timeUpdate()
{
   Timer_object = setInterval(function(){updateButtons()}, 500);    
}

/***************************************************************************//*!
*
* @brief   Update Ctrl Structure button states
* @param   
* @return  None
* @remarks 
******************************************************************************/ 
// periodical updates of buttons/switches in Cascade Tab 
function updateButtons()
{
  Frm2TwStateReload();
  StateMachine();
}    

/***************************************************************************//*!
*
* @brief   Sensor type selector init routine - according to parent doc. table
* @param   
* @return  None
* @remarks 
******************************************************************************/     
/* -------------  --------------------------*/
function sensorTypeSelectInit(){
 var optionObject;
 var selectedSensor;
 var j = 0;
  
  
   var MotorPrefix = getActiveMotor();
   // read from main page table
   selectedSensor =  parent.document.getElementById([MotorPrefix]+'PospeFbck').innerHTML;
   // read object by ID from CtrlStructurePage
   optionObject = document.getElementById(MotorPrefix + "pospe_ctrl_Select");
 
   for(var i=0;i<5;i++)
   {
     if (((selectedSensor>>>[i])&1) != 1)    optionObject.remove(j);
     else                                    j++;
   }
}
 
/***************************************************************************//*!
* @brief   The function converts the Number to String form, according to selected control method
* @param   inPointer - number representating the selected ctrl method 
* @return  string of selected control method
* @remarks 
*******************************************************************************/   
function conversionNo2Ctrl(inPointer)
{
    var arithmeticArray=new Array(4);
    arithmeticArray[0] = "scalar_ctrl";
    arithmeticArray[1] = "volt_ctrl";
    arithmeticArray[2] = "current_ctrl";
    arithmeticArray[3] = "speed_ctrl";    

    return arithmeticArray[inPointer];     
} 

/***************************************************************************//*!
* @brief   The function converts the Number to String form, according to selected reference signals
* @param   inPointer - number representating the selected ctrl method 
* @return  string of selected reference signals
* @remarks 
*******************************************************************************/
function conversionXml2Variables(inPointer)
{
    var referencesArray=new Array(8);
    referencesArray[0] = "SCALAR_VHZ_FACTOR_GAIN";
    referencesArray[1] = "Freq_req";
    referencesArray[2] = "Ud_req";
    referencesArray[3] = "Uq_req";    
    referencesArray[4] = "Id_req";
    referencesArray[5] = "Iq_req";    
    referencesArray[6] = "Speed_req";
    
    return referencesArray[inPointer];     
}
/***************************************************************************//*!
*
* @brief   Reload of the switches/selectors states from FRM to TW
* @param   
* @return  None
* @remarks 
******************************************************************************/     
/* ---------------- Cascade control structure selector ------------------ */  
function Frm2TwStateReload(){
  var retMsg;
  var object = new Array(6); 
  
  var xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");   
  var prefixM = getActiveMotor();  
  var CtrlRegisterVal  = xmlDoc.getElementsByTagName([prefixM]+"ControlStructureMethod")[0];
  var PospeRegisterVal = xmlDoc.getElementsByTagName([prefixM]+"ControlStructurePoSpe")[0];
  var on_off           = xmlDoc.getElementsByTagName([prefixM]+"onoff")[0];

  object[1] = document.getElementById([prefixM]+'scalar_ctrl');
  object[2] = document.getElementById([prefixM]+'volt_ctrl');
  object[3] = document.getElementById([prefixM]+'current_ctrl');      
  object[4] = document.getElementById([prefixM]+'speed_ctrl');
  object[5] = document.getElementById([prefixM]+'pospe_ctrl'); 
  
  // switching off all switches EN/DIS on the Application Control Structure page
  for(var i=0;i<5;i++)
  {
    object[i+1].className    = "switch_off";
    object[i+1].style.color  = "gray";
    object[i+1].innerHTML    = "DISABLED"; 
  }     
  
  //  parsing selected MethodCtrl and set the EN/DIS switches and Id current popup menu
  if(pcm.ReadVariable(CtrlRegisterVal.childNodes[0].nodeValue));
  {
     var in_ctrlRegister = pcm.LastVariable_vValue;
     // separate the method for Id current control
     var in_IdMethodRegister = in_ctrlRegister - 3;
     // separate the method for cascade control structure selection
     if (in_ctrlRegister>3) in_ctrlRegister = 3;
     
     for(var i=0;i<4;i++){
        if(i==in_ctrlRegister)  // i = selected method
        {
          // The button of selected method is ON - Enabled - white colored
          object[i+1].className    = "switch_on";
          object[i+1].style.color  = "white";
          object[i+1].innerHTML    = "ENABLED";
          
          // input text box of selected method is enabled 
          if(i==3)             var boxNumber = 2;
          else                 var boxNumber = 3;  
          for(var j=1;j<boxNumber;j++){
            var Ctrl_type = conversionNo2Ctrl(i);                     
            document.getElementById(prefixM + Ctrl_type +'_Input'+[j]).disabled = false;}   
          
          //  Sensor type selector is enabled for all methods ecxept Scalar control, Button is On
          if (i>0){
            object[5].className    = "switch_on";
            object[5].style.color  = "white";
            object[5].innerHTML    = "ENABLED";
            document.getElementById(prefixM +'pospe_ctrl_Select').disabled = false;}
          else
            document.getElementById(prefixM +'pospe_ctrl_Select').disabled = true;
        }
        else // unseledted methods - input text box are disabled
        {
          // disabled unused text boxes within an Application Control structure tab
          if(i==3)             var boxNumber = 2;
          else                 var boxNumber = 3;  
            for(var j=1;j<boxNumber;j++){
              var Ctrl_type = conversionNo2Ctrl(i);
              document.getElementById(prefixM+[Ctrl_type]+'_Input'+[j]).disabled = true;}
        } 
      }
     
  }
  
  //  parsing selected PospeFbck and set the sensor type popup menu  
  if(pcm.ReadVariable(PospeRegisterVal.childNodes[0].nodeValue));
  {
     var in_pospeRegister = pcm.LastVariable_vValue;    
     var object_Pospe_control = document.getElementById(prefixM +'pospe_ctrl_Select');
     object_Pospe_control.selectedIndex = in_pospeRegister;
   }  


  // Application On/Off state checking and updating 
  var onoff_object = document.getElementById('sw_app_onoff');
        
  if(pcm.ReadVariable(on_off.childNodes[0].nodeValue));
  {
			var onoffvar = pcm.LastVariable_vValue;
			if(onoffvar == 0)
			{
			  onoffvar = 1;
        onoff_object.className    = "appOff";            
      }
      else
      {
        onoffvar = 0;
        onoff_object.className    = "appOn"; 
      }
		}
}

/***************************************************************************//*!
*
* @brief   Reload of the values from FRM to TW text boxex
* @param   
* @return  None
* @remarks 
******************************************************************************/     
/* ---------------- Cascade control structure variables update ------------------ */  
function Frm2TwValuesReload(){
  var retMsg;
  
  var xmlDoc           = loadXMLDoc("xml_files\\FM_params_list.xml");   
  var prefixM          = getActiveMotor();  
  var CtrlRegisterVal  = xmlDoc.getElementsByTagName([prefixM]+"ControlStructureMethod")[0];
  var Nmax          = getParentHtmlValue("N_max");
  var UDCmax        = getParentHtmlValue("UDC_max");
  var UmaxCoeff     = getParentHtmlValue("UmaxCoeff");
  var Uphnom        = getParentHtmlValue("U_ph");
  var N_nom         = getParentHtmlValue("N_req");
  var Motor_pp      = getParentHtmlValue("pp");
  var Umax          = Math.round(UDCmax/UmaxCoeff*10)/10;
  
  //  parsing selected MethodCtrl and set the EN/DIS switches and Id current popup menu
  if(pcm.ReadVariable(CtrlRegisterVal.childNodes[0].nodeValue));
  {
     var in_ctrlRegister = pcm.LastVariable_vValue;
     // separate the method for Id current control
     var in_IdMethodRegister = in_ctrlRegister - 3;
     // separate the method for cascade control structure selection
     if (in_ctrlRegister>3) in_ctrlRegister = 3;
     
     for(var i=0;i<4;i++){
        if(i==in_ctrlRegister)  // i = selected method
        {
          var Ctrl_type = conversionNo2Ctrl(i);
          var Val1_type = conversionXml2Variables(i*2); 
          var Val2_type = conversionXml2Variables(i*2+1);
 
          reference_val1 = xmlDoc.getElementsByTagName([prefixM]+[Val1_type])[0];
          reference_val2 = xmlDoc.getElementsByTagName([prefixM]+[Val2_type])[0];

          if(pcm.ReadVariable(reference_val1.childNodes[0].nodeValue))
                document.getElementById(prefixM+[Ctrl_type]+'_Input1').value = Math.ceil(pcm.LastVariable_vValue*100)/100;  
          if(i!=3)
           if(pcm.ReadVariable(reference_val2.childNodes[0].nodeValue))
                document.getElementById(prefixM+[Ctrl_type]+'_Input2').value = Math.ceil(pcm.LastVariable_vValue*10)/10; 
          if(i==0)
          {
              var aritType      = parent.document.getElementById("Arithmetic").innerText;
              k_factor          = Number(parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML); 
                          
              if(getActiveMode()==0)            
              {
                  // basic mode
                  k_factor = 1;
              
                  //fix implementation         
                  k_rate_sc         = Uphnom*Nmax*k_factor/(Umax*N_nom);
                  if(k_rate_sc >1)
                      k_rate_shift    = Math.ceil(Math.log(Math.abs(k_rate_sc))/Math.log(2));
                  else
                      k_rate_shift    = 0
                  
                  k_rate_frac       = k_rate_sc*Math.pow(2,-k_rate_shift);
                                          
                  //float implementation
                  k_rate_gain     = Motor_pp*Uphnom*k_factor/(N_nom);             
                                                 
                  if(aritType==='Float')
                  {
                      document.getElementById(prefixM+'scalar_ctrl_Input1').value = Math.round(k_rate_gain*10000)/10000;
                  }
                  else
                  {
                      document.getElementById(prefixM+'scalar_ctrl_Input1').value = Math.round(k_rate_sc*100)/100;
                  }                                         
              }
              else
              { 
                  document.getElementById(prefixM+'scalar_ctrl_Input1').value = parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML;
              }    
                            
               document.getElementById(prefixM+'ScalarUp').disabled = false;                                            
               document.getElementById(prefixM+'ScalarDown').disabled = false;
          } 
        }
        else                    // unseledted methods - input text box are kept at 0
        {
          var Ctrl_type = conversionNo2Ctrl(i);
          document.getElementById(prefixM+[Ctrl_type]+'_Input1').value = 0;
          if(i!=3)
            document.getElementById(prefixM+[Ctrl_type]+'_Input2').value = 0;
          if(i==0)
            document.getElementById(prefixM+[Ctrl_type]+'_Input1').value = parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML;            

        } 
      } // end of for*/
  } // end of if 
}


/***************************************************************************//*!
*
* @brief   The function stop count timer interval - Stop refreshing the cascade page
* @param   
* @return  None
* @remarks: Stopped refreshing is needed when the user wants to change any control method
*           by selector (Id control, sensor type) 
******************************************************************************/ 
function stopCountInterval()
{
    clearInterval(Timer_object);
}

/***************************************************************************//*!
*
* @brief   Change of the cascade control structure method - according to click
* @param   optionNo - number of selected method
* @return  None
* @remarks 
******************************************************************************/ 
function sensorTypeChange(optionNo)
{
    var retMsg;                                                                               
    var xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml"); 
    var prefixM = getActiveMotor();  
    var PospeRegisterVal = xmlDoc.getElementsByTagName([prefixM]+"ControlStructurePoSpe")[0];

    succ = pcm.WriteVariable(PospeRegisterVal.childNodes[0].nodeValue, Number(optionNo), retMsg);    
}

/***************************************************************************//*!
*
* @brief   Change of the Id control method - according to selector
* @param   optionNo - number of selected method
* @return  None
* @remarks 
******************************************************************************/ 
function IdMethodChange(optionNo)
{
    var retMsg;
    var xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");  
    var prefixM = getActiveMotor();  
    var CtrlRegisterVal = xmlDoc.getElementsByTagName([prefixM]+"ControlStructureMethod")[0];
    
    succ = pcm.WriteVariable(CtrlRegisterVal.childNodes[0].nodeValue, Number(optionNo)+3, retMsg);
}

/***************************************************************************//*!
*
* @brief   Cascade control structure selector
* @param   varID - ID of selected control structure
* @return  None
* @remarks 
******************************************************************************/ 
function Ctrl_Structure_click(varID){
    var retMsg;
    var ctrlRegister  = null;
   
    var Nmax          = getParentHtmlValue("N_max");
    var UDCmax        = getParentHtmlValue("UDC_max");
    var UmaxCoeff     = getParentHtmlValue("UmaxCoeff");
    var Uphnom        = getParentHtmlValue("U_ph");
    var N_nom         = getParentHtmlValue("N_req");
    var Motor_pp      = getParentHtmlValue("pp");
    var Umax          = Math.round(UDCmax/UmaxCoeff*10)/10;
    
    var aritType      = parent.document.getElementById("Arithmetic").innerText;
                                        
    var xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");
    var prefixM = getActiveMotor();    
      
    var CtrlRegisterVal  = xmlDoc.getElementsByTagName([prefixM]+"ControlStructureMethod")[0];
    var on_off           = xmlDoc.getElementsByTagName([prefixM]+"onoff")[0];

    // clear all control inputs        
    document.getElementById(prefixM+'scalar_ctrl_Input1').value = 0;
    document.getElementById(prefixM+'scalar_ctrl_Input2').value = 0;
    document.getElementById(prefixM+'volt_ctrl_Input1').value = 0;
    document.getElementById(prefixM+'volt_ctrl_Input2').value = 0; 
    document.getElementById(prefixM+'current_ctrl_Input1').value = 0;
    document.getElementById(prefixM+'current_ctrl_Input2').value = 0; 
    document.getElementById(prefixM+'speed_ctrl_Input1').value = 0; 
                 
    // chceck the state of ON/OFF switch    
    if(pcm.ReadVariable(on_off.childNodes[0].nodeValue));
    {
        var onoffvar = pcm.LastVariable_vValue;
      
        // If ON state is active, it does not allow to change the control structure
	    if(onoffvar == 1)
        {
            alert("The control structure cannot be changed during the RUN state!"+ '\n' + "Switch off the application.");        
        }
        else // If OFF state is active, the change of the control structure is allowed
        {
            // allow text boxes related to selected control method in Application Control structure tab      
            if(varID==(prefixM+'speed_ctrl')) var boxNumber = 2;
            else                              var boxNumber = 3;  
            for(var j=1;j<boxNumber;j++){
               document.getElementById([varID]+'_Input'+[j]).disabled = false;}   
            
            // generate ctrlRegister value that will be send to FRM (enum type)   
            if(pcm.ReadVariable(CtrlRegisterVal.childNodes[0].nodeValue));
            {
                var in_ctrlRegister = pcm.LastVariable_vValue;
                    
                if (varID == prefixM+'scalar_ctrl')    
                {
                    ctrlRegister = 0;
                    document.getElementById(prefixM+'pospe_ctrl_Select').selectedIndex = -1;
                    document.getElementById(prefixM+'pospe_ctrl_Select').disabled = true;
    
                    k_factor          = Number(parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML); 
                    
                    if(getActiveMode()==0)            
                    {
                        // basic mode
                        k_factor = 1;
                    
                        //fix implementation         
                        k_rate_sc         = Uphnom*Nmax*k_factor/(Umax*N_nom);
                        if(k_rate_sc >1)
                            k_rate_shift    = Math.ceil(Math.log(Math.abs(k_rate_sc))/Math.log(2));
                        else
                            k_rate_shift    = 0
                        
                        k_rate_frac       = k_rate_sc*Math.pow(2,-k_rate_shift);
                                                
                        //float implementation
                        k_rate_gain     = Motor_pp*Uphnom*k_factor/(N_nom);             
                                                       
                        if(aritType==='Float')
                        {
                            document.getElementById(prefixM+'scalar_ctrl_Input1').value = Math.round(k_rate_gain*10000)/10000;
                        }
                        else
                        {
                            document.getElementById(prefixM+'scalar_ctrl_Input1').value = Math.round(k_rate_sc*100)/100;
                        }                                         
                    }
                    else
                    { 
                        document.getElementById(prefixM+'scalar_ctrl_Input1').value = parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML;
                    }    

                    document.getElementById(prefixM+'scalar_ctrl_Input2').value = 0;
                    document.getElementById(prefixM+'ScalarUp').disabled = false;                                            
                    document.getElementById(prefixM+'ScalarDown').disabled = false;
                }                              
                                             
                if (varID == prefixM+'volt_ctrl')      
                {
                    ctrlRegister = 1;
                    document.getElementById(prefixM+'volt_ctrl_Input1').value = 0;
                    document.getElementById(prefixM+'volt_ctrl_Input2').value = 0;
                    document.getElementById(prefixM+'ScalarUp').disabled = true;                                            
                    document.getElementById(prefixM+'ScalarDown').disabled = true;
                }                              
    
                if (varID == prefixM+'current_ctrl')   
                {
                    ctrlRegister = 2;
                    document.getElementById(prefixM+'current_ctrl_Input1').value = 0;
                    document.getElementById(prefixM+'current_ctrl_Input2').value = 0;
                    document.getElementById(prefixM+'ScalarUp').disabled = true;                                            
                    document.getElementById(prefixM+'ScalarDown').disabled = true;
                }
                                                            
                if (varID == prefixM+'speed_ctrl')     
                {
                    ctrlRegister = 3;
                    //document.getElementById('speed_ctrl_Select').disabled = false
                    document.getElementById(prefixM+'ScalarUp').disabled = true;                                            
                    document.getElementById(prefixM+'ScalarDown').disabled = true;
                }    
              
                // write to FRM   
                succ = pcm.WriteVariable(CtrlRegisterVal.childNodes[0].nodeValue, ctrlRegister, retMsg);
           }
       }
    }
}

/***************************************************************************//*!
*
* @brief   On-Off toggle button routine
* @param   None
* @return  None
* @remarks 
******************************************************************************/    
function Power_click(){
  var retMsg;
  var onoffvar; 
  
  var prefixM = getActiveMotor();
     
  xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");
  var on_off=xmlDoc.getElementsByTagName([prefixM]+"onoff");
  
  var object = document.getElementById('sw_app_onoff');
  if(pcm.ReadVariable(on_off[0].childNodes[0].nodeValue))
		{
			var onoffvar = pcm.LastVariable_vValue;
			if(onoffvar == 0)
			{
			  onoffvar = 1;
        object.className    = "appOn";            
      }
      else
      {
        onoffvar = 0;
        object.className    = "appOff"; 
      }
		}
		
		succ = pcm.WriteVariable(on_off[0].childNodes[0].nodeValue, onoffvar, retMsg);
}      

/***************************************************************************//*!
*
* @brief   State machine engine
* @param   None
* @return  None
* @remarks 
******************************************************************************/ 
function StateMachine(){
      var ValueState;
      
      xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");
      
      var prefixM = getActiveMotor();
      var ActualState=xmlDoc.getElementsByTagName([prefixM]+"states")[0].getAttribute("FreemasterName");
     
         
      if(pcm.ReadVariable(ActualState))
      {
        xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");
        
        var states=xmlDoc.getElementsByTagName([prefixM]+"state"); 
        ValueState = pcm.LastVariable_vValue;
  
  
        var x=document.getElementById('textApplicationState').rows;
        var y=x[0].cells;
        y[0].align="center";
        y[0].innerHTML =  states[ValueState].childNodes[0].nodeValue;  
        y[0].className = "stateTableCell";
        
        if(ValueState == 1)
        {  
          //document.getElementById('textApplicationState').style.background = "#FF9999";
          document.getElementById('textApplicationState').style.fontWeight = "bold";
          document.getElementById('textApplicationState').style.color = "#FC0506";          
        }      
        else
        {
          //document.getElementById('textApplicationState').style.background = "transparent";
          document.getElementById('textApplicationState').style.fontWeight = "normal";    
          document.getElementById('textApplicationState').style.color = "#000000";                  
        }    
      }
}                                                                                                                                          
     
/***************************************************************************//*!
*
* @brief   chose the image according to selected method
* @param   None
* @return  None
* @remarks               document.getElementById('scalar_ctrl_Input1').value
******************************************************************************/ 
function clickCntStrImage(varID){
    
    var prefixM = getActiveMotor();

    switch(varID)
    {
      case (prefixM+"scalar_ctrl"): 
        setImageDimensions('images/SCcontrol.png',520,300);
      break;
      
      case (prefixM+"volt_ctrl"): 
        setImageDimensions('images/Vcontrol.png',430,295);
      break;
      
      case (prefixM+"current_ctrl"): 
        setImageDimensions('images/Ccontrol.png',590,400);
      break;
      
      case (prefixM+"speed_ctrl"): 
        setImageDimensions('images/Wcontrol.png',765,400);
      break;
        
    default:
    }
}  

/***************************************************************************//*!
*
* @brief   Sets the size of iframe window according to displayed image
* @param   None
* @return  None
* @remarks 
******************************************************************************/ 
function setImageDimensions(imPath, inW, inH){
      var prefixM = getActiveMotor();
    
      var object  = document.getElementById('cntrStrucFrameImage');
      var object2 = document.getElementById('cntrStrucFrameButton');
      
      var buttonUP   = document.getElementById(prefixM+'ScalarUp');                                            
      var buttonDOWN = document.getElementById(prefixM+'ScalarDown');      
      
      object.src            = imPath;
      
      object.style.width    = inW.toString()+"px";
      object.style.height   = inH.toString()+"px";   
    
      object.style.top      = "40px";
      object.style.left     = ((800-inW)/2).toString()+"px";
      
      object2.style.width   = "120px";
      object2.style.height  = "25px";  
            
      object2.style.top     = (40 + inH - 30).toString()+"px";
      object2.style.left    = ((800-120)/2).toString()+"px";
      
    object.style.display = "block";
    object2.style.display = "block";
    
    buttonUP.style.visibility = "hidden";
    buttonDOWN.style.visibility = "hidden";    

    object2.src = 'form_buttonCloseWindow.html';      
}   

/***************************************************************************//*!
*
* @brief   Onclic button event - Update FRM values
* @param   None
* @return  None
* @remarks 
******************************************************************************/
function clickUpdateCtrlStruc(){
    var retMsg;
    var prefixM   = getActiveMotor();
    var writeFRM  = new Array();
    var writeFRMoffset = 0;

    xmlDoc=loadXMLDoc("xml_files\\FM_params_list.xml");
    var MethodCtrlVal = xmlDoc.getElementsByTagName([prefixM]+"ControlStructureMethod")[0];
    
    if(pcm.ReadVariable(MethodCtrlVal.childNodes[0].nodeValue))
      {
        var in_MethodCtrlVal = pcm.LastVariable_vValue;

        if (in_MethodCtrlVal == 0)
        {
            var Nmax          = getParentHtmlValue("N_max");
            var UDCmax        = getParentHtmlValue("UDC_max");
            var UmaxCoeff     = getParentHtmlValue("UmaxCoeff");
            var Uphnom        = getParentHtmlValue("U_ph");
            var N_nom         = getParentHtmlValue("N_req");
            var Motor_pp      = getParentHtmlValue("pp");
            var Umax          = Math.round(UDCmax/UmaxCoeff*10)/10;
            
            var k_factor_max  = 2;
            var aritType      = parent.document.getElementById("Arithmetic").innerText;
            
            // read actual value manualy set
            k_factor          = (document.getElementById(prefixM+'scalar_ctrl_Input1').value); 
	        parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML = k_factor;

            
            if(getActiveMode()==0)            
            {
                // basic mode
                k_factor = 1;
            }
            //fix implementation         
            k_rate_sc         = (Uphnom*Nmax/(Umax*N_nom))*k_factor;
                
            if(k_rate_sc >1)
                k_rate_shift    = Math.ceil(Math.log(Math.abs(k_rate_sc))/Math.log(2));
            else
                k_rate_shift    = 0
            
            k_rate_frac       = k_rate_sc*Math.pow(2,-k_rate_shift);
            
            //float implementation
            k_rate_gain     = Motor_pp*Uphnom*k_factor/(N_nom);             
                   
            if(aritType==='Float')
            {
                writeFRM[0] = k_rate_gain;
                document.getElementById(prefixM+'scalar_ctrl_Input1').value = Math.round(k_rate_gain*10000)/10000;
            }
            else
            {
                writeFRM[0] = k_rate_frac;
                writeFRM[1] = k_rate_shift;
            }                          
             
            writeFRM[2] = Number((document.getElementById(prefixM+'scalar_ctrl_Input2').value));
            
            var writeFRMregisterVal0 = xmlDoc.getElementsByTagName([prefixM]+"SCALAR_VHZ_FACTOR_GAIN");
            var writeFRMregisterVal1 = xmlDoc.getElementsByTagName([prefixM]+"SCALAR_VHZ_FACTOR_SHIFT");
            var writeFRMregisterVal2 = xmlDoc.getElementsByTagName([prefixM]+"Freq_req"); 
        }
        
        if (in_MethodCtrlVal == 1){
             writeFRM[0] = document.getElementById(prefixM+'volt_ctrl_Input1').value;
             writeFRM[1] = document.getElementById(prefixM+'volt_ctrl_Input2').value;
             
             var writeFRMregisterVal0 = xmlDoc.getElementsByTagName([prefixM]+"Ud_req");
             var writeFRMregisterVal1 = xmlDoc.getElementsByTagName([prefixM]+"Uq_req");
        }
        
        if (in_MethodCtrlVal == 2){
             writeFRM[0] = document.getElementById(prefixM+'current_ctrl_Input1').value;
             writeFRM[1] = document.getElementById(prefixM+'current_ctrl_Input2').value;
             
             var writeFRMregisterVal0 = xmlDoc.getElementsByTagName([prefixM]+"Id_req");
             var writeFRMregisterVal1 = xmlDoc.getElementsByTagName([prefixM]+"Iq_req");    
        }
        
        if (in_MethodCtrlVal == 3){
             writeFRM[0] = document.getElementById(prefixM+'speed_ctrl_Input1').value;
             var writeFRMregisterVal0 = xmlDoc.getElementsByTagName([prefixM]+"Speed_req");

             if(Math.abs(writeFRM[0]) <= getParentHtmlValue("N_min"))
             {
               writeFRM[0] = 0;
               document.getElementById(prefixM+'speed_ctrl_Input1').value = 0;
             }
        }
        
        if (in_MethodCtrlVal > 3){
             writeFRM[0] = document.getElementById(prefixM+'speed_ctrl_Input1').value;
             var writeFRMregisterVal0 = xmlDoc.getElementsByTagName([prefixM]+"Speed_req");
        }
        
        if (in_MethodCtrlVal<3)
        {
            succ = pcm.WriteVariable(writeFRMregisterVal0[0].childNodes[0].nodeValue, Number(writeFRM[0]), retMsg); 
            if(aritType!=='Float')
                succ = pcm.WriteVariable(writeFRMregisterVal1[0].childNodes[0].nodeValue, Number(writeFRM[1]), retMsg);
            if(in_MethodCtrlVal== 0)
            {   
                succ = pcm.WriteVariable(writeFRMregisterVal2[0].childNodes[0].nodeValue, Number(writeFRM[2]), retMsg);
            }
        }
        else
             succ = pcm.WriteVariable(writeFRMregisterVal0[0].childNodes[0].nodeValue, Number(writeFRM[0]), retMsg);
      }  
}

/***************************************************************************//*!
*
* @brief  The function reads values from input forms, scales them and write 
*         to output HTML form
* @param   
* @return 
* @remarks 
******************************************************************************/
function writeCascadeHTMLOutput(prefix,xmlObject)
{ 
  var Nmax          = getParentHtmlValue("N_max");
  var UDCmax        = getParentHtmlValue("UDC_max");
  var UmaxCoeff     = getParentHtmlValue("UmaxCoeff");    
  var Uphnom        = getParentHtmlValue("U_ph");
  var N_nom         = getParentHtmlValue("N_req");
  var Motor_pp      = getParentHtmlValue("pp");
  var CLOOP_Ts      = getParentHtmlValue("CLOOP_Ts");
  var SLOOP_Ts      = getParentHtmlValue("SLOOP_Ts");
  var RAMP_Up       = getParentHtmlValue("RAMP_UP");
  var RAMP_Down     = getParentHtmlValue("RAMP_DOWN");
  var PP            = getParentHtmlValue("pp");
  var Wmax          = 2*Math.PI*PP*Nmax/60;
  var Umax          = Math.round(UDCmax/UmaxCoeff*10)/10;
  
  var k_factor_max  = 2;
  
  var prefixM = getActiveMotor();
  
  // Control Structure module - scalar control part
  document.write(HTML_write_blank_line());     
  document.write(HTML_write_comment_line("Control Structure Module - Scalar Control","",""));
  document.write(HTML_write_comment_line_dash()); 

  k_factor         = Number(parent.document.getElementById(prefixM+'SCALAR_Factor').innerText);   
           
  //fix implementation         
  k_rate_sc         = Uphnom*Nmax*k_factor/(Umax*N_nom);
                  
  if(k_rate_sc ==1)
    k_rate_sc = k_rate_sc + 0.0000001;
    
    k_rate_shift    = Math.ceil(Math.log(Math.abs(k_rate_sc))/Math.log(2));
   
  
  k_rate_frac       = Math.round(k_rate_sc*Math.pow(2,-k_rate_shift)*1000000000000)/1000000000000;
  
  //float implementation
  k_rate_gain     = Motor_pp*Uphnom*k_factor/(N_nom);               
  /* check preset discretization method */
  var DiscMethod = parent.document.getElementById("DiscMethod").innerText;
  var DiscMethodFactor = 1;
  if(DiscMethod=="Trapezoidal")
      DiscMethodFactor = 2; 
                           
  /* intergration constant for scalar position calculation */
  Kint = 2*Math.PI*Motor_pp*Nmax/60*CLOOP_Ts/DiscMethodFactor/Math.PI; 
  if (Kint>=(1-1/Math.pow(2,31)))
		   Kint_sc = Math.ceil(Math.log(Math.abs(Kint))/Math.log(2));
   else
      Kint_sc = 0;
    
		Int_Nsh  = Kint_sc;
    Int_C1   = Math.round(Kint/Math.pow(2,Kint_sc)*1000000000000)/1000000000000;
    testFracValRange("Int_C1",Int_C1);
   
  // scalar speed ramp increments
  ScalarRampIncUp_float = RAMP_Up*CLOOP_Ts;
  ScalarRampIncDown_float = RAMP_Down*CLOOP_Ts;
  ScalarRampIncUp =  Math.round(RAMP_Up/60*PP*2*Math.PI/Wmax*CLOOP_Ts*1000000000000)/1000000000000;
  ScalarRampIncDown =  Math.round(RAMP_Down/60*PP*2*Math.PI/Wmax*CLOOP_Ts*1000000000000)/1000000000000;
  testFracValRange("ScalarRampIncUp",ScalarRampIncUp,1);
  testFracValRange("ScalarRampIncDown",ScalarRampIncDown,1);   
           
  document.write(HTML_write_define_line_number(prefix,0,"SCALAR_VHZ_FACTOR_GAIN",xmlObject));
  document.write(HTML_write_define_line_number(prefix,1,"SCALAR_VHZ_FACTOR_SHIFT",xmlObject));    
  setInnerHtmlValueAsText("SCALAR_VHZ_FACTOR_GAIN",0,k_rate_frac,k_rate_gain);
  setInnerHtmlValueAsText("SCALAR_VHZ_FACTOR_SHIFT",1,k_rate_shift,'N/A');  
  
  document.write(HTML_write_define_line_number(prefix,0,"SCALAR_INTEG_GAIN",xmlObject));
  document.write(HTML_write_define_line_number(prefix,1,"SCALAR_INTEG_SHIFT",xmlObject));
  setInnerHtmlValueAsText("SCALAR_INTEG_GAIN",0,Int_C1,Kint);
  setInnerHtmlValueAsText("SCALAR_INTEG_SHIFT",1,Int_Nsh);   
  
  /* scalar ramp increments */
  document.write(HTML_write_define_line_number(prefix,0,"SCALAR_RAMP_UP",xmlObject));
  document.write(HTML_write_define_line_number(prefix,0,"SCALAR_RAMP_DOWN",xmlObject));
  setInnerHtmlValueAsText("SCALAR_RAMP_UP",7,ScalarRampIncUp);
  setInnerHtmlValueAsText("SCALAR_RAMP_DOWN",7,ScalarRampIncDown);       
}

/***************************************************************************//*!
* @brief  The function reads values from input forms, scales them and write 
*         to output file form
* @param   
* @return 
* @remarks 
******************************************************************************/
function writeCascadeHeaderOutput(str)
{
   str = write_blank_lines(str,1);     
   str = write_comment_text(str,'Control Structure Module - Scalar Control','');
   str = write_comment_line_dash(str);
 
   var aritType     = parent.document.getElementById("Arithmetic").innerText;
   
   // Cascade module
   str = write_define_line_number(str,'SCALAR_VHZ_FACTOR_GAIN');
   str = write_define_line_number(str,'SCALAR_VHZ_FACTOR_SHIFT');
   str = write_define_line_number(str,'SCALAR_INTEG_GAIN');
   str = write_define_line_number(str,'SCALAR_INTEG_SHIFT');
   str = write_define_line_number(str,'SCALAR_RAMP_UP');
   str = write_define_line_number(str,'SCALAR_RAMP_DOWN');
        
   return str;
}

/***************************************************************************//*!
* @brief  The function reads values from input forms, scales them and write 
*         to output file form
* @param   
* @return 
* @remarks 
******************************************************************************/
function clickScalarUpDown(varID)
{
    var prefixM = getActiveMotor();
    
    var k_factor_max  = 5;
    var IncDec        = 0.02;
    var k_factor      = Number(document.getElementById(prefixM+'scalar_ctrl_Input1').value);//Number(parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML);
    
    // Up/Down buttons enabled only in expert mode
    if(getActiveMode()!=0)            
    {
        switch(varID)
        {
         case prefixM+"ScalarUp":
          if (k_factor<k_factor_max) {
            k_factor =  k_factor + IncDec;
            parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML = Math.round(k_factor*100)/100;
            document.getElementById(prefixM+'scalar_ctrl_Input1').value = Math.round(k_factor*100)/100;
           }
          break;       
         case prefixM+"ScalarDown":
         if(k_factor>0){
            k_factor =  k_factor - IncDec;
            parent.document.getElementById(prefixM+'SCALAR_Factor').innerHTML = Math.round(k_factor*100)/100;
            document.getElementById(prefixM+'scalar_ctrl_Input1').value = Math.round(k_factor*100)/100;
            }
          break;  
         default: 
        }
    
       clickUpdateCtrlStruc();
    }
}

/***************************************************************************//*!
* 
******************************************************************************
* End of code
******************************************************************************/
    