/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */

/*
 * File:	freedom.h
 * Purpose:	Kinetis Freedom CPU card definitions
 *
 * Notes:
 */

#ifndef __TOWER_H__
#define __TOWER_H__

#include "mcg.h"

/* Global defines to use for TWR_K64F120M */
#define DEBUG_PRINT

#if (defined(FRDM_KV31F120M))
#       define MCU_MKV31F512VLL12
//#define MCU_MKV31F256VLL12
#	define BRD_STRING			"FRDM-KV31F120M"
#	define BRD_SYSCLOCK			(((CLK0_FREQ_HZ/ PLL0_PRDIV) * PLL0_VDIV) / 1000000)
#	define BRD_HS_SYSCLOCK			(((CLK0_FREQ_HZ/ PLL0_PRDIV_HS) * PLL0_VDIV_HS) / 1000000)

 /* Input Clock Info */
#	define CLK0_FREQ_HZ			8000000
#	define CLK0_TYPE			CRYSTAL

  /* PLL Configuration Info */
//#	define NO_PLL_INIT

/*
 * The expected PLL output frequency is:
 * PLL out = (((CLKIN/PRDIV) x VDIV))
 * where the CLKIN can be either CLK0_FREQ_HZ or CLK1_FREQ_HZ.
 *
 * For more info on PLL initialization refer to the mcg driver files.
 */

  #define PLL0_PRDIV      4             // run mode PRDIV (8 MHz div 4 = 2 MHz)
  #define PLL0_VDIV       40            // run mode DVDIV (2 MHz * 40 = 80 MHz)
//#define PLL0_VDIV       38            // run mode DVDIV (2 MHz * 38 = 76 MHz)
//#define PLL0_VDIV       36            // run mode DVDIV (2 MHz * 36 = 72 MHz)
//#define PLL0_VDIV       34            // run mode DVDIV (2 MHz * 34 = 68 MHz)
//#define PLL0_VDIV       32            // run mode DVDIV (2 MHz * 32 = 64 MHz)
//#define PLL0_VDIV       26            // run mode DVDIV (2 MHz * 26 = 52 MHz)

  #define PLL0_PRDIV_HS   2             // high speed run PRDIV
  #define PLL0_VDIV_HS    30            // high speed run VDIV

  #define CORE_CLK_DIV            0
  #define BUS_CLK_DIV             1
  #define FLEXBUS_CLK_DIV         2
  #define FLASH_CLK_DIV           2

  #define CORE_CLK_DIV_HS            0
  #define BUS_CLK_DIV_HS             1
  #define FLEXBUS_CLK_DIV_HS         4
  #define FLASH_CLK_DIV_HS           4

	/* System Bus Clock Info */
#	define REF_CLK				XTAL8
#	define CORE_CLK_MHZ			PLL80      			/* system/core frequency in MHz */

	/* Serial Port Info */
#	define TERM_PORT			UART0_BASE_PTR	/* OSJTAG serial port or TWR-SER COM port */
#	define TERMINAL_BAUD		        115200

#       define UART0_CLK                  1
#	undef UART0_ALT1		/* PTA_1/2 */
#	undef UART0_ALT2		/* PTA_14/15 */
#	define UART0_ALT3		/* PTB_16/17 */
#	undef UART0_ALT4		/* PTD_6/7 */
#	undef HW_FLOW_CONTROL	/* UART0, PTA_0/3 */
#	undef HW_FLOW_CONTROL1	/* UART0, PTA_16/17 */
#	undef HW_FLOW_CONTROL2	/* UART0, PTB_2/3 */
#	undef HW_FLOW_CONTROL3	/* UART0, PTD_4/5 */

#	undef UART1_ALT2		/* PTE_0/1 */
#	undef UART1_ALT1		/* PTC_3/4 */
#	undef HW_FLOW_CONTROL	/* UART1, PTC_1/2 */
#	undef HW_FLOW_CONTROL1	/* UART1, PTE_2/3 */

#	undef UART2_ALT1		/* PTD_2/3 */
#	undef HW_FLOW_CONTROL	/* UART1, PTD_0/1 */

#else
#	error "No valid tower CPU card defined"
#endif

  #define LED0_EN (PORTD_PCR1 = PORT_PCR_MUX(1))  //RED
  #define LED1_EN (PORTD_PCR7 = PORT_PCR_MUX(1))  //GREEN
  #define LED2_EN (PORTE_PCR25 = PORT_PCR_MUX(1)) //BLUE
//  #define LED3_EN (PORTD_PCR7 = PORT_PCR_MUX(1))

  #define LED0_DIR GPIOD_PDDR |= (1<<1);
  #define LED1_DIR GPIOD_PDDR |= (1<<7);
  #define LED2_DIR GPIOE_PDDR |= (1<<25);
//  #define LED3_DIR GPIOE_PDDR |= (1<<1);

  #define LED0_TOGGLE (GPIOD_PTOR = (1<<1))
  #define LED1_TOGGLE (GPIOD_PTOR = (1<<7))
  #define LED2_TOGGLE (GPIOD_PTOR = (1<<25))
//  #define LED3_TOGGLE (GPIOD_PTOR = (1<<7))

  #define LED0_OFF (GPIOD_PSOR = (1<<1))
  #define LED1_OFF (GPIOD_PSOR = (1<<7))
  #define LED2_OFF (GPIOE_PSOR = (1<<25))
//  #define LED3_OFF (GPIOD_PSOR = (1<<7))

  #define LED0_ON (GPIOD_PCOR = (1<<1))
  #define LED1_ON (GPIOD_PCOR = (1<<7))
  #define LED2_ON (GPIOE_PCOR = (1<<25))
//  #define LED3_ON (GPIOD_PCOR = (1<<7))

#endif		/* __TOWER_H__ */