/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     M1_state_machine.c
*
* @brief    Motor 1 state machine 
*
******************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "M1_StateMachine.h"
#include "main.h"

#include "volt_dcb.h"

#include "pospe_obs.h"

#include "pwm3ph_ftm.h"

#include "curr3ph_2sh.h"

/******************************************************************************
* Constants
******************************************************************************/
#define CALIB_DURATION_SEC          0.2   /* calibration duration in seconds */
#define FAULT_RELEASE_DURATION_SEC  3     /* fault release duration in seconds*/
#define FREEWHEEL_DURATION_SEC      0.5   /* rotor freewheel duration in seconds */

/* calculated macros */
#define CALIB_DURATION              (CALIB_DURATION_SEC*SPEED_LOOP_FREQ)
#define FAULT_RELEASE_DURATION      (FAULT_RELEASE_DURATION_SEC*SPEED_LOOP_FREQ)
#define FREEWHEEL_DURATION          (FREEWHEEL_DURATION_SEC*SPEED_LOOP_FREQ)
#define SVM_SECTOR_DEFAULT          2    

/******************************************************************************
* Macros 
******************************************************************************/
/* modulation index set to 0.5 because the applicatinon is scaled to phase voltage / sqrt(3) */
#define MOD_INDEX                       FRAC16(0.5) 


/******************************************************************************
* Types
******************************************************************************/

/******************************************************************************
* Global variables
******************************************************************************/
/* main control structure */
MCDEF_PMSM_T                        gsM1Drive;

/* main application switch */
bool             mbM1SwitchAppOnOff;
bool             bDemoMode; // Demo mode enabled/dissabled
UWord32          uw32SpeedStimulatorCnt;  // Used for demo mode


/******************************************************************************
* Local variables
******************************************************************************/
/* M1 structure */
static M1_RUN_SUBSTATE_T            meM1StateRun;     
                                    
/* Position & Speed sensor */
static POSPE_OBS_T                  msM1PospeObs;  

/* Voltage sensor */
static VOLT_DCB_T                   msM1UDcBusSensor;

/* 3-phase PWM actuator */
static PWM3PH_FTM_T                 msM1Pwm3ph;

/* current sensing sensor */
static CURR3PH_2SH_T                msM1PhCurSensor;

static volatile UWord16             uw16DriverFault;


/* FreeMASTER scales */
/* DO NOT USE THEM in the code to avoid float library include */
static volatile float               fltM1voltageScale; 
static volatile float               fltM1DCBvoltageScale;
static volatile float               fltM1currentScale;
static volatile float               fltM1frequencyScale; 
static volatile float               fltM1speedScale;

/******************************************************************************
* Local functions
******************************************************************************/

/*------------------------------------
 * User state machine functions
 * ----------------------------------*/
static void M1_StateFault(void);
static void M1_StateInit(void);
static void M1_StateStop(void);
static void M1_StateRun(void);

/*------------------------------------
 * User state-transition functions
 * ----------------------------------*/
static void M1_TransFaultInit(void);
static void M1_TransInitFault(void);
static void M1_TransInitStop(void);
static void M1_TransStopFault(void);
static void M1_TransStopRun(void);
static void M1_TransRunFault(void);
static void M1_TransRunStop(void);

/* State machine functions field */
/* as global variable used in main.c */
extern const SM_APP_STATE_FCN_T msSTATE = {M1_StateFault, M1_StateInit, M1_StateStop, M1_StateRun};

/* State-transition functions field */
static const SM_APP_TRANS_FCN_T msTRANS = {M1_TransFaultInit, M1_TransInitFault, M1_TransInitStop, M1_TransStopFault, M1_TransStopRun, M1_TransRunFault, M1_TransRunStop};

/* State machine structure declaration and initialization */
SM_APP_CTRL_T gsM1Ctrl = 
{
    /* gsM1_Ctrl.psState, User state functions  */
    &msSTATE,
     
    /* gsM1_Ctrl..psTrans, User state-transition functions */
    &msTRANS,
 
    /* gsM1_Ctrl.uiCtrl, Deafult no control command */
    SM_CTRL_NONE,
      
    /* gsM1_Ctrl.eState, Default state after reset */
    INIT     
};

/*------------------------------------
 * User sub-state machine functions
 * ----------------------------------*/
static void M1_StateRunCalib(void);
static void M1_StateRunReady(void);
static void M1_StateRunAlign(void);
static void M1_StateRunStartup(void);
static void M1_StateRunSpin(void);
static void M1_StateRunFreewheel(void);

/*------------------------------------
 * User sub-state-transition functions
 * ----------------------------------*/
static void M1_TransRunCalibReady(void);
static void M1_TransRunReadyAlign(void);
static void M1_TransRunAlignStartup(void);
static void M1_TransRunStartupSpin(void);
static void M1_TransRunStartupFreewheel(void);
static void M1_TransRunSpinFreewheel(void);
static void M1_TransRunFreewheelReady(void);


/* Sub-state machine functions field */
static const PFCN_VOID_VOID mM1_STATE_RUN_TABLE[6] = {M1_StateRunCalib, M1_StateRunReady, M1_StateRunAlign, M1_StateRunStartup, M1_StateRunSpin, M1_StateRunFreewheel};

/* additional functions */
static void M1_FaultDetection(void);  
static void M1_ClearFOCVariables(void);

/***************************************************************************//*!
*
* @brief   FAULT state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateFault(void)
{
    /* read 3-phase motor currents */ /* otherwise the interrupt flag will not be cleared */
    SAC_Curr3Ph2ShGet(&msM1PhCurSensor);
    
    /* read DCBus voltage value */
    SAC_VoltDcBusGet(&msM1UDcBusSensor);
    gsM1Drive.sFocPMSM.f16UDcBusFilt = GDFLIB_FilterIIR1(gsM1Drive.sFocPMSM.f16UDcBus,&gsM1Drive.sFocPMSM.sUDcBusFilter);

    /* Disable user application switch */
    mbM1SwitchAppOnOff = FALSE;
        
    if (!MC_FAULT_ANY(gsM1Drive.sFaultIdPending))
    {
        /* Slow loop counter */
        if (--gsM1Drive.uw16CounterSlowLoop==0)
        {
            /* initialize speed loop counter */
            gsM1Drive.uw16CounterSlowLoop = gsM1Drive.uw16TimeSlowLoop;
            
            if (--gsM1Drive.uw16CounterState == 0)
            {
                /* Clear fault command */
                gsM1Ctrl.uiCtrl |= SM_CTRL_FAULT_CLEAR;
            }
        }
    }
    else
    {
        gsM1Drive.uw16CounterState = gsM1Drive.uw16TimeFaultRelease;
    }
    
    /* Detects faults */
    M1_FaultDetection();
}

/***************************************************************************//*!
*
* @brief   State Init function
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateInit(void)
{  
  
  
    /*----------------------------------------------
     *  Hardware independent layer - Constructors
     *---------------------------------------------*/
    /* Position and speed observer */
    msM1PospeObs.pf16PosElEst    = &gsM1Drive.sFocPMSM.f16PosElReload;
    msM1PospeObs.pf16SpeedElEst  = &gsM1Drive.sSpeed.f16Speed;
    msM1PospeObs.psIABC          = &gsM1Drive.sFocPMSM.sIABC;
    msM1PospeObs.psUDQ           = &gsM1Drive.sFocPMSM.sUDQReq;
    msM1PospeObs.psUAlBe         = &gsM1Drive.sFocPMSM.sUAlBeReq;
    msM1PospeObs.psAngleEl       = &gsM1Drive.sFocPMSM.sAnglePosEl;
    
    
    
    msM1PospeObs.sTo.f16PropScale                            = TO_KP_GAIN;
    msM1PospeObs.sTo.i16PropShift                            = TO_KP_SHIFT;
    msM1PospeObs.sTo.f16IntegScale                           = TO_KI_GAIN;
    msM1PospeObs.sTo.i16IntegShift                           = TO_KI_SHIFT;
    msM1PospeObs.sTo.f16ThScaled                             = TO_THETA_GAIN;
    msM1PospeObs.sTo.i16ThShift                              = TO_THETA_SHIFT;
    
    msM1PospeObs.sBemfObsrv.f16IScaled                       = I_SCALE;
    msM1PospeObs.sBemfObsrv.f16UScaled                       = U_SCALE;
    msM1PospeObs.sBemfObsrv.f16EScaled                       = E_SCALE;
    msM1PospeObs.sBemfObsrv.f16WIScaled                      = WI_SCALE; 
    msM1PospeObs.uw16IGainShift                              = I_SCALE_SHIFT;
    msM1PospeObs.sBemfObsrv.udtCtrl.f16PropScaled            = BEMF_DQ_KP_GAIN;        
    msM1PospeObs.sBemfObsrv.udtCtrl.f16IntegScaled           = BEMF_DQ_KI_GAIN;        
    msM1PospeObs.sBemfObsrv.udtCtrl.i16PropShift             = BEMF_DQ_KP_SHIFT;        
    msM1PospeObs.sBemfObsrv.udtCtrl.i16IntegShift            = BEMF_DQ_KI_SHIFT;  
    
    msM1PospeObs.sSpeedElEstFilt.trFiltCoeff.f16B0           = TO_SPEED_IIR_B0;    
    msM1PospeObs.sSpeedElEstFilt.trFiltCoeff.f16B1           = TO_SPEED_IIR_B1;
    msM1PospeObs.sSpeedElEstFilt.trFiltCoeff.f16A1           = TO_SPEED_IIR_A1;
    
    msM1PospeObs.bOpenLoop = TRUE;
    SAC_PospeObsClear(&msM1PospeObs);
    
    /* DCBus voltage measurement */
    msM1UDcBusSensor.pf16UDcBus = &gsM1Drive.sFocPMSM.f16UDcBus;
    SAC_VoltDcBusInit(&msM1UDcBusSensor);

    /* 3-phase PWM generation */
    SAC_FtmPwm3PhInit(&msM1Pwm3ph);
    msM1Pwm3ph.psUABC = &gsM1Drive.sFocPMSM.sDutyABC;
    
    /* 3-phase current measurement */
    SAC_Curr3Ph2ShInit(&msM1PhCurSensor);
    msM1PhCurSensor.psIABC = &gsM1Drive.sFocPMSM.sIABC;
    msM1PhCurSensor.puw16SVMSector = &gsM1Drive.sFocPMSM.uw16SectorSVM;
    /*----------------------------------------------
     *  End of SAC modules initialization 
     *---------------------------------------------*/
     
    /* PMSM FOC params */
    gsM1Drive.sFocPMSM.sIdPiParams.f16PropGain                     = D_KP_GAIN;
    gsM1Drive.sFocPMSM.sIdPiParams.f16IntegGain                    = D_KI_GAIN;
    gsM1Drive.sFocPMSM.sIdPiParams.w16PropGainShift                = D_KP_SHIFT;
    gsM1Drive.sFocPMSM.sIdPiParams.w16IntegGainShift               = D_KI_SHIFT;
    gsM1Drive.sFocPMSM.sIdPiParams.f16UpperLimit                   = FRAC16(1.0);  
    gsM1Drive.sFocPMSM.sIdPiParams.f16LowerLimit                   = FRAC16(-1.0);

    gsM1Drive.sFocPMSM.sIqPiParams.f16PropGain                     = Q_KP_GAIN;
    gsM1Drive.sFocPMSM.sIqPiParams.f16IntegGain                    = Q_KI_GAIN;
    gsM1Drive.sFocPMSM.sIqPiParams.w16PropGainShift                = Q_KP_SHIFT;
    gsM1Drive.sFocPMSM.sIqPiParams.w16IntegGainShift               = Q_KI_SHIFT;
    gsM1Drive.sFocPMSM.sIqPiParams.f16UpperLimit                   = FRAC16(1.0);  
    gsM1Drive.sFocPMSM.sIqPiParams.f16LowerLimit                   = FRAC16(-1.0);    

    gsM1Drive.sFocPMSM.uw16SectorSVM                               = SVM_SECTOR_DEFAULT;
    gsM1Drive.sFocPMSM.f16DutyCycleLimit                           = CLOOP_LIMIT;

    gsM1Drive.sFocPMSM.f16UDcBus                                   = 0;
    gsM1Drive.sFocPMSM.f16UDcBusFilt                               = 0;
    gsM1Drive.sFocPMSM.sUDcBusFilter.trFiltCoeff.f16B0             = UDCB_IIR_B0;
    gsM1Drive.sFocPMSM.sUDcBusFilter.trFiltCoeff.f16B1             = UDCB_IIR_B1;
    gsM1Drive.sFocPMSM.sUDcBusFilter.trFiltCoeff.f16A1             = UDCB_IIR_A1;
    
    /* Elim DCB ripple */
    gsM1Drive.sFocPMSM.sElimDCBRip.f16ModIndex                     = MOD_INDEX;

    gsM1Drive.sAlignment.f16UdReq                                  = ALIGN_VOLTAGE;
    gsM1Drive.sAlignment.uw16Time                                  = ALIGN_DURATION;

    /* Speed params */
    gsM1Drive.sSpeed.sSpeedPiParams.f16PropGain                    = SPEED_PI_PROP_GAIN;
    gsM1Drive.sSpeed.sSpeedPiParams.f16IntegGain                   = SPEED_PI_INTEG_GAIN;
    gsM1Drive.sSpeed.sSpeedPiParams.w16PropGainShift               = SPEED_PI_PROP_SHIFT;
    gsM1Drive.sSpeed.sSpeedPiParams.w16IntegGainShift              = SPEED_PI_INTEG_SHIFT;
    gsM1Drive.sSpeed.sSpeedPiParams.f16UpperLimit                  = SPEED_LOOP_HIGH_LIMIT;  
    gsM1Drive.sSpeed.sSpeedPiParams.f16LowerLimit                  = SPEED_LOOP_LOW_LIMIT;    

    gsM1Drive.sSpeed.sSpeedRampParams.f32RampUp                    = SPEED_RAMP_UP;
    gsM1Drive.sSpeed.sSpeedRampParams.f32RampDown                  = SPEED_RAMP_DOWN; 

    gsM1Drive.sSpeed.sSpeedFilter.trFiltCoeff.f16B0                = SPEED_IIR_B0;
    gsM1Drive.sSpeed.sSpeedFilter.trFiltCoeff.f16B1                = SPEED_IIR_B1;
    gsM1Drive.sSpeed.sSpeedFilter.trFiltCoeff.f16A1                = SPEED_IIR_A1;

    gsM1Drive.sSpeed.f16SpeedCmd                                   = 0;

    /* Scalar control params */
    gsM1Drive.sScalarCtrl.f16VHzGain                               = SCALAR_VHZ_FACTOR_GAIN;
    gsM1Drive.sScalarCtrl.f16VHzGainShift                          = SCALAR_VHZ_FACTOR_SHIFT;
    gsM1Drive.sScalarCtrl.sFreqRampParams.f32RampUp                = SCALAR_RAMP_UP;
    gsM1Drive.sScalarCtrl.sFreqRampParams.f32RampDown              = SCALAR_RAMP_DOWN;
    gsM1Drive.sScalarCtrl.sFreqIntegrator.f16C1                    = SCALAR_INTEG_GAIN;
    gsM1Drive.sScalarCtrl.sFreqIntegrator.u16NShift                = SCALAR_INTEG_SHIFT;
    
    /* Open loop start up */
    gsM1Drive.sStartUp.sSpeedIntegrator.f16C1                      = SCALAR_INTEG_GAIN; 
    gsM1Drive.sStartUp.sSpeedIntegrator.u16NShift                  = SCALAR_INTEG_SHIFT;/* the shift in integrator is only positive */
    gsM1Drive.sStartUp.f16CoeffMerging                             = MERG_COEFF;
    gsM1Drive.sStartUp.f16SpeedCatchUp                             = MERG_SPEED_TRH;   
    gsM1Drive.sStartUp.f16CurrentStartup                           = OL_START_I;
    gsM1Drive.sStartUp.sSpeedRampOpenLoopParams.f32RampUp          = OL_START_RAMP_INC; 
    gsM1Drive.sStartUp.sSpeedRampOpenLoopParams.f32RampDown        = OL_START_RAMP_INC;
    gsM1Drive.sStartUp.bOpenLoop                                   = TRUE;

    /* MCAT cascade control variables */
    gsM1Drive.sMCATctrl.sIDQReqMCAT.f16D                           = 0;
    gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q                           = 0;
    gsM1Drive.sMCATctrl.sUDQReqMCAT.f16D                           = 0;
    gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q                           = 0;
    gsM1Drive.sMCATctrl.uw16PospeSensor                            = 0;

    /* Timing control and general variables */
    gsM1Drive.uw16CounterSlowLoop                                  = 0;
    gsM1Drive.uw16TimeSlowLoop                                     = SPEED_LOOP_CNTR;
    gsM1Drive.uw16CounterState                                     = 0;
    gsM1Drive.uw16TimeFullSpeedFreeWheel                           = FREEWHEEL_DURATION;
    gsM1Drive.uw16TimeCalibration                                  = CALIB_DURATION;
    gsM1Drive.uw16TimeFaultRelease                                 = FAULT_RELEASE_DURATION;
    mbM1SwitchAppOnOff                                             = FALSE;
    /* Default MCAT control mode after reset */
    gsM1Drive.eControl                                             = CONTROL_MODE_SPEED_FOC;

    /* fault set to init states */
    MC_FAULT_CLEAR_ALL(gsM1Drive.sFaultId);
    MC_FAULT_CLEAR_ALL(gsM1Drive.sFaultIdPending);
    uw16DriverFault                                                = 0;

    
    /* fault thresholds */
    gsM1Drive.sFaultThresholds.f16UDcBusOver                       = U_DCB_OVERVOLTAGE;
    gsM1Drive.sFaultThresholds.f16UDcBusUnder                      = U_DCB_UNDERVOLTAGE;
    gsM1Drive.sFaultThresholds.f16SpeedOver                        = N_OVERSPEED;
    gsM1Drive.sFaultThresholds.f16SpeedMin                         = N_MIN;
    gsM1Drive.sFaultThresholds.f16SpeedNom                         = N_NOM;
    
    /* Defined scaling for FreeMASTER */
    fltM1voltageScale                                              = U_MAX;
    fltM1currentScale                                              = I_MAX;
    fltM1DCBvoltageScale                                           = U_DCB_MAX;
    fltM1speedScale                                                = N_MAX;
    fltM1frequencyScale                                            = FREQ_MAX;
    
    /* Clear rest of variables  */
    M1_ClearFOCVariables();
    
    /* Filter init not to enter to fault */
    gsM1Drive.sFocPMSM.sUDcBusFilter.f16FiltBufferX[0] = (Frac16)((U_DCB_UNDERVOLTAGE/2.0) + (U_DCB_OVERVOLTAGE/2.0)); 
    gsM1Drive.sFocPMSM.sUDcBusFilter.f32FiltBufferY[0] = (Frac32)((U_DCB_UNDERVOLTAGE/2.0) + (U_DCB_OVERVOLTAGE/2.0)) << 16;

    
    /* INIT_DONE command */
    gsM1Ctrl.uiCtrl |= SM_CTRL_INIT_DONE;
}

/***************************************************************************//*!
*
* @brief   STOP state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateStop(void)
{
    /* Type the code to do when in the STOP state */
    /* read 3-phase motor currents */ /* otherwise the interrupt flag will not be cleared */
    SAC_Curr3Ph2ShGet(&msM1PhCurSensor);
    
    /* read DCBus voltage value */
    SAC_VoltDcBusGet(&msM1UDcBusSensor);
    gsM1Drive.sFocPMSM.f16UDcBusFilt = GDFLIB_FilterIIR1(gsM1Drive.sFocPMSM.f16UDcBus,&gsM1Drive.sFocPMSM.sUDcBusFilter);
    
//    bDemoMode = TRUE;
//    uw32SpeedStimulatorCnt = 0;
//    mbM1SwitchAppOnOff = TRUE;
    
    /* If the user switches on  or set non-zero speed*/
    if ((mbM1SwitchAppOnOff != 0) || (gsM1Drive.sSpeed.f16SpeedCmd != 0))
    {
      /* Set the swith on */
      mbM1SwitchAppOnOff = 1;  
      
      /* Start command */
        gsM1Ctrl.uiCtrl |= SM_CTRL_START;
    }
  
    M1_FaultDetection();
  
    /* If a fault occurred */
    if (gsM1Drive.sFaultIdPending)
    {
        /* Switches to the FAULT state */
        gsM1Ctrl.uiCtrl |= SM_CTRL_FAULT;    
    }
}

/***************************************************************************//*!
*
* @brief   RUN state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateRun(void)
{
    /* Type the code to do when in the RUN state */
    SAC_Curr3Ph2ShGet(&msM1PhCurSensor);
    
    /* read position and speed */
    SAC_PospeObsGet(&msM1PospeObs);
    
    /* read DCBus voltage value */
    SAC_VoltDcBusGet(&msM1UDcBusSensor);
    gsM1Drive.sFocPMSM.f16UDcBusFilt = GDFLIB_FilterIIR1(gsM1Drive.sFocPMSM.f16UDcBus,&gsM1Drive.sFocPMSM.sUDcBusFilter);     
        
    /* Run sub-state function */
    mM1_STATE_RUN_TABLE[meM1StateRun]();       
  
    /* PWM peripheral update */
    SAC_FtmPwm3PhSet(&msM1Pwm3ph);
    
    /* set current sensor for  sampling */
    SAC_Curr3Ph2ShChanAssign(&msM1PhCurSensor);
    
    /* If the user switches off */
    if (!mbM1SwitchAppOnOff)
    {
        /* Stop command */
        gsM1Ctrl.uiCtrl |= SM_CTRL_STOP;    
    }
        
    /* detect fault */
    M1_FaultDetection();
    
    /* If a fault occurred */
    if ( gsM1Drive.sFaultIdPending != 0)
    {
        /* Switches to the FAULT state */
        gsM1Ctrl.uiCtrl |= SM_CTRL_FAULT;    
    }
}

/***************************************************************************//*!
*
* @brief   FAULT to INIT transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransFaultInit(void)
{
    /* Type the code to do when going from the FAULT to the INIT state */
}

/***************************************************************************//*!
*
* @brief   INIT to FAULT transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransInitFault(void)
{  
    /* Type the code to do when going from the INIT to the FAULT state */
    /* Disable PWM output */
    SAC_FtmPwm3PhOutDis(&msM1Pwm3ph);
    
    gsM1Drive.sSpeed.f16SpeedCmd = 0;  
    /* init slow loop counter */
    gsM1Drive.uw16CounterSlowLoop = 1;
}

/***************************************************************************//*!
*
* @brief   INIT to STOP transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransInitStop(void)
{
    /* Type the code to do when going from the INIT to the STOP state */
    /* Disable PWM output */
    SAC_FtmPwm3PhOutDis(&msM1Pwm3ph);

    /* Enable Open loop start up */
    gsM1Drive.sStartUp.bOpenLoop   = TRUE;
    /* SAC module inner variable */
    msM1PospeObs.bOpenLoop = TRUE;
    
    /* Init filters */
    GDFLIB_FilterIIR1Init(&gsM1Drive.sSpeed.sSpeedFilter);
}

/***************************************************************************//*!
*
* @brief   STOP to FAULT transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransStopFault(void)
{
    /* Type the code to do when going from the STOP to the FAULT state */
    gsM1Drive.sFaultId = gsM1Drive.sFaultIdPending;
    gsM1Drive.uw16CounterState = gsM1Drive.uw16TimeFaultRelease;   
    
    /* init slow loop counter */
    gsM1Drive.uw16CounterSlowLoop = 1;
}

/***************************************************************************//*!
*
* @brief   STOP to RUN transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransStopRun(void)
{        
    /* Type the code to do when going from the STOP to the RUN state */
    /* 50% duty cycle */  
    gsM1Drive.sFocPMSM.sDutyABC.f16A = FRAC16(0.5); 
    gsM1Drive.sFocPMSM.sDutyABC.f16B = FRAC16(0.5);
    gsM1Drive.sFocPMSM.sDutyABC.f16C = FRAC16(0.5);         
        
    /* PWM duty cycles calculation */
    
    /* PWM duty cycles calculation and update*/
    SAC_FtmPwm3PhSet(&msM1Pwm3ph);    
    
    /* Clear offset filters */
    SAC_Curr3Ph2ShCalibInit(&msM1PhCurSensor);
    
    /* Enable PWM output */
    SAC_FtmPwm3PhOutEn(&msM1Pwm3ph);
    
    /* pass calibration routine duration to state counter*/
    gsM1Drive.uw16CounterState = gsM1Drive.uw16TimeCalibration;

    /* init slow loop counter  */
    gsM1Drive.uw16CounterSlowLoop = 1;
        
    /* Calibration sub-state when transition to RUN */
    meM1StateRun = CALIB;
                
    /* Acknoledge that the system can proceed into the RUN state */
    gsM1Ctrl.uiCtrl |= SM_CTRL_RUN_ACK;
}

/***************************************************************************//*!
*
* @brief   RUN to FAULT transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunFault(void)
{
    /* Type the code to do when going from the RUN to the FAULT state */
    /* Disable PWM output */
    SAC_FtmPwm3PhOutDis(&msM1Pwm3ph);

    /* clear over load flag */
    gsM1Drive.sSpeed.i16SpeedPiSatFlag = 0;

    /* init slow loop counter */
    gsM1Drive.uw16CounterSlowLoop = 1;

    gsM1Drive.sSpeed.f16SpeedReq               = 0;
    gsM1Drive.sSpeed.f16SpeedCmd               = 0;
    gsM1Drive.sScalarCtrl.f32FreqCmd           = 0;
    gsM1Drive.sScalarCtrl.sUDQReq.f16Q         = 0;
    gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q       = 0;
    gsM1Drive.sMCATctrl.sUDQReqMCAT.f16D       = 0;
    gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q       = 0;
    gsM1Drive.sMCATctrl.sIDQReqMCAT.f16D       = 0;

    /* Clear actual speed values */
    gsM1Drive.sScalarCtrl.f16FreqRamp          = 0;
    gsM1Drive.sSpeed.f16Speed                  = 0;
    gsM1Drive.sSpeed.f16SpeedFilt              = 0;
}

/***************************************************************************//*!
*
* @brief   RUN to STOP transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunStop(void)
{  
    /* Type the code to do when going from the RUN to the STOP state */
    /* Disable PWM output */
    SAC_FtmPwm3PhOutDis(&msM1Pwm3ph);
                        
    gsM1Drive.sSpeed.f16SpeedReq               = 0;
    gsM1Drive.sSpeed.f16SpeedCmd               = 0;
    gsM1Drive.sScalarCtrl.f32FreqCmd           = 0;
    gsM1Drive.sScalarCtrl.sUDQReq.f16Q         = 0;
    gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q       = 0;
    gsM1Drive.sMCATctrl.sUDQReqMCAT.f16D       = 0;
    gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q       = 0;
    gsM1Drive.sMCATctrl.sIDQReqMCAT.f16D       = 0;

    M1_ClearFOCVariables();
    /* Acknowledge that the system can proceed into the STOP state */
    gsM1Ctrl.uiCtrl |= SM_CTRL_STOP_ACK;
}

/***************************************************************************//*!
*
* @brief   RUN CALIB sub-state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateRunCalib(void)
{     
    /* Type the code to do when in the RUN CALIB sub-state */
    /* performing ADC offset calibration */
    
    /* call offset measurement */
    SAC_Curr3Ph2ShCalib(&msM1PhCurSensor);

    /* change SVM sector in range <1;6> to measure all AD channel mapping combinations */
    if(++gsM1Drive.sFocPMSM.uw16SectorSVM > 6)
            gsM1Drive.sFocPMSM.uw16SectorSVM = 1;

    /* Slow loop */
    if (--gsM1Drive.uw16CounterSlowLoop==0)
    {      
        /* initialize speed loop counter */
        gsM1Drive.uw16CounterSlowLoop = gsM1Drive.uw16TimeSlowLoop;  
        
        if(--gsM1Drive.uw16CounterState == 0)
        {
            /* write calibrated offset values */
            SAC_Curr3Ph2ShCalibSet(&msM1PhCurSensor);
        
            /* To switch to the RUN READY sub-state */
            M1_TransRunCalibReady();              
        }    
    }
}

/***************************************************************************//*!
*
* @brief   RUN READY sub-state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateRunReady(void)
{
    /* Type the code to do when in the RUN READY sub-state */
    /* Clear actual speed values */
    gsM1Drive.sScalarCtrl.f16FreqRamp   = 0;
    gsM1Drive.sSpeed.f16Speed           = 0;
    gsM1Drive.sSpeed.f16SpeedFilt       = 0;
    /* SAC module inner variables */
    msM1PospeObs.f16PosElEst            = 0; 
    msM1PospeObs.f16SpeedElEst          = 0; 
        
    /* MCAT control structure switch */
    switch (gsM1Drive.eControl)
    {
    case CONTROL_MODE_SCALAR: 
        if (!(gsM1Drive.sScalarCtrl.f32FreqCmd == 0))
        {
            gsM1Drive.sScalarCtrl.f16FreqRamp    = 0;
            gsM1Drive.sScalarCtrl.sUDQReq.f16Q   = 0;
            /* Transition to the RUN ALIGN sub-state */
            M1_TransRunReadyAlign();
        }
        break;
        
    case CONTROL_MODE_VOLTAGE_FOC:
        if (!(gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q == 0 ))
        {
            if(gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q > 0)
                gsM1Drive.sSpeed.f16SpeedCmd = MLIB_ShLSat_F16(gsM1Drive.sStartUp.f16SpeedCatchUp, 1);
            else
                gsM1Drive.sSpeed.f16SpeedCmd = MLIB_Neg_F16(MLIB_ShLSat_F16(gsM1Drive.sStartUp.f16SpeedCatchUp, 1));
           
            /* Transition to the RUN ALIGN sub-state */
            M1_TransRunReadyAlign();
        }
        break;                      
        
    case CONTROL_MODE_CURRENT_FOC:        
        if (!(gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q == 0 ))
        {
            if(gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q > 0)
                gsM1Drive.sSpeed.f16SpeedCmd = MLIB_ShLSat_F16(gsM1Drive.sStartUp.f16SpeedCatchUp,1);
            else
                gsM1Drive.sSpeed.f16SpeedCmd = MLIB_Neg_F16(MLIB_ShLSat_F16(gsM1Drive.sStartUp.f16SpeedCatchUp,1)); 
            
            /* Transition to the RUN ALIGN sub-state */
            M1_TransRunReadyAlign();
        }
        break;                 
    case CONTROL_MODE_SPEED_FOC:
    default: 
        if((MLIB_AbsSat_F16(gsM1Drive.sSpeed.f16SpeedCmd) > gsM1Drive.sFaultThresholds.f16SpeedMin)&&\
          (MLIB_AbsSat_F16(gsM1Drive.sSpeed.f16SpeedCmd) <= gsM1Drive.sFaultThresholds.f16SpeedNom))
        {
            /* Transition to the RUN ALIGN sub-state */
            M1_TransRunReadyAlign();                    
        }   
        else
        {
            gsM1Drive.sSpeed.f16SpeedCmd = 0;
        }                        
    }
}

/***************************************************************************//*!
*
* @brief   RUN ALIGN sub-state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateRunAlign(void)
{
    /* Type the code to do when in the RUN ALIGN sub-state */
    /* clear actual speed values */
    gsM1Drive.sScalarCtrl.f16FreqRamp           = 0;
    gsM1Drive.sSpeed.f16Speed                   = 0;
    gsM1Drive.sSpeed.f16SpeedFilt               = 0;   
    /* SAC module inner variables */
    msM1PospeObs.f16PosElEst                    = 0; 
    msM1PospeObs.f16SpeedElEst                  = 0; 
    
    MCS_PMSMAlignmentA1(&gsM1Drive.sFocPMSM, &gsM1Drive.sAlignment); 
    
    /* Slow loop */
    if (--gsM1Drive.uw16CounterSlowLoop==0)
    {
        /* initialize speed loop counter */
        gsM1Drive.uw16CounterSlowLoop = gsM1Drive.uw16TimeSlowLoop;
      
        if(--gsM1Drive.uw16CounterState==0)
        {
            /* Transition to the RUN STARTUP sub-state */
            M1_TransRunAlignStartup();
        }
    }
}

/***************************************************************************//*!
*
* @brief   RUN STARTUP sub-state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateRunStartup(void)
{
    /* If f16SpeedCmd ==  0, go to Freewheel state */
    if((gsM1Drive.sSpeed.f16SpeedCmd==0) && (gsM1Drive.eControl==CONTROL_MODE_SPEED_FOC))
        M1_TransRunStartupFreewheel();
  
    /* Type the code to do when in the RUN STARTUP sub-state */
    /* pass actual estimation position to OL startup structure */
    gsM1Drive.sStartUp.f16PosEst =  gsM1Drive.sFocPMSM.f16PosElReload;
    
    /*open loop startup */  
    MCS_PMSMOpenLoopStartUpA1(&gsM1Drive.sStartUp);

    /* Pass f16SpeedRampOpenloop to f16SpeedRamp*/
    gsM1Drive.sSpeed.f16SpeedRamp = gsM1Drive.sStartUp.f16SpeedRampOpenLoop;
    
    /* Position and speed for FOC */
    gsM1Drive.sFocPMSM.f16PosElReload    = gsM1Drive.sStartUp.f16PosMerged;

    /* MCAT control structure switch */
    switch (gsM1Drive.eControl)
    {
    case CONTROL_MODE_SCALAR: 
        /* switch directly to SPIN state */
        M1_TransRunStartupSpin();
        break;      
            
    case CONTROL_MODE_VOLTAGE_FOC:      
        /* pass MCAT required values in run-time */
        gsM1Drive.sFocPMSM.sUDQReq.f16D = gsM1Drive.sMCATctrl.sUDQReqMCAT.f16D;
        gsM1Drive.sFocPMSM.sUDQReq.f16Q = gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q;
        /* FOC */
        MCS_PMSMFocCtrlVoltageA1(&gsM1Drive.sFocPMSM);
        break;  
   
    case CONTROL_MODE_CURRENT_FOC:
        /* FOC */
        gsM1Drive.sFocPMSM.sIDQReq.f16D = gsM1Drive.sMCATctrl.sIDQReqMCAT.f16D;
        gsM1Drive.sFocPMSM.sIDQReq.f16Q = gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q;
        MCS_PMSMFocCtrlCurrentA1(&gsM1Drive.sFocPMSM);
        break;                 
    
    case CONTROL_MODE_SPEED_FOC:
        default:
        /* FOC */
        if(!(gsM1Drive.sSpeed.f16SpeedCmd==0))
        {
            /* Speed loop control */
            if (--gsM1Drive.uw16CounterSlowLoop==0)
            {
                /* initialize speed loop counter */
                gsM1Drive.uw16CounterSlowLoop = gsM1Drive.uw16TimeSlowLoop;

                /* actual speed filter */
                gsM1Drive.sSpeed.f16SpeedFilt = GDFLIB_FilterIIR1(gsM1Drive.sSpeed.f16Speed,&gsM1Drive.sSpeed.sSpeedFilter);

                /* pass required speed values lower than nominal speed */
                if((MLIB_AbsSat_F16(gsM1Drive.sSpeed.f16SpeedCmd) > gsM1Drive.sFaultThresholds.f16SpeedNom))
                {
                    /* set required speed to nominal speed if over speed command > speed nominal */
                    if(gsM1Drive.sSpeed.f16SpeedCmd>0)
                        gsM1Drive.sSpeed.f16SpeedCmd = gsM1Drive.sFaultThresholds.f16SpeedNom;
                    else
                        gsM1Drive.sSpeed.f16SpeedCmd = MLIB_Neg_F16(gsM1Drive.sFaultThresholds.f16SpeedNom);
                }

                gsM1Drive.sSpeed.f16SpeedReq = gsM1Drive.sSpeed.f16SpeedCmd;
            }                  
        }
        /* Curent control loop */
        gsM1Drive.sFocPMSM.sIDQReq.f16D = 0;
               
        /* during the open loop start up the values of required Iq current are kept in pre-defined level*/            
        if(gsM1Drive.sSpeed.f16SpeedReq > 0)
            gsM1Drive.sFocPMSM.sIDQReq.f16Q = gsM1Drive.sStartUp.f16CurrentStartup;
        else
            gsM1Drive.sFocPMSM.sIDQReq.f16Q = MLIB_Neg_F16(gsM1Drive.sStartUp.f16CurrentStartup);
      
        MCS_PMSMFocCtrlCurrentA1(&gsM1Drive.sFocPMSM);
        break;
    }
    
    /* switch to close loop  */
    if (!gsM1Drive.sStartUp.bOpenLoop)
    {
        M1_TransRunStartupSpin();
    }
}
/***************************************************************************//*!
*
* @brief   RUN SPIN sub-state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateRunSpin(void)
{
    /* Type the code to do when in the RUN SPIN sub-state */
    /* MCAT control structure switch */
    switch (gsM1Drive.eControl)
    {
    case CONTROL_MODE_SCALAR: 
        /* scalar function call */
        MCS_PMSMScalarCtrlA1(&gsM1Drive.sFocPMSM, &gsM1Drive.sScalarCtrl);
            
        /* pass required voltages to Bemf Observer to work */
        gsM1Drive.sFocPMSM.sUDQReq.f16Q = gsM1Drive.sScalarCtrl.sUDQReq.f16Q; 
        gsM1Drive.sFocPMSM.sUDQReq.f16D = gsM1Drive.sScalarCtrl.sUDQReq.f16D;        
            
        /* Sub-state RUN FREEWHEEL */
        if(gsM1Drive.sScalarCtrl.f32FreqCmd==0)
               M1_TransRunSpinFreewheel();                      
        break;

    case CONTROL_MODE_VOLTAGE_FOC:
        /* FOC */
        gsM1Drive.sFocPMSM.sUDQReq.f16Q = gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q;
        gsM1Drive.sFocPMSM.sUDQReq.f16D = gsM1Drive.sMCATctrl.sUDQReqMCAT.f16D;
        MCS_PMSMFocCtrlVoltageA1(&gsM1Drive.sFocPMSM);
            
        /* Sub-state RUN FREEWHEEL */
        if(gsM1Drive.sMCATctrl.sUDQReqMCAT.f16Q==0)
            M1_TransRunSpinFreewheel();
            break;                      

    case CONTROL_MODE_CURRENT_FOC:        
        /* FOC */
        gsM1Drive.sFocPMSM.sIDQReq.f16Q = gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q;
        gsM1Drive.sFocPMSM.sIDQReq.f16D = gsM1Drive.sMCATctrl.sIDQReqMCAT.f16D;
        MCS_PMSMFocCtrlCurrentA1(&gsM1Drive.sFocPMSM);
            
        /* Sub-state RUN FREEWHEEL */
        if(gsM1Drive.sMCATctrl.sIDQReqMCAT.f16Q==0)
            M1_TransRunSpinFreewheel();
        break;
            
    case CONTROL_MODE_SPEED_FOC:
    default: 
        /* Speed loop control */
        if (--gsM1Drive.uw16CounterSlowLoop==0)
        {
            /* initialize speed loop counter */
            gsM1Drive.uw16CounterSlowLoop = gsM1Drive.uw16TimeSlowLoop;
          
            /* actual speed filter */
            gsM1Drive.sSpeed.f16SpeedFilt = GDFLIB_FilterIIR1(gsM1Drive.sSpeed.f16Speed,&gsM1Drive.sSpeed.sSpeedFilter);

            /* speed reverse */
            if(((gsM1Drive.sSpeed.f16SpeedCmd>gsM1Drive.sFaultThresholds.f16SpeedMin)&&\
                (gsM1Drive.sSpeed.f16SpeedReq>gsM1Drive.sFaultThresholds.f16SpeedMin))||\
                ((gsM1Drive.sSpeed.f16SpeedCmd<MLIB_Neg_F16(gsM1Drive.sFaultThresholds.f16SpeedMin))&&\
                (gsM1Drive.sSpeed.f16SpeedReq<MLIB_Neg_F16(gsM1Drive.sFaultThresholds.f16SpeedMin))))
            {    
                /* pass required speed values lower than nominal speed */
                if((MLIB_AbsSat_F16(gsM1Drive.sSpeed.f16SpeedCmd) > gsM1Drive.sFaultThresholds.f16SpeedNom))
                {    
                    /* set required speed to nominal speed if over speed command > speed nominal */
                    if(gsM1Drive.sSpeed.f16SpeedCmd>0)
                        gsM1Drive.sSpeed.f16SpeedCmd = gsM1Drive.sFaultThresholds.f16SpeedNom;
                    else
                        gsM1Drive.sSpeed.f16SpeedCmd = MLIB_Neg_F16(gsM1Drive.sFaultThresholds.f16SpeedNom);
                }

                gsM1Drive.sSpeed.f16SpeedReq = gsM1Drive.sSpeed.f16SpeedCmd;
            }
            else
            {
                gsM1Drive.sSpeed.f16SpeedReq = 0;
                if(MLIB_AbsSat_F16(gsM1Drive.sSpeed.f16SpeedRamp)<(gsM1Drive.sFaultThresholds.f16SpeedMin))
                    M1_TransRunSpinFreewheel();
            } 
          
            /* call PMSM speed control */
            MCS_PMSMFocCtrlSpeedA1(&gsM1Drive.sFocPMSM, &gsM1Drive.sSpeed);
        }                  
        
        if(MLIB_AbsSat_F16(gsM1Drive.sSpeed.f16SpeedRamp) < gsM1Drive.sFaultThresholds.f16SpeedMin)
        {
            /* Sub-state RUN FREEWHEEL */
            M1_TransRunSpinFreewheel();
        }
  
        /* FOC */
        MCS_PMSMFocCtrlCurrentA1(&gsM1Drive.sFocPMSM);
        break;
    }
}

/***************************************************************************//*!
*
* @brief   RUN FREEWHEEL sub-state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_StateRunFreewheel(void)
{        
    /* Type the code to do when in the RUN FREEWHEEL sub-state */

    /* clear actual speed values */
    gsM1Drive.sScalarCtrl.f16FreqRamp       = 0;
    gsM1Drive.sSpeed.f16Speed               = 0;
    gsM1Drive.sSpeed.f16SpeedFilt           = 0;  
    gsM1Drive.sSpeed.f16SpeedRamp           = 0;
    gsM1Drive.sSpeed.f16SpeedReq            = 0;

    /* Slow loop */
    if (--gsM1Drive.uw16CounterSlowLoop==0)
    {
        /* initialize speed loop counter */
        gsM1Drive.uw16CounterSlowLoop = gsM1Drive.uw16TimeSlowLoop;

        if (--gsM1Drive.uw16CounterState == 0)
        {
            /* Sub-state RUN READY */
            M1_TransRunFreewheelReady();
        }        
    }
}

/***************************************************************************//*!
*
* @brief   RUN CALIB to READY transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunCalibReady(void)
{
    /* Type the code to do when going from the RUN CALIB to the RUN READY sub-state */

    /* set 50% PWM duty cycle */
    gsM1Drive.sFocPMSM.sDutyABC.f16A = FRAC16(0.5); 
    gsM1Drive.sFocPMSM.sDutyABC.f16B = FRAC16(0.5);
    gsM1Drive.sFocPMSM.sDutyABC.f16C = FRAC16(0.5);   
    
    /* init slow loop counter  */
    gsM1Drive.uw16CounterSlowLoop = 1;        
    
    /* swith to sub state READY */
    meM1StateRun = READY;
}

/***************************************************************************//*!
*
* @brief   RUN READY to ALIGN transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunReadyAlign(void)
{
    /* Type the code to do when going from the RUN READY to the RUN ALIGN sub-state */
    /* Alignment duration set-up */
    gsM1Drive.uw16CounterState = gsM1Drive.sAlignment.uw16Time;
    /* Counter of half alignment duration */
    gsM1Drive.sAlignment.uw16TimeHalf = MLIB_ShR_F16(gsM1Drive.sAlignment.uw16Time, 1) * gsM1Drive.uw16TimeSlowLoop;

    /* init slow loop counter  */
    gsM1Drive.uw16CounterSlowLoop = 1;
        
    /* set required alignment voltage to Ud */
    gsM1Drive.sFocPMSM.sUDQReq.f16D = gsM1Drive.sAlignment.f16UdReq; 
    gsM1Drive.sFocPMSM.sUDQReq.f16Q = 0;    

    /* Sub-state RUN ALIGN */
    meM1StateRun = ALIGN;
}

/***************************************************************************//*!
*
* @brief   RUN ALIGN to STARTUP transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunAlignStartup(void)
{
    /* Type the code to do when going from the RUN ALIGN to the RUN STARTUP sub-state */
    /* clear application parameters */
    M1_ClearFOCVariables();
            
    /* pass required speed to open loop start-up structure */
    if(gsM1Drive.sSpeed.f16SpeedCmd > 0)
    {
        gsM1Drive.sStartUp.f32SpeedReq = MLIB_ShLSat_F32((Frac32)gsM1Drive.sStartUp.f16SpeedCatchUp,16); 
    }
    else
    {
        gsM1Drive.sStartUp.f32SpeedReq = MLIB_Neg_F32(MLIB_ShLSat_F32((Frac32)gsM1Drive.sStartUp.f16SpeedCatchUp,16)); 
    }
    /* enable Open loop mode in main control structure */
    gsM1Drive.sStartUp.bOpenLoop        = TRUE;    
    /* enable Open loop mode in SAC module */
    msM1PospeObs.bOpenLoop           = TRUE;
    
    /* init slow loop counter  */    
    gsM1Drive.uw16CounterSlowLoop       = 1;
    gsM1Drive.sFocPMSM.uw16SectorSVM    = SVM_SECTOR_DEFAULT;
    GDFLIB_FilterIIR1Init(&gsM1Drive.sSpeed.sSpeedFilter);       
                            
    /* To switch to the RUN STARTUP sub-state */
    meM1StateRun = STARTUP;
}


/***************************************************************************//*!
*
* @brief   RUN STARTUP to SPIN transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunStartupSpin(void)
{
    /* Type the code to do when going from the RUN STARTUP to the RUN SPIN sub-state */
    /* for FOC control switch open loop off in DQ observer */
    if(gsM1Drive.eControl!=CONTROL_MODE_SCALAR)
        msM1PospeObs.bOpenLoop = FALSE; // disable openl loop mode in SAC module
   
    gsM1Drive.sSpeed.sSpeedPiParams.f32IntegPartK_1 = MLIB_ShL_F32((Frac32)gsM1Drive.sFocPMSM.sIDQReq.f16Q, 16); 
    gsM1Drive.sSpeed.sSpeedRampParams.f32State = MLIB_ShL_F32((Frac32)gsM1Drive.sStartUp.f16SpeedRampOpenLoop, 16);
    
    /* To switch to the RUN SPIN sub-state */
    meM1StateRun = SPIN;
}

/***************************************************************************//*!
*
* @brief   RUN STARTUP to FREEWHEEL transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunStartupFreewheel(void)
{
    SAC_FtmPwm3PhOutDis(&msM1Pwm3ph);
          
    /* Freewheel duration set-up */
    gsM1Drive.uw16CounterState = gsM1Drive.uw16TimeFullSpeedFreeWheel;;
    /* Sub-state RUN FREEWHEEL */
    meM1StateRun = FREEWHEEL;
}

/***************************************************************************//*!
*
* @brief   RUN SPIN to FREEWHEEL transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunSpinFreewheel(void)
{
    /* Type the code to do when going from the RUN SPIN to the RUN FREEWHEEL sub-state */
    /* set 50% PWM duty cycle */
    gsM1Drive.sFocPMSM.sDutyABC.f16A = FRAC16(0.5); 
    gsM1Drive.sFocPMSM.sDutyABC.f16B = FRAC16(0.5);
    gsM1Drive.sFocPMSM.sDutyABC.f16C = FRAC16(0.5);

    /* init slow loop counter  */
    gsM1Drive.uw16CounterSlowLoop = 1;
    
    gsM1Drive.sFocPMSM.uw16SectorSVM = SVM_SECTOR_DEFAULT;

    SAC_FtmPwm3PhOutDis(&msM1Pwm3ph);
            
    /* Generates a time gap before the alignment to assure the rotor is not rotating */
    gsM1Drive.uw16CounterState = gsM1Drive.uw16TimeFullSpeedFreeWheel;                

    gsM1Drive.sFocPMSM.sIDQReq.f16D         = 0;
    gsM1Drive.sFocPMSM.sIDQReq.f16Q         = 0;

    gsM1Drive.sFocPMSM.sUDQReq.f16D         = 0;
    gsM1Drive.sFocPMSM.sUDQReq.f16Q         = 0;    

    gsM1Drive.sFocPMSM.sIAlBe.f16Alpha      = 0;
    gsM1Drive.sFocPMSM.sIAlBe.f16Beta       = 0;
    gsM1Drive.sFocPMSM.sUAlBeReq.f16Alpha   = 0;
    gsM1Drive.sFocPMSM.sUAlBeReq.f16Beta    = 0;    
    gsM1Drive.sFocPMSM.sUAlBeComp.f16Alpha  = 0;
    gsM1Drive.sFocPMSM.sUAlBeComp.f16Beta   = 0;    

    /* Sub-state RUN FREEWHEEL */
    meM1StateRun = FREEWHEEL;    
}




/***************************************************************************//*!
*
* @brief   RUN FREEWHEEL to READY transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_TransRunFreewheelReady(void)
{
    /* Type the code to do when going from the RUN FREEWHEEL to the RUN READY sub-state */
    /* clear application parameters */
    M1_ClearFOCVariables();
    /* Type the code to do when going from the RUN FREEWHEEL to the RUN READY sub-state */
    SAC_FtmPwm3PhOutEn(&msM1Pwm3ph);
    
    /* init slow loop counter  */
    gsM1Drive.uw16CounterSlowLoop = 1;       
    
    /* Sub-state RUN READY */
    meM1StateRun = READY;
}

/******************************************************************************
* Global functions
******************************************************************************/

/***************************************************************************//*!
*
* @brief   Fault Detection function
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_FaultDetection(void)
{    
    /* Clearing actual faults before detecting them again  */         
    /* Clear all faults */
    MC_FAULT_CLEAR_ALL(gsM1Drive.sFaultIdPending);
    
    /* Fault:   DC-bus over-current */
    if(FTM0_FMS & FTM_FMS_FAULTF0_MASK)
        MC_FAULT_SET(gsM1Drive.sFaultIdPending, MC_FAULT_I_DCBUS_OVER);
    
    /* Fault:   DC-bus over-voltage */
    if(gsM1Drive.sFocPMSM.f16UDcBusFilt > gsM1Drive.sFaultThresholds.f16UDcBusOver)
        MC_FAULT_SET(gsM1Drive.sFaultIdPending, MC_FAULT_U_DCBUS_OVER);

    /* Fault:   DC-bus under-voltage */
    if(gsM1Drive.sFocPMSM.f16UDcBusFilt < gsM1Drive.sFaultThresholds.f16UDcBusUnder)
        MC_FAULT_SET(gsM1Drive.sFaultIdPending, MC_FAULT_U_DCBUS_UNDER);
 
    /* Fault: Overload  */
    if ((MLIB_AbsSat(gsM1Drive.sSpeed.f16SpeedFilt) < gsM1Drive.sFaultThresholds.f16SpeedMin) &&\
        (MLIB_AbsSat(gsM1Drive.sSpeed.f16SpeedRamp) > gsM1Drive.sFaultThresholds.f16SpeedMin) &&\
        (gsM1Drive.sSpeed.i16SpeedPiSatFlag > 0))
            MC_FAULT_SET(gsM1Drive.sFaultIdPending, MC_FAULT_LOAD_OVER);
                    
    
    /* Fault: Over-speed  */
    if ((MLIB_AbsSat(gsM1Drive.sSpeed.f16SpeedFilt) > gsM1Drive.sFaultThresholds.f16SpeedOver) &&\
        (MLIB_AbsSat(gsM1Drive.sSpeed.f16SpeedCmd) > gsM1Drive.sFaultThresholds.f16SpeedMin))
            MC_FAULT_SET(gsM1Drive.sFaultIdPending, MC_FAULT_SPEED_OVER);  

    /* pass fault to Fault ID */
    gsM1Drive.sFaultId |= gsM1Drive.sFaultIdPending; 
}

/***************************************************************************//*!
*
* @brief  Clear FOC variables
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void M1_ClearFOCVariables(void)
{
    gsM1Drive.sAlignment.uw16TimeHalf                      = 0;

    gsM1Drive.sFocPMSM.sIABC.f16A                          = 0;
    gsM1Drive.sFocPMSM.sIABC.f16B                          = 0;
    gsM1Drive.sFocPMSM.sIABC.f16C                          = 0;
    gsM1Drive.sFocPMSM.sIAlBe.f16Alpha                     = 0;
    gsM1Drive.sFocPMSM.sIAlBe.f16Beta                      = 0;
    gsM1Drive.sFocPMSM.sIDQ.f16D                           = 0;
    gsM1Drive.sFocPMSM.sIDQ.f16Q                           = 0;
    gsM1Drive.sFocPMSM.sIDQReq.f16D                        = 0;
    gsM1Drive.sFocPMSM.sIDQReq.f16Q                        = 0;
    gsM1Drive.sFocPMSM.sIDQError.f16D                      = 0;
    gsM1Drive.sFocPMSM.sIDQError.f16Q                      = 0;
    gsM1Drive.sFocPMSM.sDutyABC.f16A                       = FRAC16(0.5);
    gsM1Drive.sFocPMSM.sDutyABC.f16B                       = FRAC16(0.5);
    gsM1Drive.sFocPMSM.sDutyABC.f16C                       = FRAC16(0.5);
    gsM1Drive.sFocPMSM.sUAlBeReq.f16Alpha                  = 0;
    gsM1Drive.sFocPMSM.sUAlBeReq.f16Beta                   = 0;
    gsM1Drive.sFocPMSM.sUAlBeComp.f16Alpha                 = 0;
    gsM1Drive.sFocPMSM.sUAlBeComp.f16Beta                  = 0;
    gsM1Drive.sFocPMSM.sUDQReq.f16D                        = 0;
    gsM1Drive.sFocPMSM.sUDQReq.f16Q                        = 0;
    gsM1Drive.sFocPMSM.sAnglePosEl.f16Sin                  = 0;
    gsM1Drive.sFocPMSM.sAnglePosEl.f16Cos                  = 0;
    gsM1Drive.sFocPMSM.sAnglePosElReload.f16Sin            = 0;
    gsM1Drive.sFocPMSM.sAnglePosElReload.f16Cos            = 0;
    gsM1Drive.sFocPMSM.i16IdPiSatFlag                      = 0;
    gsM1Drive.sFocPMSM.i16IqPiSatFlag                      = 0;
    gsM1Drive.sFocPMSM.sIdPiParams.u16LimitFlag            = 0;
    gsM1Drive.sFocPMSM.sIqPiParams.u16LimitFlag            = 0;
    gsM1Drive.sFocPMSM.sIdPiParams.f32IntegPartK_1         = 0;
    gsM1Drive.sFocPMSM.sIdPiParams.f16InK_1                = 0;
    gsM1Drive.sFocPMSM.sIqPiParams.f32IntegPartK_1         = 0;
    gsM1Drive.sFocPMSM.sIqPiParams.f16InK_1                = 0;
    
    gsM1Drive.sSpeed.sSpeedRampParams.f32State             = 0;
    gsM1Drive.sSpeed.f16Speed                              = 0;
    gsM1Drive.sSpeed.f16SpeedFilt                          = 0;
    gsM1Drive.sSpeed.f16SpeedError                         = 0;
    gsM1Drive.sSpeed.f16SpeedRamp                          = 0;    
    gsM1Drive.sSpeed.sSpeedPiParams.f32IntegPartK_1        = 0;
    gsM1Drive.sSpeed.sSpeedPiParams.u16LimitFlag           = 0;
    gsM1Drive.sSpeed.sSpeedFilter.f16FiltBufferX[0]        = 0;
    gsM1Drive.sSpeed.sSpeedFilter.f32FiltBufferY[0]        = 0;

    gsM1Drive.sScalarCtrl.f16FreqRamp                      = 0;
    gsM1Drive.sScalarCtrl.f16PosElScalar                   = 0;
    gsM1Drive.sScalarCtrl.sUDQReq.f16D                     = 0;
    gsM1Drive.sScalarCtrl.sUDQReq.f16Q                     = 0;
    gsM1Drive.sScalarCtrl.sFreqIntegrator.f32State         = 0;
    gsM1Drive.sScalarCtrl.sFreqIntegrator.f16InK1          = 0;

    gsM1Drive.sStartUp.f16PosMerged                        = 0;
    gsM1Drive.sStartUp.f16PosEst                           = 0;
    gsM1Drive.sStartUp.f16PosGen                           = 0; 
    gsM1Drive.sStartUp.f16RatioMerging                     = 0;
    gsM1Drive.sStartUp.f16SpeedRampOpenLoop                = 0;
    gsM1Drive.sStartUp.f32SpeedReq                         = 0;
    gsM1Drive.sStartUp.sSpeedIntegrator.f32State           = 0;
    gsM1Drive.sStartUp.sSpeedIntegrator.f16InK1            = 0;
    gsM1Drive.sStartUp.sSpeedRampOpenLoopParams.f32State   = 0;

    /* Clear observer */
    SAC_PospeObsClear(&msM1PospeObs);
}
/***************************************************************************//*!
*
* @brief   Set the app switch function
*
* @param   void
*
* @return  none
*
******************************************************************************/
void M1_SetAppSwitch(bool bValue)
{
    mbM1SwitchAppOnOff = bValue;
}

/***************************************************************************//*!
*
* @brief   Read the app switch function
*
* @param   void
*
* @return  none
*
******************************************************************************/
bool M1_GetAppSwitch()
{
    return (mbM1SwitchAppOnOff);
}

/***************************************************************************//*!
*
* @brief   Set the speed command function
*
* @param   void
*
* @return  none
*
******************************************************************************/
void M1_SetSpeed(Frac16 f16SpeedCmd)
{
    if (mbM1SwitchAppOnOff)
    {
        /* Set speed */
        if (MLIB_Abs_F16(f16SpeedCmd) < gsM1Drive.sStartUp.f16SpeedCatchUp)
        {
            gsM1Drive.sSpeed.f16SpeedCmd = 0;
        }
        else if (MLIB_Abs_F16(f16SpeedCmd) > N_NOM)
        {
            gsM1Drive.sSpeed.f16SpeedReq = 0;
        }
        else
        {
            gsM1Drive.sSpeed.f16SpeedCmd = f16SpeedCmd;    
        }
    }
    else
    {    
        /* Set zero speed */
        gsM1Drive.sSpeed.f16SpeedReq = 0;
    }
}

/***************************************************************************//*!
*
* @brief   Get the speed command function
*
* @param   void
*
* @return  none
*
******************************************************************************/
Frac16 M1_GetSpeed(void)
{
    /* reurn speed */
    return gsM1Drive.sSpeed.f16SpeedCmd;
}

/*
 *######################################################################
 *                           End of File
 *######################################################################
*/
