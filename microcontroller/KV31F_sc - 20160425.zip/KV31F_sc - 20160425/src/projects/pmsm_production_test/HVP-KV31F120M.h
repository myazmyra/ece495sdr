/*
* Copyright 2015 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     HVP-KV31F120M.h
*
* @brief    Kinetis HVP-KV31F120M CPU card definitions
*
******************************************************************************/
#ifndef __HVP_KV31F120M_H__
#define __HVP_KV31F120M_H__

/******************************************************************************
* Includes
******************************************************************************/
#include "mcg.h"

/******************************************************************************
* Macros
******************************************************************************/

/* Define core frequency */
// Note: Only informative value - see sysinit.c for more details


#endif /* __HVP_KV31F120M_H__ */
