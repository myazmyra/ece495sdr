/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     pospe_enc.h
*
* @brief    A header file of position and speed of SAC module for quadrature encoder
*
* @board    TWR-KV31F120M
*
******************************************************************************/

#ifndef POSPE_ENC_H_
#define POSPE_ENC_H_

#include "sac_defines.h"

/******************************************************************************
| defines and macros
|----------------------------------------------------------------------------*/
/******************************************************************************
| typedefs and structures
|----------------------------------------------------------------------------*/
/* forward declaration of structures used by the module */
typedef struct POSPE_ENC_T          POSPE_ENC_T;

struct POSPE_ENC_T
{
    ACLIB_TRACK_OBSRV_T_F16         sTo;                /* Tracking observer */
    volatile UWord16               *puw16StatusCtrl;    /* Pointer to FTM status control reg */
    volatile UWord16               *puw16CounterValue;  /* Pointer to FTM counter reg */
    volatile UWord16               *puw16ModuloValue;   /* Pointer to FTM modulo reg */
    volatile UWord16               *puw16QuadCtrl;      /* Pointer to FTM quadrature mode reg */
    Frac16                         *pf16SpeedElEst;     /* Pointer to electrical speed  */    
    Frac16                         *pf16PosElEst;       /* Pointer to rotor electrical position */
    Frac16                          f16PosError;        /* Input poisition error to tracking observer  */    
    Frac16                          f16PosMe;           /* Mechanical position calculated using encoder edges */
    Frac16                          f16PosMeEst;        /* Estimated position calculated using tracking observer  */        
    Frac16                          f16SpeedMeEst;      /* Estimated speed calculated using tracking observer */            
    UWord16                         uw16PolePairs;      /* Motor pole-pair number */
    UWord16                         uw16NoOfEncPuls;    /* Encoder pulses number */
    Frac16                          f16PosMeGain;       /* Encoder pulses to mechanical position scale gain */ 
    Word16                          i16PosMeShift;      /* Encoder pulses to mechanical position scale shift */         
};

/******************************************************************************
| exported variables
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported function prototypes
|----------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern bool SAC_PospeEncInit(POSPE_ENC_T * this);
extern bool SAC_PospeEncConfig(POSPE_ENC_T * this);
extern bool SAC_PospeEncGet(POSPE_ENC_T * this);
extern bool SAC_PospeEncClear(POSPE_ENC_T * this);
extern bool SAC_PospeEncCountSet(POSPE_ENC_T * this, UWord16 uw16CountNo);


#ifdef __cplusplus
}
#endif

#endif /* POSPE_ENC_H_ */
