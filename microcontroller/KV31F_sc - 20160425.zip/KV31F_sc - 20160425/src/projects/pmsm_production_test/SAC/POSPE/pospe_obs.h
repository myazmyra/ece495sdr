/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     pospe_obs.h
*
* @brief    a Header file of position and speed of SAC module 
*
* @board    TWR-KV31F120M
*
******************************************************************************/

#ifndef POSPE_OBS_H_
#define POSPE_OBS_H_

#include "sac_defines.h"

/******************************************************************************
| defines and macros
|----------------------------------------------------------------------------*/
/******************************************************************************
| typedefs and structures
|----------------------------------------------------------------------------*/
/* forward declaration of structures used by the module */
typedef struct POSPE_OBS_T          POSPE_OBS_T;

struct POSPE_OBS_T
{
    ACLIB_BEMF_OBSRV_DQ_T_F16       sBemfObsrv;         /* BEMF observer in DQ */
    ACLIB_TRACK_OBSRV_T_F16         sTo;                /* Tracking observer */
    GDFLIB_FILTER_IIR1_T            sSpeedElEstFilt;    /* Estimated speed filter */
    MCLIB_3_COOR_SYST_T             *psIABC;            /* Pointer to measured 3-phase current */
    MCLIB_2_COOR_SYST_D_Q_T         *psUDQ;             /* Pointer to required DQ voltage */
    MCLIB_2_COOR_SYST_ALPHA_BETA_T  *psUAlBe;           /* Pointer to required Alpha/Beta voltage */
    MCLIB_ANGLE_T                   *psAngleEl;         /* Pointer to electrical position sin/cos (at the moment of current reading) */    
    Frac16                          *pf16SpeedElEst;    /* Pointer to electrical speed  */    
    Frac16                          *pf16PosElEst;      /* Pointer to rotor electrical position */
    Frac16                          f16SpeedElEst;      /* Rotor electrical speed estimated */
    Frac16                          f16PosElEst;        /* Rotor electrical position estimated*/       
    UWord16                         uw16IGainShift;     /* Additional shift to Bemf Observer I Gain */
    bool                            bOpenLoop;          /* Observer open-loop mode */
};

/******************************************************************************
| exported variables
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported function prototypes
|----------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern bool SAC_PospeObsClear(POSPE_OBS_T * this);
extern bool SAC_PospeObsGet(POSPE_OBS_T * this);

#ifdef __cplusplus
}
#endif

#endif /* POSPE_OBS_H_ */
