/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     pospe_obs.c
*
* @brief    Position and speed SAC module based on Bemf osbserver 
*
* @board    TWR-KV31F120M
*
******************************************************************************/

/******************************************************************************
| includes
|----------------------------------------------------------------------------*/

#include "pospe_obs.h"

/******************************************************************************
| external declarations
|----------------------------------------------------------------------------*/

/******************************************************************************
| defines and macros                                      (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures                                 (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                          (scope: module-exported)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                             (scope: module-local)
|----------------------------------------------------------------------------*/
static bool    statusPass;

/******************************************************************************
| function prototypes                                     (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| function implementations                                (scope: module-local)
|----------------------------------------------------------------------------*/


/***************************************************************************//*!
@brief          Clear selected internal module variables

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_PospeObsClear(POSPE_OBS_T * this)
{

    statusPass = TRUE;

    this->f16SpeedElEst                         = 0;
    this->f16PosElEst                           = 0;
    
    this->sTo.f16Theta                          = 0;
    this->sTo.f16Speed                          = 0;
    this->sTo.f32I_1                            = 0;

    this->sBemfObsrv.udtEObsrv.f32D             = 0;
    this->sBemfObsrv.udtEObsrv.f32Q             = 0;
    this->sBemfObsrv.udtIObsrv.f32D             = 0;
    this->sBemfObsrv.udtIObsrv.f32Q             = 0;
    this->sBemfObsrv.udtCtrl.f32ID_1            = 0;
    this->sBemfObsrv.udtCtrl.f32IQ_1            = 0;

    GDFLIB_FilterIIR1Init(&this->sSpeedElEstFilt);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief  Calculate new position and speed and update value in main control structure

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_PospeObsGet(POSPE_OBS_T * this)
{
    MCLIB_2_COOR_SYST_ALPHA_BETA_T      sIAlBe;
    MCLIB_2_COOR_SYST_D_Q_T             sIDQ;  
    MCLIB_ANGLE_T                       sAngleEst;
    MCLIB_2_COOR_SYST_D_Q_T             sUDQ;    
    
    statusPass = TRUE;

    /* 3-phase to 2-phase transformation to stationary ref. frame */
    GMCLIB_Clark(&sIAlBe, this->psIABC);
    
    if (this->bOpenLoop)
    /* Open-loop mode */
    {
        /* Estimated angle calculation */
        sAngleEst.f16Sin = GFLIB_Sin(this->f16PosElEst);
        sAngleEst.f16Cos = GFLIB_Cos(this->f16PosElEst);

        /* 2-phase to 2-phase transformation to rotary ref. frame */
        GMCLIB_Park(&sIDQ, &sAngleEst, &sIAlBe);

        GMCLIB_Park(&sUDQ, &sAngleEst, this->psUAlBe);            
        
        /* D,Q current scaling if essential */
        if(this->uw16IGainShift>0)
        {
            sIDQ.f16D = MLIB_ShLSat_F16(sIDQ.f16D,this->uw16IGainShift);
            sIDQ.f16Q = MLIB_ShLSat_F16(sIDQ.f16Q,this->uw16IGainShift);
        }
        /* BEMF observer in DQ system */
        ACLIB_PMSMBemfObsrvDQ_F16(&sIDQ, &sUDQ, this->f16SpeedElEst, &this->sBemfObsrv);
    }
    else
    /* Closed-loop mode */
    {
        /* 2-phase to 2-phase transformation to rotary ref. frame */
        GMCLIB_Park(&sIDQ, this->psAngleEl, &sIAlBe);
        
        /* D,Q current scaling if essential */
        if(this->uw16IGainShift>0)
        {
            sIDQ.f16D = MLIB_ShLSat_F16(sIDQ.f16D,this->uw16IGainShift);
            sIDQ.f16Q = MLIB_ShLSat_F16(sIDQ.f16Q,this->uw16IGainShift);
        }
        /* BEMF observer in DQ system */
        ACLIB_PMSMBemfObsrvDQ_F16(&sIDQ, this->psUDQ, this->f16SpeedElEst, &this->sBemfObsrv);
    }
    
    /* Tracking observer calculation */            
    this->f16PosElEst = ACLIB_TrackObsrv_F16(this->sBemfObsrv.f16Error, &this->sTo);
    
    /* Speed estimation filter  */
    this->f16SpeedElEst = GDFLIB_FilterIIR1(this->sTo.f16Speed, &this->sSpeedElEstFilt);
    
    /* return estimated position and speed to upper layer */
    *this->pf16PosElEst             = this->f16PosElEst;
    *this->pf16SpeedElEst           = this->f16SpeedElEst;

  return(statusPass);
}


/* End of file */
