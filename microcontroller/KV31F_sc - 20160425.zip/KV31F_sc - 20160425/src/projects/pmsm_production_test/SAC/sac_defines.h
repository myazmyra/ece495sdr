/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file         sac_defines.h
*
* @brief
* 
*******************************************************************************/

#ifndef SAC_DEFINES_H_
#define SAC_DEFINES_H_

#include "SWLIBS_Typedefs.h"
#include "gmclib.h"
#include "gflib.h"
#include "gdflib.h"
#include "aclib.h"
/******************************************************************************
| defines and macros
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported variables
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported function prototypes
|----------------------------------------------------------------------------*/

#endif /* SAC_DEFINES_H_ */
