/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     pwm3ph_ftm.h
*
* @brief    A header file of 3-phase PWM generation SAC module
*
* @board    TWR-KV31F120M
*
******************************************************************************/

#ifndef PWM3PH_FTM_H_
#define PWM3PH_FTM_H_

#include "sac_defines.h"

/******************************************************************************
| defines and macros
|----------------------------------------------------------------------------*/
typedef struct PWM3PH_FTM_T           PWM3PH_FTM_T;     /*!< @public */

/******************************************************************************
| typedefs and structures
|----------------------------------------------------------------------------*/

/*------------------------------------------------------------------------*//*!
@brief      Definition of public structure data type.
*//*-------------------------------------------------------------------------*/

struct PWM3PH_FTM_T
{
    MCLIB_3_COOR_SYST_T_F16       * psUABC;             /* pointer to the 3-phase pwm duty cycles */
    volatile Word16               * pw16PhAVal1;        /* pointer to phase A top value */
    volatile Word16               * pw16PhAVal2;        /* pointer to phase A bottom value */
    volatile Word16               * pw16PhBVal1;        /* pointer to phase B top value */
    volatile Word16               * pw16PhBVal2;        /* pointer to phase B bottom value */
    volatile Word16               * pw16PhCVal1;        /* pointer to phase C top value */
    volatile Word16               * pw16PhCVal2;        /* pointer to phase C bottom value */
    volatile UWord16              * puw16pPwmLoad;      /* pointer to PWM load register */
    volatile UWord16              * puw16PwmOutmask;    /* pointer to PWM mask resister */
             UWord16                uw16Modulo;         /* modulo value */
    
};

/******************************************************************************
| exported variables
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported function prototypes
|----------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern bool SAC_FtmPwm3PhInit(PWM3PH_FTM_T * this);
extern bool SAC_FtmPwm3PhSet(PWM3PH_FTM_T * this);
extern bool SAC_FtmPwm3PhOutEn(PWM3PH_FTM_T * this);
extern bool SAC_FtmPwm3PhOutDis(PWM3PH_FTM_T * this);

#ifdef __cplusplus
}
#endif

#endif /* PWM3PH_FTM_H_ */
