/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     pwm3ph_ftm.c
*
* @brief    3-phase PWM FTM driver layer of SAC module
*
* @board    TWR-KV31F120M
*
******************************************************************************/

/******************************************************************************
| includes
|----------------------------------------------------------------------------*/
#include "pwm3ph_ftm.h"

/******************************************************************************
| defines and macros                                      (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures                                 (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                          (scope: module-exported)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                             (scope: module-local)
|----------------------------------------------------------------------------*/
static bool statusPass;

/******************************************************************************
| function prototypes                                     (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| function implementations                                (scope: module-local)
|----------------------------------------------------------------------------*/

/***************************************************************************//*!
@brief          Pointers initialization to value, mask, load and modulo FTM regs

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhInit(PWM3PH_FTM_T * this)
{
    statusPass = TRUE;

    this->puw16PwmOutmask  = (volatile UWord16 *)(0x40038060);  //  FTM0_OUTMASK
    this->puw16pPwmLoad    = (volatile UWord16 *)(0x40038098);  //  FTM0_PWMLOAD
   
    /* modulo read from pwma_sob0 val1 register */
    this->uw16Modulo        = (UWord16)(*(volatile Word16 *)(0x40038008)) + 1;
    
    /* Phase A channel value registers */
    this->pw16PhAVal1 = (volatile Word16 *)(0x40038010);  // FTM0_C0V
    this->pw16PhAVal2 = (volatile Word16 *)(0x40038018);  // FTM0_C1V

    /* Phase B channel value registers */
    this->pw16PhBVal1 = (volatile Word16 *)(0x40038020);  // FTM0_C2V
    this->pw16PhBVal2 = (volatile Word16 *)(0x40038028);  // FTM0_C3V

    /* Phase C channel value registers */
    this->pw16PhCVal1 = (volatile Word16 *)(0x40038030);  // FTM0_C4V
    this->pw16PhCVal2 = (volatile Word16 *)(0x40038038);  // FTM0_C5V
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Write new values to FTM value registers and update them

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhSet(PWM3PH_FTM_T * this)
{
    Frac16                        f16DutyCycle;
    MCLIB_3_COOR_SYST_T_F16       sUABCtemp;   
    statusPass = TRUE;
    
    /* pointer to duty cycle structure */
    sUABCtemp = *this->psUABC;
    
    /* phase A */
    f16DutyCycle = MLIB_Mul_F16(this->uw16Modulo,sUABCtemp.f16A);
    *this->pw16PhAVal1 = (Word16)MLIB_Neg_F16(f16DutyCycle);
    *this->pw16PhAVal2 = (Word16)f16DutyCycle;
    
    /* phase B */
    f16DutyCycle = MLIB_Mul_F16(this->uw16Modulo, sUABCtemp.f16B);
    *this->pw16PhBVal1 = (Word16)MLIB_Neg_F16(f16DutyCycle);
    *this->pw16PhBVal2 = (Word16)f16DutyCycle;
    
    /* phase C */
    f16DutyCycle = MLIB_Mul_F16(this->uw16Modulo, sUABCtemp.f16C);           
    *this->pw16PhCVal1 = (Word16)MLIB_Neg_F16(f16DutyCycle);
    *this->pw16PhCVal2 = (Word16)f16DutyCycle;    
    
    /*
     * Set LDOK bit in FTm PWMLOAD register
     */
    *this->puw16pPwmLoad |= 0x0200;  
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Enable PWM outputs

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhOutEn(PWM3PH_FTM_T * this)
{
    statusPass = TRUE;
    
    /* FlexTIMER
     * OUTMASK register = mcPWM_BASE + $0x60
     *
     * Any write to the OUTMASK register, stores the value in its write buffer. The register is
     * updated with the value of its write buffer according to PWM synchronization.
     *
     * CHnOM = 0 - Channel output is not masked. It continues to operate normally.
     * CHnOM = 1 - Channel output is masked. It is forced to its inactive state.
     * |----------------------------------------------------------------------------|
     * |bits:   |   31..8   |  7   |   6  |   5  |  4   |   3  |  2   |  1   |  0   |     
     * |Meaning:| RESERVED  |CH7OM |CH6OM |CH5OM |CH4OM |CH3OM |CH2OM |CH1OM |CH0OM |
     * |----------------------------------------------------------------------------|
             * |Value:  |     0     |      |      |      |      |      |      |      |      |
     * |----------------------------------------------------------------------------|
     */

    *this->puw16PwmOutmask &= ~0x3F;   /* PWM outputs enabled in channels 0..5 */
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Disable PWM outputs

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhOutDis(PWM3PH_FTM_T * this)
{
    statusPass = TRUE;
    
    /* FlexTIMER
     * OUTMASK register = mcPWM_BASE + $0x60
     *
     * Any write to the OUTMASK register, stores the value in its write buffer. The register is
     * updated with the value of its write buffer according to PWM synchronization.
     *
     * CHnOM = 0 - Channel output is not masked. It continues to operate normally.
     * CHnOM = 1 - Channel output is masked. It is forced to its inactive state.
     * |----------------------------------------------------------------------------|
     * |bits:   |   31..8   |  7   |   6  |   5  |  4   |   3  |  2   |  1   |  0   |         
     * |Meaning:| RESERVED  |CH7OM |CH6OM |CH5OM |CH4OM |CH3OM |CH2OM |CH1OM |CH0OM |
     * |----------------------------------------------------------------------------|
     * |Value:  |     0     |      |      |      |      |      |      |      |      |
     * |----------------------------------------------------------------------------|
     */

    *this->puw16PwmOutmask |= 0x3F;   /* PWM outputs disabled in channels 0..5 */
    
    return(statusPass);
}

/* End of file */
