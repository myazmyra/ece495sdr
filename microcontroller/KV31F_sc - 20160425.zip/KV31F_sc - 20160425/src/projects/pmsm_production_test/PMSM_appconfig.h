/**********************************************************************/
// File Name: {FM_project_loc}/../../src/projects/kv30/PMSM_Sensorless_FOC_MID/PMSM_appconfig.h 
//
// Date:  19. February, 2015
//
// Automatically generated file for static configuration of the PMSM FOC application
/**********************************************************************/

#ifndef __M1_PMSMFOC_CONFIG_SETUP_H
#define __M1_PMSMFOC_CONFIG_SETUP_H


//Motor Parameters                      
//----------------------------------------------------------------------
//Pole-pair number                      = 2 [-]
//Stator resistance                     = 0.57 [Ohms]
//Direct axis inductance                = 0.000381 [H]
//Quadrature axis inductance            = 0.000479 [H]
//Back-EMF constant                     = 0.0145 [V.sec/rad]
//Drive inertia                         = 0.0000016 [kg.m2]
//Nominal current                       = 1 [A]

#define MOTOR_PP                        (2)
//----------------------------------------------------------------------

//Application scales                    
//----------------------------------------------------------------------
#define I_MAX                           (8.25)
#define U_DCB_MAX                       (58.0)
#define U_MAX                           (33.5)
#define N_MAX                           (4400.0)
#define FREQ_MAX                        (147.0)
#define E_MAX                           (20.0)
#define U_DCB_TRIP                      FRAC16(0.344827586207)
#define U_DCB_UNDERVOLTAGE              FRAC16(0.172413793103)
#define U_DCB_OVERVOLTAGE               FRAC16(0.965517241379)
#define N_OVERSPEED                     FRAC16(0.977272727273)
#define N_MIN                           FRAC16(0.090909090909)
#define N_NOM                           FRAC16(0.909090909091)
#define I_PH_NOM                        FRAC16(0.121212121212)
//DCB Voltage Filter                    
#define UDCB_IIR_B0                     FRAC16(0.003807378494)
#define UDCB_IIR_B1                     FRAC16(0.003807378494)
#define UDCB_IIR_A1                     FRAC16(-0.117385243012)
//Mechanical Alignment                  
#define ALIGN_VOLTAGE                   FRAC16(0.018)
#define ALIGN_DURATION                  (500)

//Current Loop Control                  
//----------------------------------------------------------------------
//Loop Bandwidth                        = 150 [Hz]
//Loop Attenuation                      = 1 [-]
//Loop sample time                      = 0.0001 [sec]
//----------------------------------------------------------------------
//Current Controller Output Limit       
#define CLOOP_LIMIT                     FRAC16(0.9)
//D-axis Controller - Parallel type     
#define D_KP_GAIN                       FRAC16(0.583826466884)
#define D_KP_SHIFT                      (-4)
#define D_KI_GAIN                       FRAC16(0.533404095625)
#define D_KI_SHIFT                      (-7)
//Q-axis Controller - Parallel type     
#define Q_KP_GAIN                       FRAC16(0.655850331055)
#define Q_KP_SHIFT                      (-3)
#define Q_KI_GAIN                       FRAC16(0.670605149092)
#define Q_KI_SHIFT                      (-7)

//Speed Loop Control                    
//----------------------------------------------------------------------
//Loop Bandwidth                        = 10 [Hz]
//Loop Attenuation                      = 1 [-]
//Loop sample time                      = 0.001 [sec]
//----------------------------------------------------------------------
//Speed Controller - Parallel type      
#define SPEED_PI_PROP_GAIN              FRAC16(0.558505360638)
#define SPEED_PI_PROP_SHIFT             (-2)
#define SPEED_PI_INTEG_GAIN             FRAC16(0.85786423394)
#define SPEED_PI_INTEG_SHIFT            (-10)
#define SPEED_LOOP_HIGH_LIMIT           FRAC16(0.242424242424)
#define SPEED_LOOP_LOW_LIMIT            FRAC16(-0.242424242424)

#define SPEED_RAMP_UP                   FRAC32(0.00025)
#define SPEED_RAMP_DOWN                 FRAC32(0.00025)

#define SPEED_LOOP_CNTR                 (10)
#define SPEED_LOOP_FREQ                 (1000)

#define SPEED_IIR_B0                    FRAC16(0.029882152951)
#define SPEED_IIR_B1                    FRAC16(0.029882152951)
#define SPEED_IIR_A1                    FRAC16(-0.065235694097)

//Sensorless BEMF DQ nad Tracking Observer
//----------------------------------------------------------------------
//Loop Bandwidth                        = 280 [Hz]
//Loop Attenuation                      = 1 [-]
//Loop sample time                      = 0.0001 [sec]
//----------------------------------------------------------------------
//Bemf DQ Observer                      
#define I_SCALE                         FRAC16(0.869863013699)
#define U_SCALE                         FRAC16(0.927079009271)
#define E_SCALE                         FRAC16(0.553480005535)
#define WI_SCALE                        FRAC16(0.100779614562)
#define I_SCALE_SHIFT                   (0)
#define BEMF_DQ_KP_GAIN                 FRAC16(0.63572884414)
#define BEMF_DQ_KP_SHIFT                (-1)
#define BEMF_DQ_KI_GAIN                 FRAC16(0.778295842638)
#define BEMF_DQ_KI_SHIFT                (-4)

//Bemf DQ Observer                      
#define TO_KP_GAIN                      FRAC16(0.981818181818)
#define TO_KP_SHIFT                     (-2)
#define TO_KI_GAIN                      FRAC16(0.710662530162)
#define TO_KI_SHIFT                     (-9)
#define TO_THETA_GAIN                   FRAC16(0.938666666667)
#define TO_THETA_SHIFT                  (-5)
//Observer speed output filter          
#define TO_SPEED_IIR_B0                 FRAC16(0.013954401463)
#define TO_SPEED_IIR_B1                 FRAC16(0.013954401463)
#define TO_SPEED_IIR_A1                 FRAC16(-0.097091197074)
//Open loop start-up                    
#define OL_START_RAMP_INC               FRAC32(0.000034090909)
#define OL_START_I                      FRAC16(0.08)
#define MERG_SPEED_TRH                  FRAC16(0.113636363636)
#define MERG_COEFF                      FRAC16(0.004577636719)

//Control Structure Module - Scalar Control
//----------------------------------------------------------------------
#define SCALAR_VHZ_FACTOR_GAIN          FRAC16(0.591044776119)
#define SCALAR_VHZ_FACTOR_SHIFT         (-1)
#define SCALAR_INTEG_GAIN               FRAC16(0.014666666667)
#define SCALAR_INTEG_SHIFT              (0)
#define SCALAR_RAMP_UP                  FRAC32(0.000011363636)
#define SCALAR_RAMP_DOWN                FRAC32(0.000011363636)

//Motor Identification Module           
//----------------------------------------------------------------------
#define CHAR_NUMBER_OF_POINTS_BASE      (6)
#define CHAR_CURRENT_POINT_NUMBERS      (65)
#define CHAR_NUMBER_OF_POINTS_HALF      (32)
#define TIME_50MS                       (500)
#define TIME_100MS                      (1000)
#define TIME_300MS                      (3000)
#define TIME_600MS                      (6000)
#define TIME_1200MS                     (12000)
#define TIME_2400MS                     (24000)
#define K_I_RESCALE_LUT_SHIFT           (2)
#define PWR_CHAR_CURRENT_END            FRAC16(0.24242424242424243)
#define PWR_CHAR_CURRENT_INC            FRAC16(0.007459207459207459)
#define K_RESCALE_DCB_TO_PHASE_HALF     FRAC16(0.8656716417910447)
#define K_ANGLE_INCREMENT               FRAC16(0.2)
#define INV_MOD_INDEX                   FRAC16(0.5002043280479085)
#define K_I_RESCALE_LUT_GAIN            FRAC16(0.515625)
#define K_I_50MA                        FRAC16(0.006060606060606061)

#endif

//End of generated file                 
/**********************************************************************/
