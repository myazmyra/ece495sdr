/******************************************************************************
* 
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved                       
*
******************************************************************************* 
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* $FileName: peripherals_init.c$
* $Version : 1.0.0.1$
* $Date    : Nov-19-2013$
*
* Comments:
*
*   This file contains the peripherals initialization.
*
*END************************************************************************/

#include "peripherals_init.h"
#include "main.h"
#include "freemaster.h"


/***************************************************************************
* InitFTM0
* --------------------------------------------------------------------------
* Initialization of the FTM0 module for center-aligned PWM generation
****************************************************************************/
void InitFTM0(void)
{
    // enable the clock for FTM0 
    SIM_SCGC6 |= SIM_SCGC6_FTM0_MASK;

    /* Disable all channels outputs using the OUTPUT MASK feature.
    However, the output pins are still driven as GPIO since the
    channel mode is set to FTM channel disabled after RESET */
    FTM0_OUTMASK = FTM_OUTMASK_CH5OM_MASK | FTM_OUTMASK_CH4OM_MASK | FTM_OUTMASK_CH3OM_MASK |
                 FTM_OUTMASK_CH2OM_MASK | FTM_OUTMASK_CH1OM_MASK | FTM_OUTMASK_CH0OM_MASK; 

    FTM0_MODE |= FTM_MODE_WPDIS_MASK; // Disable write protection for certain registers
    FTM0_MODE |= FTM_MODE_FTMEN_MASK; // enable the counter
    //FTM0_CONF |= FTM_CONF_BDMMODE(3); // counter running in BDM mode
    FTM0_MODE |= FTM_MODE_FAULTM_MASK;
    // Set PWM frequency; MODULO = Fclk/Fpwm/2, MODULO defined in main.h as global macro

    FTM0_MOD = MODULO / 2 - 1;
    FTM0_CNTIN = -MODULO / 2;

    //  FTM0_SYNCONF |= FTM_SYNCONF_SYNCMODE_MASK; // should be set enhanced PWM sync mode 
    // CTNMAX = 1 - PWM update at counter in max. value 
    FTM0_SYNC = FTM_SYNC_CNTMAX_MASK;
    // FTM0_SYNC |= FTM_SYNC_SWSYNC_MASK;   

    // for center aligned PWM using combine mode:

    /* COMBINE = 1 - combine mode set
    COMP = 1 - complementary PWM set
    DTEN = 1 - deadtime enabled
    SYNCEN = 1 - PWM update synchronization enabled
    FAULTEN = 1 - fault control enabled */  
    FTM0_COMBINE =  FTM_COMBINE_FAULTEN0_MASK | FTM_COMBINE_SYNCEN0_MASK | FTM_COMBINE_DTEN0_MASK
                | FTM_COMBINE_COMP0_MASK    | FTM_COMBINE_COMBINE0_MASK
                | FTM_COMBINE_FAULTEN1_MASK | FTM_COMBINE_SYNCEN1_MASK | FTM_COMBINE_DTEN1_MASK
                | FTM_COMBINE_COMP1_MASK    | FTM_COMBINE_COMBINE1_MASK
                | FTM_COMBINE_FAULTEN2_MASK | FTM_COMBINE_SYNCEN2_MASK | FTM_COMBINE_DTEN2_MASK
                | FTM_COMBINE_COMP2_MASK    | FTM_COMBINE_COMBINE2_MASK;

    // polarity setting, 3ppa driver high sides are active low 
    FTM0_POL = 0;
    // Dead time = 1 us for 60 MHz core clock 1us/25ns 
    FTM0_DEADTIME = 60;
    // Initial setting of value registers to 50 % of duty cycle 
    FTM0_C0V = -MODULO / 4; 
    FTM0_C1V =  MODULO / 4;
    FTM0_C2V = -MODULO / 4; 
    FTM0_C3V =  MODULO / 4;
    FTM0_C4V = -MODULO / 4;
    FTM0_C5V =  MODULO / 4;


    /* SWSYNC = 1 - set PWM value update. This bit is cleared automatically */
    //  FTM0_SYNC |= FTM_SYNC_SWSYNC_MASK;   

    /*
    Note:
    1. From this moment the output pins are under FTM control. Since the PWM output is disabled by
    the FTM0OUTMASK register, there is no change on PWM outputs. Before the channel mode is set,
    the correct output pin polarity has to be defined.
    2. Even if the odd channels are generated automatically by complementary logic, these channels
    have to be set to be in the same channel mode. */


    FTM0_C0SC |= FTM_CnSC_ELSB_MASK ;
    FTM0_C1SC |= FTM_CnSC_ELSB_MASK ;
    FTM0_C2SC |= FTM_CnSC_ELSB_MASK ;
    FTM0_C3SC |= FTM_CnSC_ELSB_MASK ;
    FTM0_C4SC |= FTM_CnSC_ELSB_MASK ;
    FTM0_C5SC |= FTM_CnSC_ELSB_MASK ;

    FTM0_PWMLOAD = FTM_PWMLOAD_LDOK_MASK ;  //LDOK bit set to apply changes in FTM registers

    // enable inittrig signal for starting of the PDB counter
    FTM0_EXTTRIG |= FTM_EXTTRIG_INITTRIGEN_MASK;

    FTM0_MODE |= FTM_MODE_INIT_MASK;

    // Set system clock as source for FTM0 (CLKS[1:0] = 01) 
    FTM0_SC |= FTM_SC_CLKS(1);  

    //PORT for FTM0 initialization   
    // Note: Clock for Port C anc D enabled in sysinit.c already 

    PORTC_PCR1 = PORT_PCR_MUX(4); // FTM0 CH0,PTC1
    PORTC_PCR2 = PORT_PCR_MUX(4); // FTM0 CH1,PTC2
    PORTC_PCR5 = PORT_PCR_MUX(7); // FTM0 CH2,PTC5
    PORTC_PCR4 = PORT_PCR_MUX(4); // FTM0 CH3,PTC4
    PORTD_PCR4 = PORT_PCR_MUX(4); // FTM0 CH4,PTD4
    PORTD_PCR5 = PORT_PCR_MUX(4); // FTM0 CH5,PTD5
 
    PORTA_PCR19 = PORT_PCR_MUX(2); // Fault input FTM0_FLT0
} 

/***************************************************************************
* InitADC
* --------------------------------------------------------------------------
* Initialization of the PDB and A/D converter for current and voltage sensing
* 
****************************************************************************/
#pragma optimize = none
void InitADC(void)
{
    /* ### ADC init code */
    // enable clock for ADC0 and ADC1 modules
    SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;
    SIM_SCGC6 |= SIM_SCGC6_ADC1_MASK;

    //------- ADC self calibration procedure start -----
    // setting the clock to 3.125 MHz (ADIV and ADICLK bits) and single-ended 12-bit conversion (MODE bits);
    ADC0_CFG1 = ADC_CFG1_ADIV(2) | ADC_CFG1_MODE(1) | ADC_CFG1_ADICLK(0);
    ADC1_CFG1 = ADC_CFG1_ADIV(2) | ADC_CFG1_MODE(1) | ADC_CFG1_ADICLK(0);
    // HW averaging enabled, 32 samples averaged, continuous conversion must be enabled
    ADC0_SC3 = ADC_SC3_AVGE_MASK | ADC_SC3_AVGS(3) | ADC_SC3_ADCO_MASK; 
    ADC1_SC3 = ADC_SC3_AVGE_MASK | ADC_SC3_AVGS(3) | ADC_SC3_ADCO_MASK; 

    // starting the calibration of ADC0
    ADC0_SC3 |= ADC_SC3_CAL_MASK;
    while (!((ADC0_SC1A >> ADC_SC1_COCO_SHIFT) & 1)){} // wait until the calibration complets
    if (( ADC0_SC3 & ADC_SC3_CALF_MASK ) == ADC_SC3_CALF_MASK)
    { 
      asm ("nop"); // adc calibration failed, place breakpoint here for debug
    }; 
    unsigned short calib;
    calib = 0;
    calib = ADC0_CLP0;
    calib =+ ADC0_CLP1;
    calib =+ ADC0_CLP2;
    calib =+ ADC0_CLP3;
    calib =+ ADC0_CLP4;
    calib =+ ADC0_CLPS;
    calib = calib >> 1;
    calib = calib | 0x8000; // set the MSB
    ADC0_PG = calib; // set the plus side gain register
    calib = ADC0_CLM0;
    calib =+ ADC0_CLM1;
    calib =+ ADC0_CLM2;
    calib =+ ADC0_CLM3;
    calib =+ ADC0_CLM4;
    calib =+ ADC0_CLMS;
    calib = calib >> 1;
    calib = calib | 0x8000; // set the MSB
    ADC0_MG = calib; // set the minus side gain register
    
    // starting the calibration of ADC1
    calib = 0;
    ADC1_SC3 |= ADC_SC3_CAL_MASK;
    while (!((ADC1_SC1A >> ADC_SC1_COCO_SHIFT) & 1)){ } // wait until the calibration complets
    if (( ADC1_SC3 & ADC_SC3_CALF_MASK ) == ADC_SC3_CALF_MASK)
    { 
      asm ("nop"); // adc calibration failed
    }; 
    calib = ADC1_CLP0;
    calib =+ ADC1_CLP1;
    calib =+ ADC1_CLP2;
    calib =+ ADC1_CLP3;
    calib =+ ADC1_CLP4;
    calib =+ ADC1_CLPS;
    calib = calib >> 1;
    calib = calib | 0x8000; // set the MSB
    ADC1_PG = calib; // set the plus side gain register
    calib = ADC1_CLM0;
    calib =+ ADC1_CLM1;
    calib =+ ADC1_CLM2;
    calib =+ ADC1_CLM3;
    calib =+ ADC1_CLM4;
    calib =+ ADC1_CLMS;
    calib = calib >> 1;
    calib = calib | 0x8000; // set the MSB
    ADC1_MG = calib; // set the minus side gain register  
    //------- ADC self calibration procedure end -----  

    // setting the prescaller (bus_clock/4) = 50/4 = 12.5MHz and resoulution to 12 bits
    // long sample time
    // for normal operation
    ADC0_CFG1 = ADC_CFG1_ADIV(2) | ADC_CFG1_MODE(1);// | ADC_CFG1_ADLSMP_MASK ;
    ADC1_CFG1 = ADC_CFG1_ADIV(2) | ADC_CFG1_MODE(1);// | ADC_CFG1_ADLSMP_MASK;
    
    // hardweare averaging and continuous conversion disabled
    ADC0_SC3 = 0;
    ADC1_SC3 = 0;
    
    // hardware trigger enabled
    ADC0_SC2 |= ADC_SC2_ADTRG_MASK;
    ADC1_SC2 |= ADC_SC2_ADTRG_MASK; 
    
    // set the trigger of the ADC to FTM InitTrig (for calibration purposes only)
    SIM_SOPT7 |= SIM_SOPT7_ADC1ALTTRGEN_MASK | SIM_SOPT7_ADC1TRGSEL(8) |  SIM_SOPT7_ADC0ALTTRGEN_MASK | SIM_SOPT7_ADC0TRGSEL(8);
    
    // start conversion of current and enable interrupt
    ADC1_SC1A = ADC_SC1_AIEN_MASK | ADC_SC1_ADCH(0x00); // Ib     
    ADC0_SC1B = ADC_SC1_ADCH(0x0d);
    ADC0_SC1A = ADC_SC1_ADCH(0x03); // Ib     
    ADC1_SC1B = ADC_SC1_ADCH(0x03);
      
     /* Configuration table of ADC channels according to the input pin signals:
     Valid for Kinetis KV30 Daughter card (HVP-Kv30F120M) together with HVP-MC3PH  
    Quantity   |Channel 0                         | Channel 1
    ------------------------------------------------------------------------------
    I_A (PTB0)   | ADC0_SE8  ADC0_SC1n_ADCH(0x08) | ADC1_SE8 ADC1_SC1n_ADCH(0x08)  
    I_B (20)     | ADC0_DP3  ADC0_SC1n_ADCH(0x03) | ADC1_DP0 ADC1_SC1n_ADCH(0x00) 
    I_C (18)     | ADC0_DP0  ADC0_SC1n_ADCH(0x00) | ADC1_DP3 ADC1_SC1n_ADCH(0x03) 
    U_dcb (PTB2) | ADC0_SE13 ADC0_SC1n_ADCH(0x0D)                                 
    */  


    /* ### PDB init code */

    SIM_SCGC6  |= SIM_SCGC6_PDB_MASK;  // enable clock for PDB module
    PDB0_MOD = MODULO; // same as FTM0
    // PDB triggers for ADC0 module
    PDB0_CH0DLY1 = MODULO / 4; //MODULO/2;    // pretrigger1 delay (will generate trigger B for ADC - for voltage)
    //NOTE: pretrigger delays for current sampling need to be tuned for particular motor. Kind of dead-time compensation
    // the default value is MODULO
    PDB0_CH0DLY0 = 13 ; //0;   // pretrigger1 delay (will generate trigger B for ADC - for currents)
    // PDB trigger for ADC1 module
    PDB0_CH1DLY0 = 13 ; //0; //pretrigger1 delay (will generate trigger A for ADC - for currents)
    // Assign FTM0 trigger for starting of the PDB counter | Enable PDB module | Use continuous mode
    // enable interrupt for debug purposes only
    PDB0_SC |= PDB_SC_TRGSEL(0x8)| PDB_SC_PRESCALER(0x1) | PDB_SC_PDBEN_MASK | PDB_SC_PDBEIE_MASK;

    //PDB0_IDLY = 20;  // PDB delay interrupt only for debug ( pulse ocurres approx. 10 cycles after starting of the conversion)
    PDB0_SC |= PDB_SC_LDOK_MASK;  // LDOK needed for update of PDB0_MOD and PDBn_CH0DLYm values

    /* Enable PDB channels to trigger ADC coversion */
    PDB0_CH0C1 |= PDB_C1_TOS(0x1) | PDB_C1_EN(0x1);  
    PDB0_CH0C1 |= PDB_C1_TOS(0x2) | PDB_C1_EN(0x2);  
    PDB0_CH1C1 |= PDB_C1_TOS(0x1) | PDB_C1_EN(0x1); 

    /* switch the triger of the ADC to PDB */
    SIM_SOPT7 = 0;     
}

/*************************************************************************
 * Function Name: GPIO_init
 * Parameters: none
 * Return: none
 * Description: I/O pins configuration
 *************************************************************************/
void GPIO_init(void)
{
  //UART0
  PORTB_BASE_PTR->PCR[16] = PORT_PCR_MUX(3);
  PORTB_BASE_PTR->PCR[17] = PORT_PCR_MUX(3);
  
  // LED
  PORTD_BASE_PTR->PCR[1] = PORT_PCR_MUX(1);
  PTD_BASE_PTR->PDDR |= 1 << 1;
  PTD_BASE_PTR->PSOR = 1 << 1;   // Turn off red LED
  
  PORTD_BASE_PTR->PCR[7] = PORT_PCR_MUX(1);
  PTD_BASE_PTR->PDDR |= 1 << 7;
  PTD_BASE_PTR->PSOR = 1 << 7;   // Turn off green LED
  
  // Push buttons: PTA4 = SW2, PTE4 = SW1
  PORTA_BASE_PTR->PCR[4] = PORT_PCR_MUX(1);
  PORTE_BASE_PTR->PCR[4] = PORT_PCR_MUX(1);
  
  /* Enable PTA4 isr */
  PORTA_BASE_PTR->PCR[4] |= PORT_PCR_IRQC(9); // Rising edge interrupt
}

/**************************************************************************//*!
* FreeMASTER_Init
* --------------------------------------------------------------------------
* Initialize FreeMASTER resources
******************************************************************************/

void InitFreemaster(void)
{
    /* UART0 and UART1 are clocked from the core clock, but all other UARTs are
    * clocked from the peripheral clock. So we have to determine which clock
    * to send to the uart_init function.
    */
    if ((FMSTR_UART_PORT == UART0_BASE_PTR) | (FMSTR_UART_PORT == UART1_BASE_PTR))
      /* Fmstr UART Init */
      uart_init (FMSTR_UART_PORT, BRD_SYSCLOCK, FMSTR_UART_BAUD);
    else
      /* Fmstr UART Init */
      uart_init (FMSTR_UART_PORT, BRD_SYSCLOCK / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV2_MASK) >> 24)+ 1), FMSTR_UART_BAUD);

    /* Enable UART Isr */    
    ISR_ENABLE_VECT(FMSTR_UART_VECTOR);

    /* Initialize FMSTR stack */
    FMSTR_Init();
}

/*
 *######################################################################
 *                           End of File
 *######################################################################
*/
