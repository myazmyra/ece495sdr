/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */

/*
 * File:		pmsm_production_test.c
 * Purpose:		LED,Switch and Accel example
 *
 *		Configures GPIO for the LED and push buttons on the TWR-KV31F120M
 *		Yellow LED      - On if SW1 pressed
 *		Blue/RED LED    - On if SW2 pressed
 *		Orange/RED LED      - On if SW3 pressed
 *		Green LED       - On if SW4 pressed
 *
 *		Also configures push buttons for falling IRQ's. ISR
 *		configured in vector table in isr.h
 */

#define GPIO_PIN_MASK			0x1Fu
#define GPIO_PIN(x)				(((1)<<(x & GPIO_PIN_MASK)))

#include "common.h"
#include "lptmr.h"
#include "i2c.h"
#include "adc16.h"
#include "freemaster.h"
#include "SWLIBS_Typedefs.h"
#include "peripherals_init.h"
#include "M1_statemachine.h"
#include "main.h"

/*Function declarations */
void portc_isr(void);
void porta_isr(void);
void porte_isr(void);
void init_gpio(void);
void adc1_differential_channel1(void);
void adc1_differential_channel_init(void);
extern signed char result[20];
/******************************************************************************
* Global variables
******************************************************************************/
tADC_Config Master_Adc_Config;  
tADC_Cal_Blk CalibrationStore[2];
extern bool             mbM1SwitchAppOnOff;
/******************************************************************************
* Local variables
******************************************************************************/
static UWord32          uw32ButtonFilter;  // Used for demo mode

void main (void)
{
        int i,adc_result,adc_threshold;
        printf("**********************************************************************\n");  
        printf("%s Production Test Software with Thermistor on Freedom!\n", BRD_STRING);
        printf("Press and Hold SW3 - Place finger on Thermistor. LED blink RED till temp stops rising\r\n");      
        printf("Press SW2 - LED turns Green and Motor Spins.\r\n");
        printf("Press SW2, SW3 its associated LED illuminates.\r\n");
        printf("Tilt FRDM board from left to right connectors side to see corresponding LEDs blinking.\n");
        printf("**********************************************************************\n");  
        printf("  X     Y     Z     Thermistor Reads while Switch 3 Pressed");
         /* Turn on all port clocks */
	SIM_SCGC5 = SIM_SCGC5_PORTA_MASK |
				SIM_SCGC5_PORTB_MASK |
				SIM_SCGC5_PORTC_MASK |
				SIM_SCGC5_PORTD_MASK |
				SIM_SCGC5_PORTE_MASK;
        SIM_SCGC6 |= (SIM_SCGC6_ADC1_MASK );  

        /*Initialize I2C*/
        init_I2C();
        /*Configure accelemoter sensor*/
        I2CWriteRegister(0x2A,0x01);
        
	/* Enable GPIOC interrupts in NVIC */
        enable_irq(61);		/* GPIOC Vector is 77. IRQ# is 77-16=61 */
	enable_irq(63);		/* GPIOC Vector is 79. IRQ# is 79-16=63 */

	/* Initialize GPIO on board for -K22F120M */
	init_gpio();
        adc1_differential_channel_init();
        adc1_differential_channel1();
                      for (i=0;i<0xffff;i++){
                         if ((ADC1_SC1A & ADC_SC1_COCO_MASK)>>ADC_SC1_COCO_SHIFT == 1){
                            adc_threshold = ADC1_RA&0x7fff;                        
                            break;
                         }
                      }
//        printf(" if greater than 0x%02X ", adc_threshold);   

       printf("\n");
       /* Motor Control Init */
       InitFTM0(); /* initialize PWM */
       InitADC();
           
       /* Init FreeMASTER resources */
       //  InitFreemaster();
     
       /* Enable particular interrupts */
       enable_irq(39);       // Enable ADC0 interrupt 
       NVIC_IP(39) = 0xC0;   // Interrupt priority for ADC0
       enable_irq(73);       // Enable ADC1 interrupt 
       NVIC_IP(73) = 0xC0;   // Interrupt priority for ADC1
       enable_irq(31);       // Enable UART0 interrupt
       enable_irq(52);       // Enable PDB interrupt 
       enable_irq(59);       // Interrupt priority for PORTA
       
       
       /* Enable Interrupts globally */
       EnableInterrupts;
       
       /* Demo mode setup */
       bDemoMode = FALSE;
       uw32SpeedStimulatorCnt = 0;
       mbM1SwitchAppOnOff = FALSE;
       uw32ButtonFilter = 0;
       PTD_BASE_PTR->PCOR = 1 << 1; // trun on red LED

        
	while (1)
        {
                /*Look at status of accelerometer*/
                I2CReadMultiRegisters(0x01,6);
		
                if (result[0]>20)
                {
                  /*Toogle Secondary side LEDS PTB19 - Orange LED (D6) and PTD7 
                  * - Green LED (D7)*/
                  #if (defined(TOWER))
                  LED2_TOGGLE;
                  LED1_TOGGLE;
                  #elif (defined(FREEDOM))
                  LED1_ON;
                  time_delay_ms(100);
                  LED1_OFF;
                  #endif
                }
                else if(result[0]<-20)
                {
                   /*Toogle Primary side LEDS PTE1 - Yellow LED (D3) and
                    *   PTE0 - Blue LED (D4)*/
                  #if (defined(TOWER))
                  LED0_OFF;
                  LED3_OFF;
                 #elif (defined(FREEDOM))
                  LED2_ON;
                  time_delay_ms(100);
                  LED2_OFF;
                 #endif
                  
                }
                else
                {
                   /* Look at status of SW1 on PTC6 */
                 #if (defined(TOWER))
                 if ((GPIOC_PDIR & GPIO_PDIR_PDI(GPIO_PIN(6))) == 0) {
                          /*
                           * if pressed...
                           * Set PTE1 to 0 (turns on orange/RED LED)
                           */
                          GPIOE_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(1));
                 } else {
                          /*
                           * else if SW1 not pressed...
                           * Set PTE1 to 1 (turns off orange LED)
                           */
                          GPIOE_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(1));
                 }
                 #endif

                  /* Look at status of SW2 on PTC11 */
                 #if (defined(TOWER))
                 if ((GPIOC_PDIR & GPIO_PDIR_PDI(GPIO_PIN(11))) == 0) {
                          /*
                           * If pressed...
                           * Set PTE0 to 0 (turns on blue LED)
                           */
                          LED0_ON;
                  } else {
                          /*
                           * else if SW2 not pressed...
                           * Set PTE0 to 1 ((turns off blue LED)
                           */
                          LED0_OFF;
                  }
                 #elif (defined(FREEDOM))
                 if ((GPIOA_PDIR & GPIO_PDIR_PDI(GPIO_PIN(4))) == 0) {
                          LED2_ON;
                  } else {
                          LED2_OFF;
                  }
                  #endif
                  
                  /* Look at status of SW3  */
                  #if (defined(TOWER))
                  if ((GPIOA_PDIR & GPIO_PDIR_PDI(GPIO_PIN(4))) == 0) {
                          LED2_ON;  //ORANGE
                  } else {
                           LED2_OFF;
                  }
                 #elif (defined(FREEDOM))
                 if ((GPIOE_PDIR & GPIO_PDIR_PDI(GPIO_PIN(4))) == 0) {
                      LED0_ON; //on RED
                      adc1_differential_channel1();
                      for (i=0;i<0xffff;i++){
                         if ((ADC1_SC1A & ADC_SC1_COCO_MASK)>>ADC_SC1_COCO_SHIFT == 1){
                           
                         //   adc_result = (~(ADC1_RA - 1))&0x7fff;                        
                            adc_result = ADC1_RA&0x7fff;                        
                            break;
                         }
                      }  
                      if (adc_result < adc_threshold){  
                                 adc_threshold = adc_result;
                                 LED0_OFF; //off RED
                                 time_delay_ms(400);
                                 LED0_ON; //on RED
                            }
                  } else {
                          LED0_OFF; //off RED
                  }
                  #endif

                  /* Look at status of SW4 on PTE25 */
                 #if (defined(TOWER))
                  if ((GPIOE_PDIR & GPIO_PDIR_PDI(GPIO_PIN(25))) == 0) {
                          /*
                           * if pressed...
                           * Set PTD7 to 0 (turns on green LED)
                           */
                          LED1_ON;
                  } else {
                          /*
                           * else if SW1 not pressed...
                           * Set PTD7 to 1 (turns off green LED)
                           */
                          LED1_OFF;
                  }
                #endif
                }
                
 	       time_delay_ms(100);
               
                 printf("\r                                ");
               printf("\r%3d  %3d  %3d       0x%02X", result[0], result[2], result[4], adc_result);   

	}
}

/*
 * Initialize GPIO for Board switches and LED's
 *    Device            TOWER       FRDM
 *    SW1 -             PTC6        RESET
 *    SW2 -             PTC11       PTA4
 *    SW3 -             PTA4        PTE4
 *    SW4 -             PTE25       n/a
 *  
 *  Yellow LED (D3)     PTE1        N/A
 *  Blue LED (D4)       PTE0        PTE25
 *  Orange/RED LED (D6) PTB19       PTD1
 *  Green LED (D7)      PTD7        PTD7
*/
void init_gpio()
{
	/*
	 * Set PTD1, PTC6, PTC7, PTA4 PTE4 and PTE25 for GPIO functionality,
	 * falling IRQ, and to use internal pull-ups. (pin defaults to input state)
	 */
	PORTC_PCR6 =
	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
	    PORT_PCR_PS_MASK;
	PORTC_PCR11 =
	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
	    PORT_PCR_PS_MASK;
        PORTA_PCR4 =
	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
	    PORT_PCR_PS_MASK;
       #if (defined(TOWER))
       PORTE_PCR25 =
       	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
       	    PORT_PCR_PS_MASK;
       #elif (defined(FREEDOM))
       PORTE_PCR4 =
       	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
       	    PORT_PCR_PS_MASK;
       #endif

	/*
	 * Set PTE1, PTE0, PTB19, and PTD7 (connected to LED's)
	 * for GPIO functionality
	 */
       LED0_EN;
       LED1_EN;
       LED2_EN;
       /* Change to outputs */
       LED0_DIR;
       LED1_DIR;
       LED2_DIR;
 
#if (defined(TOWER))
       LED3_EN;
       /* Change to outputs */
       LED3_DIR;
#endif

}

/* ISR for PORTC interrupts */
void portc_isr(void)
{
	if (PORTC_ISFR & GPIO_PIN(6)) {
		PORTC_ISFR = (1<<6);	/* Clear Port C ISR flags */
		printf("  SW1 ");
	}
	if (PORTC_ISFR & GPIO_PIN(11)) {
		PORTC_ISFR = (1<<11);	/* Clear Port C ISR flags */
		printf("  SW2 ");
	}
	printf("Pressed\n");
}

/* ISR for PORTA interrupts */
void porta_isr(void)
{
  if (PORTA_BASE_PTR->PCR[4] | PORT_PCR_ISF_MASK)
  { 
    PORTA_BASE_PTR->PCR[4] |= PORT_PCR_ISF_MASK; // clear the flag
    #if (defined(TOWER))
    printf("  SW3 ");
    #elif (defined(FREEDOM))
    printf("  SW2 ");
    #endif
		
    if(uw32ButtonFilter > 2000) // Proceede only if more then 200ms passed
    {
      uw32ButtonFilter = 0;
      if(bDemoMode)
      {      
        PTD_BASE_PTR->PCOR = 1 << 1; // trun on red LED
        PTD_BASE_PTR->PSOR = 1 << 7; // trun off green LED
        M1_SetSpeed(0);
        M1_SetAppSwitch(0);
        bDemoMode = FALSE;
      }
      else
      {
        PTD_BASE_PTR->PSOR = 1 << 1; // trun off red LED
        PTD_BASE_PTR->PCOR = 1 << 7; // trun on green LED
        M1_SetAppSwitch(1);
        bDemoMode = TRUE;  
        uw32SpeedStimulatorCnt = 0;
        InitADC();
      }  
    }
    }
  printf("Pressed  -Motor Demo Runs\n");
}

/* ISR for PORTE interrupts */
void porte_isr(void)
{
	if (PORTE_ISFR & GPIO_PIN(25)) {
		PORTE_ISFR = (1<<25);	/* Clear Port E ISR flags */
		printf("  SW4 ");
	}
	if (PORTE_ISFR & GPIO_PIN(4)) {
		PORTE_ISFR = (1<<4);	/* Clear Port E ISR flags */
		printf("  SW3 ");       /* SW3 on FRDM-KC31F */
                PTD_BASE_PTR->PCOR = 1 << 1; // trun on red LED
                PTD_BASE_PTR->PSOR = 1 << 7; // trun off green LED
                M1_SetSpeed(0);
                M1_SetAppSwitch(0);
                bDemoMode = FALSE;
                
	}
	printf("Pressed - HOLD down and watch LED blinking RED while temp rises on Thermistor\n");
}
/*************************************************************************
 * Function Name: ADC_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the adc complete interrupt
 *
 *************************************************************************/
void ADC_ISR_Handler(void)
{
    /* StateMachine call */
    SM_StateMachine(&gsM1Ctrl); 
    
    DemoSpeedStimulator(); 
  
    /* FreeMASTER Recorder */
    FMSTR_Recorder();
    
  
}
/*************************************************************************
 * Function Name: PDB_Error_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the PDB error interrupt: reinitiates the PDB module 
 *
 *************************************************************************/
void PDB_Error_ISR_Handler(void)
{
    PDB0_SC &= ~PDB_SC_PDBEN_MASK;  /* disable PDB */ 
    PDB0_CH0S &= ~PDB_S_CF_MASK;
    PDB0_CH0S &= ~PDB_S_ERR_MASK;   /* reset error CH0 */    
    PDB0_CH1S &= ~PDB_S_CF_MASK;
    PDB0_CH1S &= ~PDB_S_ERR_MASK;   /* reset error CH1 */
    PDB0_SC |= PDB_SC_PDBEN_MASK;   /* Enable PDB */
}
/*************************************************************************
 * Function Name: DemoSpeedStimulator
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  Demo speed stimulator
 *
 *************************************************************************/
void DemoSpeedStimulator(void)
{   
    if(uw32ButtonFilter < 10000) uw32ButtonFilter++;   
    if ( bDemoMode )
    {
      uw32SpeedStimulatorCnt++;
      switch (uw32SpeedStimulatorCnt)
      {
      case 1:
        M1_SetSpeed(FRAC16(1000/N_MAX));
      break;        
      case 25000:
        M1_SetSpeed(FRAC16(2000/N_MAX));
      break;
      case 50000:
        M1_SetSpeed(FRAC16(3000/N_MAX));
      break;
      case 75000:
        M1_SetSpeed(FRAC16(1000/N_MAX));
      break; 
      case 125000:
        M1_SetSpeed(-FRAC16(1000.0/N_MAX));
      break;
      case 200000:
        uw32SpeedStimulatorCnt = 0;
      break;
      }
    }
}

