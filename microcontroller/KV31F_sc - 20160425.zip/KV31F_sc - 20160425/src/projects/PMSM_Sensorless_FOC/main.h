/*******************************************************************************
*
* Copyright 2015 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     main.h
*
* @brief    PMSM sensorless on HVP-KV31F120M header file
*
******************************************************************************/

#ifndef __MAIN_H
#define __MAIN_H 1

/******************************************************************************
* Includes
******************************************************************************/
#include "common.h"    // Common Kinetis defines
#include "isr.h"
#include "uart.h"

/******************************************************************************
* Macros
******************************************************************************/


/* FreeMASTER UART Settings */ 
// see HVP-KV31F120M.h
  #define FMSTR_UART_PORT              UART0_BASE_PTR
  #define FMSTR_UART_VECTOR            47
  #define FMSTR_UART_BAUD              19200     
//  #define CORE_CLK_KHZ                 120000

/* Standard Macros */
#ifndef EnableInterrupts
  #define EnableInterrupts asm(" CPSIE i");    /* Macro to enable all interrupts. */
#endif
#ifndef DisableInterrupts
  #define DisableInterrupts asm(" CPSID i");   /* Macro to disable all interrupts. */
#endif

/* Interrupt Macros */
#define ISR_ENABLE_VECT(vect)    NVIC_ISER_REG(NVIC_BASE_PTR, (vect-16)/32) = 1<<((vect-16)%32)
#define ISR_DISABLE_VECT(vect)   NVIC_ICER_REG(NVIC_BASE_PTR, (vect-16)/32) = 1<<((vect-16)%32)

#define ISR_ENABLE_IRQ(vect)     NVIC_ISER_REG(NVIC_BASE_PTR, vect/32) = 1<<(vect%32)
#define ISR_DISABLE_IRQ(vect)    NVIC_ICER_REG(NVIC_BASE_PTR, vect/32) = 1<<(vect%32)

                                                
/* PWM settings */
// Modulo value = (PWM input clock in Hz) / (PWM frequency * 2)
// PWM input clock will be System clock (96 MHz) - see sysinit.c
#define MODULO (4800UL) // PWM frequency will be 10.0 kHz                                                   

                                            
/******************************************************************************
* Function prototypes
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
  
void ADC_ISR_Handler(void);
void PDB_Error_ISR_Handler(void);
void DemoSpeedStimulator(void);

#ifdef __cplusplus
}
#endif

/********************************************************************/
#endif // (_main_h)