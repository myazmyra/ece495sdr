/*******************************************************************************
*
* Copyright 2015 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     isr.h
*
* @brief    Define interrupt service routines referenced by the vector table.
*           Note: Only "vectors.c" should include this header file.
*
******************************************************************************/
#ifndef __ISR_H
#define __ISR_H 1

extern void ADC_ISR_Handler(void);
extern void PDB_Error_ISR_Handler(void);
extern void Ports_ISR_Handler(void);

//----------------------------------------------

#undef    VECTOR_055   // as it was previously defined in vectors.h
#define   VECTOR_055   ADC_ISR_Handler     

#undef    VECTOR_068   // as it was previously defined in vectors.h
#define   VECTOR_068   PDB_Error_ISR_Handler     

#undef    VECTOR_089   // as it was previously defined in vectors.h
#define   VECTOR_089   ADC_ISR_Handler      

#undef    VECTOR_075
#define   VECTOR_075   Ports_ISR_Handler 
//----------------------------------------------

#endif  //__ISR_H

/* End of "isr.h" */

