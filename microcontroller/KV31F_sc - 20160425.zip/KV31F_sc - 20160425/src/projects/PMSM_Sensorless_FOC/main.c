/*******************************************************************************
*
* Copyright 2015 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     main.c
*
* @brief    The main file for PMSM sensorless on HVP-KV31F120M
*
******************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "freemaster.h"
#include "SWLIBS_Typedefs.h"
#include "peripherals_init.h"
#include "M1_statemachine.h"
#include "main.h"

/******************************************************************************
* Global variables
******************************************************************************/
extern bool             mbM1SwitchAppOnOff;

/******************************************************************************
* Local variables
******************************************************************************/
static UWord32          uw32ButtonFilter;  // Used for demo mode

/******************************************************************************
* Function definitions
******************************************************************************/
void main (void)
{
  
    InitFTM0(); /* initialize PWM */
    InitADC();
    GPIO_init();
        
    /* Init FreeMASTER resources */
    InitFreemaster();
  
    /* Enable particular interrupts */
    enable_irq(39);       // Enable ADC0 interrupt 
    NVIC_IP(39) = 0xC0;   // Interrupt priority for ADC0
    enable_irq(73);       // Enable ADC1 interrupt 
    NVIC_IP(73) = 0xC0;   // Interrupt priority for ADC1
    enable_irq(31);       // Enable UART0 interrupt
    enable_irq(52);       // Enable PDB interrupt 
    enable_irq(59);       // Interrupt priority for PORTA
    
    
    /* Enable Interrupts globally */
    EnableInterrupts;
    
    /* Demo mode setup */
    bDemoMode = FALSE;
    uw32SpeedStimulatorCnt = 0;
    mbM1SwitchAppOnOff = FALSE;
    uw32ButtonFilter = 0;
    PTD_BASE_PTR->PCOR = 1 << 1; // trun on red LED

    /* Infinite loop */
    while(1)
    {
        FMSTR_Poll();
    }
}

/*************************************************************************
 * Function Name: ADC_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the adc complete interrupt
 *
 *************************************************************************/
void ADC_ISR_Handler(void)
{
    /* StateMachine call */
    SM_StateMachine(&gsM1Ctrl); 
    
    DemoSpeedStimulator(); 
  
    /* FreeMASTER Recorder */
    FMSTR_Recorder();
    
  
}

/*************************************************************************
 * Function Name: PDB_Error_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the PDB error interrupt: reinitiates the PDB module 
 *
 *************************************************************************/
void PDB_Error_ISR_Handler(void)
{
    PDB0_SC &= ~PDB_SC_PDBEN_MASK;  /* disable PDB */ 
    PDB0_CH0S &= ~PDB_S_CF_MASK;
    PDB0_CH0S &= ~PDB_S_ERR_MASK;   /* reset error CH0 */    
    PDB0_CH1S &= ~PDB_S_CF_MASK;
    PDB0_CH1S &= ~PDB_S_ERR_MASK;   /* reset error CH1 */
    PDB0_SC |= PDB_SC_PDBEN_MASK;   /* Enable PDB */
}


/*************************************************************************
 * Function Name: PORTC_IRQHandler
 * Parameters: none
 *
 * Return: none
 *
 * Description: port A interrupt handler 
 *
 *************************************************************************/
void Ports_ISR_Handler(void)
{ 
  if (PORTA_BASE_PTR->PCR[4] | PORT_PCR_ISF_MASK)
  { 
    PORTA_BASE_PTR->PCR[4] |= PORT_PCR_ISF_MASK; // clear the flag
    if(uw32ButtonFilter > 2000) // Proceede only if more then 200ms passed
    {
      uw32ButtonFilter = 0;
      if(bDemoMode)
      {      
        PTD_BASE_PTR->PCOR = 1 << 1; // trun on red LED
        PTD_BASE_PTR->PSOR = 1 << 7; // trun off green LED
        M1_SetSpeed(0);
        M1_SetAppSwitch(0);
        bDemoMode = FALSE;
      }
      else
      {
        PTD_BASE_PTR->PSOR = 1 << 1; // trun off red LED
        PTD_BASE_PTR->PCOR = 1 << 7; // trun on green LED
        M1_SetAppSwitch(1);
        bDemoMode = TRUE;  
        uw32SpeedStimulatorCnt = 0;
      }  
    }
  }
}  

/*************************************************************************
 * Function Name: DemoSpeedStimulator
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  Demo speed stimulator
 *
 *************************************************************************/
void DemoSpeedStimulator(void)
{   
    if(uw32ButtonFilter < 10000) uw32ButtonFilter++;   
    if ( bDemoMode )
    {
      uw32SpeedStimulatorCnt++;
      switch (uw32SpeedStimulatorCnt)
      {
      case 1:
        M1_SetSpeed(FRAC16(1000/N_MAX));
      break;        
      case 25000:
        M1_SetSpeed(FRAC16(2000/N_MAX));
      break;
      case 50000:
        M1_SetSpeed(FRAC16(3000/N_MAX));
      break;
      case 75000:
        M1_SetSpeed(FRAC16(1000/N_MAX));
      break; 
      case 125000:
        M1_SetSpeed(-FRAC16(1000.0/N_MAX));
      break;
      case 200000:
        uw32SpeedStimulatorCnt = 0;
      break;
      }
    }
}

/*
 *######################################################################
 *                           End of File
 *######################################################################
*/