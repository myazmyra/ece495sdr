/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2013 Freescale Semiconductor, Inc.
* ALL RIGHTS RESERVED.
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* @file isr.h
*
* @author Freescale
*
* @version 0.0.1
*
* @date Jun. 25, 2013
*
* @brief define interrupt service routines referenced by the vector table. 
*
* Note: Only "vectors.c" should include this header file.
*
*******************************************************************************
******************************************************************************/

#ifndef __ISR_H
#define __ISR_H


/* Example */
/*
#undef  VECTOR_044
#define VECTOR_044 LPTMR_Isr  
*/

/*
// ISR(s) are defined in your project directory.
extern void LPTMR_Isr(void);
*/

extern void ADC_ISR_Handler(void);
extern void PDB_Error_ISR_Handler(void);
extern void FTM1_Isr(void);
extern void FTM2_Isr(void);
extern void PDB0_Isr(void);
extern void porta_isr(void);
extern void portc_isr(void);
extern void porte_isr(void);


/*!
 * @brief define interrupt service routine for different vectors.
 *
 */

#undef    VECTOR_055   // as it was previously defined in vectors.h
#define   VECTOR_055   ADC_ISR_Handler     

#undef    VECTOR_068   // as it was previously defined in vectors.h
#define   VECTOR_068   PDB_Error_ISR_Handler     

#undef    VECTOR_089   // as it was previously defined in vectors.h
#define   VECTOR_089   ADC_ISR_Handler      

#undef  VECTOR_059
#define VECTOR_059 FTM1_Isr

#undef  VECTOR_060
#define VECTOR_060 FTM2_Isr

#undef  VECTOR_068
#define VECTOR_068 PDB0_Isr 

#undef  VECTOR_075
#define VECTOR_075		porta_isr

#undef  VECTOR_077
#define VECTOR_077		portc_isr

#undef  VECTOR_079
#define VECTOR_079		porte_isr

#endif  //__ISR_H

/* End of "isr.h" */
