#include "adc16.h"


extern tADC_Config Master_Adc_Config;  
extern tADC_Cal_Blk CalibrationStore[2];




void adc1_differential_channel_init(void){   
        uint8_t cal_ok;
        
   /* Turn on the ADC1 clocks */

       SIM_SCGC6 |= (SIM_SCGC6_ADC1_MASK );  
  /* setup the initial configuration */
       Master_Adc_Config.CONFIG1  = ADLPC_NORMAL | ADC_CFG1_ADIV(ADIV_4) | ADLSMP_LONG | ADC_CFG1_MODE(MODE_16)| ADC_CFG1_ADICLK(0);  
       Master_Adc_Config.CONFIG2  = MUXSEL_ADCA | ADACKEN_DISABLED | ADHSC_HISPEED | ADC_CFG2_ADLSTS(ADLSTS_20) ;
       Master_Adc_Config.COMPARE1 = 0x1234u ; 
       Master_Adc_Config.COMPARE2 = 0x5678u ;
       Master_Adc_Config.STATUS2  = ADTRG_SW | ACFE_DISABLED | ACFGT_GREATER | ACREN_DISABLED | DMAEN_DISABLED | ADC_SC2_REFSEL(REFSEL_EXT);
       Master_Adc_Config.STATUS3  = CAL_OFF | ADCO_SINGLE | AVGE_DISABLED | ADC_SC3_AVGS(AVGS_32);
//       Master_Adc_Config.PGA      = PGAEN_DISABLED | PGACHP_NOCHOP | PGALP_NORMAL | ADC_PGA_PGAG(PGAG_64);
       Master_Adc_Config.STATUS1A = AIEN_OFF | DIFF_DIFFERENTIAL | ADC_SC1_ADCH(31);       
       Master_Adc_Config.STATUS1B = AIEN_OFF | DIFF_DIFFERENTIAL | ADC_SC1_ADCH(31);          

       ADC_Config_Alt(ADC1_BASE_PTR, &Master_Adc_Config);  // config ADC
       cal_ok = ADC_Cal(ADC1_BASE_PTR);                    // do the calibration
       cal_ok = cal_ok+0;
      ADC_Read_Cal(ADC1_BASE_PTR,&CalibrationStore[1]);   // store the cal   
       ADC_Config_Alt(ADC1_BASE_PTR, &Master_Adc_Config);  // config ADC
       
}    

void adc1_differential_channel1(void) {
         ADC1_SC1A = DIFF_DIFFERENTIAL | ADC_SC1_ADCH(1);    // Start conversion 

}

  