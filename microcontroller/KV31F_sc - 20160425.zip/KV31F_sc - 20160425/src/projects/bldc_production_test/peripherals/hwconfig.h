/*****************************************************************************
 * (c) Copyright 2010, Freescale Semiconductor Inc.
 * ALL RIGHTS RESERVED.
 ***************************************************************************//*!
 * @file      hwconfig.h
 * @author    R55013
 * @version   1.0.3.0
 * @date      Nov-27-2013
 * @brief     H/W configuration.
 ******************************************************************************/
#ifndef __HWCONFIG_H
#define __HWCONFIG_H

/******************************************************************************
* Constants
******************************************************************************/
/* 
   [powerstage signal]      [cpu signal]
    I_SENSE_DCB              ADC1_SE18
    BEMF_SENSE_A/B/C         ADC0_SE8 / ADC1_DP0 / ADC0_DP0
    V_SENSE_DCB              ADC0_SE13
*/

#define ADC_CHANNEL_DCBI        18
#define ADC_CHANNEL_DCBV        13
#define ADC_CHANNEL_PHASEA      8
#define ADC_CHANNEL_PHASEB      0
#define ADC_CHANNEL_PHASEC      0
#define ADC_CHANNEL_DISABLED    31



#define ISR_PRIORITY_ADC0       1       // zero-cross, sensorless control
#define ISR_PRIORITY_SLOW_TIMER 3       // speed control loop (low ISR priority)
#define ISR_PRIORITY_FORCED_CMT 1       // forced commutation (when missed sensorless cmt, open loop, timing)
#define ISR_PRIORITY_PDB0       1       // PDB trigger error clearing
#define ISR_PRIORITY_PTA        3       // port A interrupt (demo mode on/off)

#define CPU_CLOCK               96000000UL
#define CPU_CLOCK_KHZ           (CPU_CLOCK / 1000)
#define BUS_CLOCK               (CPU_CLOCK / 4)
#define TIMER_FREQUENCY         (BUS_CLOCK / 64)       // 375 kHz @ 96 MHz
#define TIMER_1MS_CONST         (TIMER_FREQUENCY / 1000)
#define SLOW_TIMER_PERIOD       (BUS_CLOCK /1000)   // 1 ms period (slow control timer uses divider by 2 and cpu clock)
#define PWM_MODULO              1200                // 20 kHz = 1200 @ 96 MHz
#define UART_BAUDRATE           9600

/******************************************************************************
* Types
******************************************************************************/
typedef struct
{
    char mask;
    char swap;
} Pwm_sChannelControl;

/******************************************************************************
* Global variables
******************************************************************************/
extern const unsigned short bldcAdc0SectorCfg[8];
extern const unsigned short bldcAdc1SectorCfg[8];
extern const unsigned short bldcAdcSelCfg[8];
extern const Pwm_sChannelControl bldcCommutationTableComp[8];


/******************************************************************************/
#endif /* __HWCONFIG_H */
