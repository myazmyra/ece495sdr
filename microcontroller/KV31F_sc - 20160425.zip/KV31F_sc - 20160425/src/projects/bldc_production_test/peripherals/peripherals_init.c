/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2004-2011 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   peripherals_init.c
*
* @brief  Init functions
*        
* @version 1.0.3.0
* 
* @date Nov-27-2013
* 
*******************************************************************************/
#include "peripherals_init.h"
#include "hwconfig.h"
#include "uart.h"
#include "smc.h"

/******************************************************************************
* Constants and macros
******************************************************************************/
#define TWO_POWER_N_SAMPLES  6  /* select carefully - COP timer not updated */

/******************************************************************************
* Local variables
******************************************************************************/
const Pwm_sChannelControl bldcCommutationTableComp[8] = { // mask, swap
                                                    {0x30,0x02},    // [0] - sector 0
                                                    {0x0C,0x04},    // [1] - sector 1
                                                    {0x03,0x04},    // [2] - sector 2
                                                    {0x30,0x01},    // [3] - sector 3
                                                    {0x0C,0x01},    // [4] - sector 4
                                                    {0x03,0x02},    // [5] - sector 5
                                                    {0x00,0x06},    // [6] - alignment vector (combination of sectors 0 & 1)
                                                    {0x3F,0x00},    // [7] - PWM Off
                                                  };
/*const unsigned short bldcAdc0SectorCfg[8] = {ADC_CHANNEL_PHASEC, ADC_CHANNEL_PHASEB, ADC_CHANNEL_PHASEA,
                                            ADC_CHANNEL_PHASEC, ADC_CHANNEL_PHASEB, ADC_CHANNEL_PHASEA,
                                            ADC_CHANNEL_PHASEA, ADC_CHANNEL_PHASEA*/


const unsigned short bldcAdc0SectorCfg[8] = {ADC_CHANNEL_PHASEC, ADC_CHANNEL_PHASEC, ADC_CHANNEL_PHASEA,
                                            ADC_CHANNEL_PHASEC, ADC_CHANNEL_PHASEA, ADC_CHANNEL_PHASEA,
                                            ADC_CHANNEL_PHASEA, ADC_CHANNEL_PHASEA};   
const unsigned short bldcAdc1SectorCfg[8] = {ADC_CHANNEL_PHASEB, ADC_CHANNEL_PHASEB, ADC_CHANNEL_PHASEB,
                                            ADC_CHANNEL_PHASEB, ADC_CHANNEL_PHASEB, ADC_CHANNEL_PHASEB,
                                            ADC_CHANNEL_PHASEB, ADC_CHANNEL_PHASEB}; 
const unsigned short bldcAdcSelCfg[8] = {0, 1, 0, 0, 1, 0, 0, 0};   



/*
LED_red - PTD1 - ALT1
LED_green - PTD7 - ALT1

Brake control - none
SW2 - PTE4 - ALT1
SW1 - PTA4 - ALT1

PWM0 - AT - PTC1  - ALT4
PWM1 - AB - PTC2  - ALT4
PWM2 - BT - PTC5  - ALT7
PWM3 - BB - PTC4  - ALT4
PWM4 - CT - PTD4  - ALT4
PWM5 - CB - PTD5  - ALT4

RXD0 - PTB16 - ALT3
TXD0 - PTB17 - ALT3
*/

/*************************************************************************
 * Function Name: Clock_init
 * Parameters: none
 * Return: none
 * Description: Clock initialization
 *************************************************************************/
void Clock_init(void)
{
  //int mcg_clock_hz;
  
  // Enable clock to all peripherals
  SIM_BASE_PTR->SCGC4 = SIM_SCGC4_EWM_MASK | SIM_SCGC4_I2C0_MASK | SIM_SCGC4_UART0_MASK | SIM_SCGC4_UART1_MASK | SIM_SCGC4_CMP_MASK;
  SIM_BASE_PTR->SCGC5 = SIM_SCGC5_LPTMR_MASK | SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTD_MASK | SIM_SCGC5_PORTE_MASK;
  SIM_BASE_PTR->SCGC6 = SIM_SCGC6_FTF_MASK | SIM_SCGC6_DMAMUX_MASK | SIM_SCGC6_SPI0_MASK | SIM_SCGC6_CRC_MASK | SIM_SCGC6_PDB_MASK | \
              SIM_SCGC6_FTM0_MASK | SIM_SCGC6_FTM1_MASK | SIM_SCGC6_FTM2_MASK | SIM_SCGC6_ADC0_MASK | SIM_SCGC6_ADC1_MASK | SIM_SCGC6_DAC0_MASK; 
  SIM_BASE_PTR->SCGC7 = SIM_SCGC7_DMA_MASK;

  // clock setting to 75 MHz
  //SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(0) | SIM_CLKDIV1_OUTDIV4(2) ;  // system clock = MCGOUTCLK ; Flash Clock (bus clock) = MCGOUTCLK / 3
  //MCG_C4 |= MCG_C4_DRST_DRS(2); //Mid-high Frequency Range - 60�75 MHz
  //fei_fee(10000000, 0, 1);// transition from FEI to FEE mode
  //clk_monitor_0(1); // clock monitor enable
  
  // clock setting to 96 MHz, internal 32768 Hz reference clock oscilator
  SIM_BASE_PTR->CLKDIV1 = SIM_CLKDIV1_OUTDIV1(0) | SIM_CLKDIV1_OUTDIV2(3) | SIM_CLKDIV1_OUTDIV3(3) | SIM_CLKDIV1_OUTDIV4(3) ;  // system clock = MCGOUTCLK ; Flash Clock (bus clock) = MCGOUTCLK / 3
  MCG_BASE_PTR->C1 |= MCG_C1_IREFS_MASK; 
  MCG_BASE_PTR->C4 |= MCG_C4_DRST_DRS(3) | MCG_C4_DMX32_MASK; //Reference 32768 Hz, PLL factor 2929, 96 MHz
  
}

/*************************************************************************
 * Function Name: ADC_init
 * Parameters: none
 * Return: none
 * Description: ADC0 & ADC1 module initialization
 *************************************************************************/
int ADC_init(void)
{
long tmp=0;
unsigned long tmp_1[7] = {0,0,0,0,0,0,0}, tmp_2[7] = {0,0,0,0,0,0,0}; 
register uint16 i = 0, numLoops = ((uint16) 1 << TWO_POWER_N_SAMPLES);
tADC_CALIB adc_calib;

  /* ADC calibration */
  // Bus clock / 1 (24 MHz), 12-bit, Bus clock source
  ADC0_BASE_PTR->CFG1 = ADC_CFG1_ADIV(0) | ADC_CFG1_MODE(1) | ADC_CFG1_ADICLK(0);
  ADC1_BASE_PTR->CFG1 = ADC_CFG1_ADIV(0) | ADC_CFG1_MODE(1) | ADC_CFG1_ADICLK(0);
  // high-speed mode, 2 extra ADC clock cycles; 6 ADCK cycles sample time
  ADC0_BASE_PTR->CFG2 = ADC_CFG2_ADHSC_MASK | ADC_CFG2_ADLSTS(3);
  ADC1_BASE_PTR->CFG2 = ADC_CFG2_ADHSC_MASK | ADC_CFG2_ADLSTS(3);
  ADC0_BASE_PTR->SC2  = ADC_SC2_REFSEL(0);
  ADC1_BASE_PTR->SC2  = ADC_SC2_REFSEL(0);
  
  /* ADC0 calibration loop */
  while ((i++) < numLoops)
  { 
    /* The input channel, conversion mode continuous function, compare      */
    /* function, resolution mode, and differential/single-ended mode are    */
    /* all ignored during the calibration function.                         */
    ADC0_BASE_PTR->SC1[0] = 0x1f;
    ADC0_BASE_PTR->SC3  = ADC_SC3_AVGS(0) & (~ADC_SC3_CAL_MASK);
    ADC0_BASE_PTR->SC3 |= ADC_SC3_CAL_MASK;
    while (!(ADC0_BASE_PTR->SC1[0] & ADC_SC1_COCO_MASK));
    
    if (ADC0_BASE_PTR->SC3 & ADC_SC3_CALF_MASK) { ADC0_BASE_PTR->SC3 |= ADC_SC3_CALF_MASK; return 1; }
    
    tmp += (short int) ADC0_BASE_PTR->OFS;
    
    tmp_1[0]+=(unsigned long)ADC0_BASE_PTR->CLP0;
    tmp_1[1]+=(unsigned long)ADC0_BASE_PTR->CLP1;
    tmp_1[2]+=(unsigned long)ADC0_BASE_PTR->CLP2;
    tmp_1[3]+=(unsigned long)ADC0_BASE_PTR->CLP3;
    tmp_1[4]+=(unsigned long)ADC0_BASE_PTR->CLP4;
    tmp_1[5]+=(unsigned long)ADC0_BASE_PTR->CLPS;
    tmp_1[6]+=(unsigned long)ADC0_BASE_PTR->CLPD;
    
    tmp_2[0]+=(unsigned long)ADC0_BASE_PTR->CLM0;
    tmp_2[1]+=(unsigned long)ADC0_BASE_PTR->CLM1;
    tmp_2[2]+=(unsigned long)ADC0_BASE_PTR->CLM2;
    tmp_2[3]+=(unsigned long)ADC0_BASE_PTR->CLM3;
    tmp_2[4]+=(unsigned long)ADC0_BASE_PTR->CLM4;
    tmp_2[5]+=(unsigned long)ADC0_BASE_PTR->CLMS;
    tmp_2[6]+=(unsigned long)ADC0_BASE_PTR->CLMD;
  }
  adc_calib.OFS  = tmp >> TWO_POWER_N_SAMPLES;
  
  adc_calib.CLP[0] = tmp_1[0] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[1] = tmp_1[1] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[2] = tmp_1[2] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[3] = tmp_1[3] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[4] = tmp_1[4] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLPS   = tmp_1[5] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLPD   = tmp_1[6] >> TWO_POWER_N_SAMPLES;    
  
  tmp = tmp_1[0]+tmp_1[1]+tmp_1[2]+tmp_1[3]+tmp_1[4]+tmp_1[5];
  adc_calib.PG  = ((tmp>>(1+TWO_POWER_N_SAMPLES))|0x8000);
  
  adc_calib.CLM[0] = tmp_2[0] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[1] = tmp_2[1] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[2] = tmp_2[2] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[3] = tmp_2[3] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[4] = tmp_2[4] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLMS   = tmp_2[5] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLMD   = tmp_2[6] >> TWO_POWER_N_SAMPLES;    
  
  tmp = tmp_2[0]+tmp_2[1]+tmp_2[2]+tmp_2[3]+tmp_2[4]+tmp_2[5];
  adc_calib.MG  = ((tmp>>(1+TWO_POWER_N_SAMPLES))|0x8000);
  
  ADC0_BASE_PTR->CLP0 = adc_calib.CLP[0]; 
  ADC0_BASE_PTR->CLP1 = adc_calib.CLP[1];
  ADC0_BASE_PTR->CLP2 = adc_calib.CLP[2];
  ADC0_BASE_PTR->CLP3 = adc_calib.CLP[3];
  ADC0_BASE_PTR->CLP4 = adc_calib.CLP[4];
  ADC0_BASE_PTR->CLPS = adc_calib.CLPS;
  ADC0_BASE_PTR->CLPD = adc_calib.CLPD;  
  ADC0_BASE_PTR->CLM0 = adc_calib.CLM[0];
  ADC0_BASE_PTR->CLM1 = adc_calib.CLM[1];
  ADC0_BASE_PTR->CLM2 = adc_calib.CLM[2];
  ADC0_BASE_PTR->CLM3 = adc_calib.CLM[3];
  ADC0_BASE_PTR->CLM4 = adc_calib.CLM[4];
  ADC0_BASE_PTR->CLMS = adc_calib.CLMS;
  ADC0_BASE_PTR->CLMD = adc_calib.CLMD;
  ADC0_BASE_PTR->PG   = adc_calib.PG; 
  ADC0_BASE_PTR->MG   = adc_calib.MG; 
  ADC0_BASE_PTR->OFS  = adc_calib.OFS;  
  /* End of ADC0 calibration */
  
  /* ADC1 calibration loop */
  for(i = 0; i < 8; i++)
  {
    tmp_1[i] = 0; 
    tmp_2[i] = 0;
  }
  i = 0; 
  tmp = 0;
  
  while ((i++) < numLoops)
  { 
    /* The input channel, conversion mode continuous function, compare      */
    /* function, resolution mode, and differential/single-ended mode are    */
    /* all ignored during the calibration function.                         */
    ADC1_BASE_PTR->SC1[0] = 0x1f;
    ADC1_BASE_PTR->SC3  = ADC_SC3_AVGS(0) & (~ADC_SC3_CAL_MASK);
    ADC1_BASE_PTR->SC3 |= ADC_SC3_CAL_MASK;
    while (!(ADC1_BASE_PTR->SC1[0] & ADC_SC1_COCO_MASK));
    
    if (ADC1_BASE_PTR->SC3 & ADC_SC3_CALF_MASK) { ADC1_BASE_PTR->SC3 |= ADC_SC3_CALF_MASK; return 1; }
    
    tmp += (short int) ADC1_BASE_PTR->OFS;
    
    tmp_1[0]+=(unsigned long)ADC1_BASE_PTR->CLP0;
    tmp_1[1]+=(unsigned long)ADC1_BASE_PTR->CLP1;
    tmp_1[2]+=(unsigned long)ADC1_BASE_PTR->CLP2;
    tmp_1[3]+=(unsigned long)ADC1_BASE_PTR->CLP3;
    tmp_1[4]+=(unsigned long)ADC1_BASE_PTR->CLP4;
    tmp_1[5]+=(unsigned long)ADC1_BASE_PTR->CLPS;
    tmp_1[6]+=(unsigned long)ADC1_BASE_PTR->CLPD;
    
    tmp_2[0]+=(unsigned long)ADC1_BASE_PTR->CLM0;
    tmp_2[1]+=(unsigned long)ADC1_BASE_PTR->CLM1;
    tmp_2[2]+=(unsigned long)ADC1_BASE_PTR->CLM2;
    tmp_2[3]+=(unsigned long)ADC1_BASE_PTR->CLM3;
    tmp_2[4]+=(unsigned long)ADC1_BASE_PTR->CLM4;
    tmp_2[5]+=(unsigned long)ADC1_BASE_PTR->CLMS;
    tmp_2[6]+=(unsigned long)ADC1_BASE_PTR->CLMD;
  }
  adc_calib.OFS  = tmp >> TWO_POWER_N_SAMPLES;
  
  adc_calib.CLP[0] = tmp_1[0] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[1] = tmp_1[1] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[2] = tmp_1[2] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[3] = tmp_1[3] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLP[4] = tmp_1[4] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLPS   = tmp_1[5] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLPD   = tmp_1[6] >> TWO_POWER_N_SAMPLES;    
  
  tmp = tmp_1[0]+tmp_1[1]+tmp_1[2]+tmp_1[3]+tmp_1[4]+tmp_1[5];
  adc_calib.PG  = ((tmp>>(1+TWO_POWER_N_SAMPLES))|0x8000);
  
  adc_calib.CLM[0] = tmp_2[0] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[1] = tmp_2[1] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[2] = tmp_2[2] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[3] = tmp_2[3] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLM[4] = tmp_2[4] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLMS   = tmp_2[5] >> TWO_POWER_N_SAMPLES;  
  adc_calib.CLMD   = tmp_2[6] >> TWO_POWER_N_SAMPLES;    
  
  tmp = tmp_2[0]+tmp_2[1]+tmp_2[2]+tmp_2[3]+tmp_2[4]+tmp_2[5];
  adc_calib.MG  = ((tmp>>(1+TWO_POWER_N_SAMPLES))|0x8000);
  
  ADC1_BASE_PTR->CLP0 = adc_calib.CLP[0]; 
  ADC1_BASE_PTR->CLP1 = adc_calib.CLP[1];
  ADC1_BASE_PTR->CLP2 = adc_calib.CLP[2];
  ADC1_BASE_PTR->CLP3 = adc_calib.CLP[3];
  ADC1_BASE_PTR->CLP4 = adc_calib.CLP[4];
  ADC1_BASE_PTR->CLPS = adc_calib.CLPS;
  ADC1_BASE_PTR->CLPD = adc_calib.CLPD;  
  ADC1_BASE_PTR->CLM0 = adc_calib.CLM[0];
  ADC1_BASE_PTR->CLM1 = adc_calib.CLM[1];
  ADC1_BASE_PTR->CLM2 = adc_calib.CLM[2];
  ADC1_BASE_PTR->CLM3 = adc_calib.CLM[3];
  ADC1_BASE_PTR->CLM4 = adc_calib.CLM[4];
  ADC1_BASE_PTR->CLMS = adc_calib.CLMS;
  ADC1_BASE_PTR->CLMD = adc_calib.CLMD;
  ADC1_BASE_PTR->PG   = adc_calib.PG; 
  ADC1_BASE_PTR->MG   = adc_calib.MG; 
  ADC1_BASE_PTR->OFS  = adc_calib.OFS; 
  /* End of ADC1 calibration */
   
  /* Enable ADC0 irq */
  enable_irq(39);
  set_irq_priority(39, ISR_PRIORITY_ADC0);
   
  // Bus clock / 1 (24 MHz), 12-bit, Bus clock source
  ADC0_BASE_PTR->CFG1 = ADC_CFG1_ADIV(0) | ADC_CFG1_MODE(1) | ADC_CFG1_ADICLK(0);
  ADC1_BASE_PTR->CFG1 = ADC_CFG1_ADIV(0) | ADC_CFG1_MODE(1) | ADC_CFG1_ADICLK(0);
  // high-speed mode, 2 extra ADC clock cycles; 6 ADCK cycles sample time
  ADC0_BASE_PTR->CFG2 = ADC_CFG2_ADHSC_MASK | ADC_CFG2_ADLSTS(3);
  ADC1_BASE_PTR->CFG2 = ADC_CFG2_ADHSC_MASK | ADC_CFG2_ADLSTS(3);
  ADC0_BASE_PTR->CV1  = 1;
  ADC1_BASE_PTR->CV1  = 1;
  ADC0_BASE_PTR->CV2  = 1;
  ADC1_BASE_PTR->CV2  = 1;
  // H/W trigger, DMA disabled
  ADC0_BASE_PTR->SC2  = ADC_SC2_ADTRG_MASK | ADC_SC2_REFSEL(0);
  ADC1_BASE_PTR->SC2  = ADC_SC2_ADTRG_MASK | ADC_SC2_REFSEL(0);
  // Average disabled
  ADC0_BASE_PTR->SC3  = ADC_SC3_AVGS(0);
  ADC1_BASE_PTR->SC3  = ADC_SC3_AVGS(0);
  
  // Prepare first meaurement
  // ADC0: DCBI & PHA/C voltage
  ADC0_BASE_PTR->SC1[0] = ADC_CHANNEL_PHASEA;
  ADC0_BASE_PTR->SC1[1] = ADC_CHANNEL_DCBV | ADC_SC1_AIEN_MASK;
  // ADC1: DCBV & PHB voltage, no interrupt
  ADC1_BASE_PTR->SC1[0] = ADC_CHANNEL_PHASEB;
  ADC1_BASE_PTR->SC1[1] = ADC_CHANNEL_DCBI;
  return 0;
}

/*************************************************************************
 * Function Name: PDB_init
 * Parameters: none
 * Return: none
 * Description: PDB module initialization
 *************************************************************************/
void PDB0_init(void)
{
  /* CH0&1: enable pre-trigger 0&1, back2back on pre-tritgger 1 */
  PDB0_BASE_PTR->CH[0].C1 = PDB_C1_TOS(3) | PDB_C1_EN(3) | PDB_C1_BB(2);
  PDB0_BASE_PTR->CH[1].C1 = PDB_C1_TOS(3) | PDB_C1_EN(3) | PDB_C1_BB(2);
  /* CH0&1: pre-trigger 0 delay=middle of pwm period*/
  PDB0_BASE_PTR->CH[0].DLY[0] = PWM_MODULO / 2;
  PDB0_BASE_PTR->CH[1].DLY[0] = PWM_MODULO / 2;
  /* LDOK immediately updates internal registers, enable PDB0 */
  PDB0_BASE_PTR->SC = PDB_SC_LDMOD(0) | PDB_SC_PDBEN_MASK;
  /* Set counters modulo */
  PDB0_BASE_PTR->MOD = 0x7fff;
  /* Internal registers are update upon trigger and LDOK, enable interrupt, no prescaler,
     trig. src 8 (FTM0-EXTTRIG), enable PDB, multiplication factor is 1, set LDOK */
  PDB0_BASE_PTR->SC = PDB_SC_LDMOD(2) | PDB_SC_PDBEIE_MASK | (0 << PDB_SC_PRESCALER_SHIFT) | PDB_SC_TRGSEL(8) | \
            PDB_SC_PDBEN_MASK | (0 << PDB_SC_MULT_SHIFT) | PDB_SC_LDOK_MASK;
  
  /* Enable PDB isr */
  enable_irq(52);
  set_irq_priority(52, ISR_PRIORITY_PDB0);
}

/*************************************************************************
 * Function Name: FTM0_init
 * Parameters: none
 * Return: none
 * Description: FlexTimer 0 initialization
 *************************************************************************/
void FTM0_init(void)
{
  FTM0_BASE_PTR->MODE = FTM_MODE_WPDIS_MASK | FTM_MODE_FTMEN_MASK;
  
  FTM0_BASE_PTR->CNTIN = (unsigned) -PWM_MODULO/2;
  FTM0_BASE_PTR->MOD = PWM_MODULO/2 - 1;       // 20 kHz

  FTM0_BASE_PTR->CONTROLS[0].CnSC = FTM_CnSC_ELSB_MASK;
  FTM0_BASE_PTR->CONTROLS[1].CnSC = FTM_CnSC_ELSB_MASK;
  FTM0_BASE_PTR->CONTROLS[2].CnSC = FTM_CnSC_ELSB_MASK;
  FTM0_BASE_PTR->CONTROLS[3].CnSC = FTM_CnSC_ELSB_MASK;
  FTM0_BASE_PTR->CONTROLS[4].CnSC = FTM_CnSC_ELSB_MASK;
  FTM0_BASE_PTR->CONTROLS[5].CnSC = FTM_CnSC_ELSB_MASK;

  FTM0_BASE_PTR->SYNC = FTM_SYNC_CNTMAX_MASK | FTM_SYNC_SYNCHOM_MASK;     // output mask updated on PWM synchronization (not on rising edge of clock)

  FTM0_BASE_PTR->COMBINE = FTM_COMBINE_SYNCEN2_MASK | FTM_COMBINE_DTEN2_MASK | FTM_COMBINE_COMP2_MASK | FTM_COMBINE_COMBINE2_MASK | \
                 FTM_COMBINE_SYNCEN1_MASK | FTM_COMBINE_DTEN1_MASK | FTM_COMBINE_COMP1_MASK | FTM_COMBINE_COMBINE1_MASK | \
                 FTM_COMBINE_SYNCEN0_MASK | FTM_COMBINE_DTEN0_MASK | FTM_COMBINE_COMP0_MASK | FTM_COMBINE_COMBINE0_MASK;

  // DTPS - deadtime prescaler: 0,1 = 1; 2 = 4; 3 = 16
  // DTVAL - deadtime value (0-63): deadtime period = DTPS x DTVAL
  FTM0_BASE_PTR->DEADTIME = FTM_DEADTIME_DTPS(0) | FTM_DEADTIME_DTVAL(63); 

  FTM0_BASE_PTR->EXTTRIG = FTM_EXTTRIG_INITTRIGEN_MASK;

 // FTM0_BASE_PTR->POL = FTM_POL_POL0_MASK | FTM_POL_POL2_MASK | FTM_POL_POL4_MASK;        // High transistors have negative polarity (MC33927/37)

  /* Following line configures:
     - enhanced PWM synchronization, FTM counter reset on SW sync
     - output SW control / polarity registers updated on PWM synchronization (not on rising edge of clock)
     - output SW control/inverting(swap)/mask registers updated from buffers on SW synchronization */  
  FTM0_BASE_PTR->SYNCONF = FTM_SYNCONF_SYNCMODE_MASK | FTM_SYNCONF_SWRSTCNT_MASK | \
                 FTM_SYNCONF_SWOC_MASK | FTM_SYNCONF_INVC_MASK | \
                 FTM_SYNCONF_SWSOC_MASK | FTM_SYNCONF_SWINVC_MASK | FTM_SYNCONF_SWOM_MASK;
  
  FTM0_BASE_PTR->OUTMASK = FTM_OUTMASK_CH0OM_MASK | FTM_OUTMASK_CH1OM_MASK | FTM_OUTMASK_CH2OM_MASK | FTM_OUTMASK_CH3OM_MASK | FTM_OUTMASK_CH4OM_MASK | FTM_OUTMASK_CH5OM_MASK;

  FTM0_BASE_PTR->CNT = 1;         // update of FTM settings
  
  FTM0_BASE_PTR->SC = FTM_SC_CLKS(1);     // no ISR, counting up, system clock, divide by 1
  
  FTM0_BASE_PTR->CONTROLS[0].CnV = (unsigned) -PWM_MODULO/4;
  FTM0_BASE_PTR->CONTROLS[1].CnV = PWM_MODULO/4;
  FTM0_BASE_PTR->CONTROLS[2].CnV = (unsigned) -PWM_MODULO/4;
  FTM0_BASE_PTR->CONTROLS[3].CnV = PWM_MODULO/4;
  FTM0_BASE_PTR->CONTROLS[4].CnV = (unsigned) -PWM_MODULO/4;
  FTM0_BASE_PTR->CONTROLS[5].CnV = PWM_MODULO/4;

  FTM0_BASE_PTR->SYNC |= FTM_SYNC_SWSYNC_MASK;
  
  FTM0_BASE_PTR->PWMLOAD |= FTM_PWMLOAD_LDOK_MASK;

  // FTM0 PWM output pins
  PORTC_BASE_PTR->PCR[1]  = PORT_PCR_MUX(4); // Drive Strength Enable
  PORTC_BASE_PTR->PCR[2]  = PORT_PCR_MUX(4); // Drive Strength Enable
  PORTC_BASE_PTR->PCR[4]  = PORT_PCR_MUX(4); // Drive Strength Enable
  PORTC_BASE_PTR->PCR[5]  = PORT_PCR_MUX(7); // Drive Strength Enable
  PORTD_BASE_PTR->PCR[4]  = PORT_PCR_MUX(4); // Drive Strength Enable
  PORTD_BASE_PTR->PCR[5] = PORT_PCR_MUX(4); // Drive Strength Enable
 
  PTC_BASE_PTR->PDDR |= (1 << 1) | (1 << 2) | (1 << 4) | (1 << 5);
  PTD_BASE_PTR->PDDR |= (1 << 4) | (1 << 5);
  
}

/*************************************************************************
 * Function Name: FTM1_init
 * Parameters: none
 * Return: none
 * Description: FlexTimer 1 initialization
 *************************************************************************/
void FTM1_init(void)
{
  FTM1_BASE_PTR->MODE = FTM_MODE_WPDIS_MASK | FTM_MODE_FTMEN_MASK;
  // Free running timer
  FTM1_BASE_PTR->MOD = 0xffff;

  // system clock, divide by 128, 1.7777us @ 96 MHz clock
  FTM1_BASE_PTR->SC = FTM_SC_CLKS(1) | FTM_SC_PS(6);

  // Enable Output Compare interrupt, output Compare, Software Output Compare only (ELSnB:ELSnA = 0:0, output pin is not controlled by FTM)
  FTM1_BASE_PTR->CONTROLS[0].CnSC = FTM_CnSC_MSA_MASK | FTM_CnSC_CHIE_MASK;
  
  enable_irq(43);
  set_irq_priority(43, ISR_PRIORITY_FORCED_CMT);
}

/*************************************************************************
 * Function Name: FTM2_init
 * Parameters: none
 * Return: none
 * Description: FlexTimer 2 initialization
 *************************************************************************/
void FTM2_init(void)
{
  FTM2_BASE_PTR->MODE = FTM_MODE_WPDIS_MASK | FTM_MODE_FTMEN_MASK;
  // Free running timer
  FTM2_BASE_PTR->MOD = 0xffff;

  // system clock, divide by 2
  FTM2_BASE_PTR->SC = FTM_SC_CLKS(1) | FTM_SC_PS(0);

  // Enable Output Compare interrupt, output Compare, Software Output Compare only (ELSnB:ELSnA = 0:0, output pin is not controlled by FTM)
  FTM2_BASE_PTR->CONTROLS[0].CnSC = FTM_CnSC_MSA_MASK | FTM_CnSC_CHIE_MASK;
  
  enable_irq(44);
  set_irq_priority(44, ISR_PRIORITY_SLOW_TIMER);
}



/*************************************************************************
 * Function Name: UART0_init
 * Parameters: none
 * Return: none
 * Description: UART port configuration
 *************************************************************************/
void UART0_init(void)
{
  // Pooling mode
  UART0_BASE_PTR->C2 &= ~(UART_C2_TE_MASK|UART_C2_RE_MASK );  /* disable uart operation */

  UART0_BASE_PTR->BDH     |= ((CPU_CLOCK / (UART_BAUDRATE * 16)) >> 8) & 0x1f;
  UART0_BASE_PTR->BDL     = (CPU_CLOCK / (UART_BAUDRATE * 16)) & 0xff;
  
  UART0_BASE_PTR->C1      = 0;
  UART0_BASE_PTR->C2      = UART_C2_TE_MASK | UART_C2_RE_MASK;                           /* enable uart operation  */
  
  // Configure UART0 port pins: PTB16, PTB17 - ALT3
  PORTB_BASE_PTR->PCR[16] = PORT_PCR_MUX(3);
  PORTB_BASE_PTR->PCR[17] = PORT_PCR_MUX(3);
}


/*************************************************************************
 * Function Name: GPIO_init
 * Parameters: none
 * Return: none
 * Description: I/O pins configuration
 *************************************************************************/
void GPIO_init(void)
{
  // LED
  PORTD_BASE_PTR->PCR[1] = PORT_PCR_MUX(1);
  PTD_BASE_PTR->PDDR |= 1 << 1;
  PTD_BASE_PTR->PSOR = 1 << 1;   // Turn off red LED
  
  PORTD_BASE_PTR->PCR[7] = PORT_PCR_MUX(1);
  PTD_BASE_PTR->PDDR |= 1 << 7;
  PTD_BASE_PTR->PSOR = 1 << 7;   // Turn off green LED
  
  // Push buttons: PTA4 = SW2, PTE4 = SW1
  PORTA_BASE_PTR->PCR[4] = PORT_PCR_MUX(1);
  PORTE_BASE_PTR->PCR[4] = PORT_PCR_MUX(1);
  
  /* Enable PTA4 isr */
  PORTA_BASE_PTR->PCR[4] |= PORT_PCR_IRQC(9); // Rising edge interrupt
  enable_irq(59);
  set_irq_priority(59, ISR_PRIORITY_PTA);
}


/*************************************************************************
 * Function Name: FTM0_SetDutyCycle
 * Parameters: duty cycle value
 * Return: none
 * Description: Set PWM dutycycle
 *************************************************************************/
void FTM0_SetDutyCycle(int16 inpDuty)
{
int FirstEdge, SecondEdge, duty;

  duty = MLIB_Mul_F16(inpDuty, PWM_MODULO/4);

  FirstEdge = -PWM_MODULO/4 - duty;
  if (FirstEdge < (-PWM_MODULO/2)) FirstEdge = -PWM_MODULO/2;
  
  SecondEdge = PWM_MODULO/4 + duty;
  if (SecondEdge > (PWM_MODULO/2)) SecondEdge = PWM_MODULO/2;

  FTM0_BASE_PTR->CONTROLS[0].CnV = FirstEdge;
  FTM0_BASE_PTR->CONTROLS[1].CnV = SecondEdge;
  FTM0_BASE_PTR->CONTROLS[2].CnV = FirstEdge;
  FTM0_BASE_PTR->CONTROLS[3].CnV = SecondEdge;
  FTM0_BASE_PTR->CONTROLS[4].CnV = FirstEdge;
  FTM0_BASE_PTR->CONTROLS[5].CnV = SecondEdge;
  FTM0_BASE_PTR->PWMLOAD |= FTM_PWMLOAD_LDOK_MASK;
}

/*************************************************************************
 * Function Name: FTM0_SetPwmOutput
 * Parameters: sector number
 * Return: none
 * Description: set PWM output configuration based on selected sector
 *************************************************************************/
void FTM0_SetPwmOutput(int16 sector)
{ 
  FTM0_BASE_PTR->INVCTRL = bldcCommutationTableComp[sector].swap;
  FTM0_BASE_PTR->OUTMASK = bldcCommutationTableComp[sector].mask;
  
  FTM0_BASE_PTR->SYNC |= FTM_SYNC_SWSYNC_MASK;
}

/*************************************************************************
 * Function Name: MCU_init
 * Parameters: none
 * Return: none
 * Description: initialization of peripheral modules after reset 
 *************************************************************************/
void MCU_init(void)
{
  Clock_init();  
  ADC_init();
  PDB0_init();
  FTM0_init();
  FTM1_init();
  FTM2_init();
//  UART0_init();
  GPIO_init();
}
             

