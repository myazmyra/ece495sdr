/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2004-2011 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   peripherals_init.h
*
* @brief  Init functions
*        
* @version 1.0.2.0
* 
* @date Oct-9-2013
* 
*******************************************************************************/
#ifndef _PERIPHERALS_
#define _PERIPHERALS_

#include "common.h"
#include "mlib.h"
#include "gflib.h"
#include "gdflib.h"
#include "gmclib.h"
#include "mcg.h"


/******************************************************************************
* Local functions
******************************************************************************/
void MCU_init(void);
void Clock_init(void);
void FTM0_init(void);
void FTM1_init(void);
void FTM2_init(void);
void GPIO_init(void);
int ADC_init(void);
void PDB0_init(void);
void UART0_init(void);
void FTM0_SetDutyCycle(int16);
void FTM0_SetPwmOutput(int16 sector);

/******************************************************************************
* Local types
******************************************************************************/
/******************************************************************************
 * ADC calibration data structure definition                                  *
 ******************************************************************************/
typedef struct { uint32 OFS, PG, MG, CLPD, CLPS, CLP[5], CLMD, CLMS, CLM[5]; } tADC_CALIB;


#endif /* _PERIPHERALS_ */