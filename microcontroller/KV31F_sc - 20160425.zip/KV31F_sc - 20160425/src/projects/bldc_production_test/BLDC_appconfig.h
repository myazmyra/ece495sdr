/**********************************************************************/
// File Name: {FM_project_loc}/../../src/projects/kv31/BLDC_Sensorless/BLDC_appconfig.h 
//
// Date:  18. February, 2015
//
// Automatically generated file for static configuration of the BLDC application
/**********************************************************************/

#ifndef __BLDC_CONFIG_SETUP_H
#define __BLDC_CONFIG_SETUP_H


//Motor Parameters                      
//----------------------------------------------------------------------
//Pole-pair number                      = 2 [-]
//Back-EMF constant                     = 0.028648 [V.sec/rad]
//Phase current nominal                 FRAC16(0.202424242424)
//Phase voltage nominal                 FRAC16(0.333333333333)
//----------------------------------------------------------------------

//Application scales                    
#define I_MAX                           (8.25)
#define U_DCB_MAX                       (15.0)
#define N_MAX                           (5000.0)
#define I_DCB_OVERCURRENT               FRAC16(0.848484848485)
#define U_DCB_UNDERVOLTAGE              FRAC16(0.533333333333)
#define U_DCB_OVERVOLTAGE               FRAC16(0.966666666667)
#define I_DCB_LIMIT                     FRAC16(0.363636363636)
#define U_DCB_TRIP                      FRAC16(0.966666666667)
#define N_NOM                           FRAC16(0.800000000000)
#define I_PH_NOM                        FRAC16(0.202424242424)
#define U_PH_NOM                        FRAC16(0.333333333333)
//Mechanical Alignemnt                  
#define ALIGN_CURRENT                   FRAC16(0.242424242424)
#define ALIGN_DURATION                  (500)

//BLDC Control Loop                     
//----------------------------------------------------------------------
//Loop sample time                      = 0.001 [sec]
//----------------------------------------------------------------------
//Control loop limits                   
#define CTRL_LOOP_LIM_HIGH              FRAC16(0.900000000000)
#define CTRL_LOOP_LIM_LOW               FRAC16(0.0)

//Speed Controller - Parallel type      
#define SPEED_LOOP_KP_GAIN              FRAC16(0.307732146035)
#define SPEED_LOOP_KP_SHIFT             (-3)
#define SPEED_LOOP_KI_GAIN              FRAC16(0.249897146924)
#define SPEED_LOOP_KI_SHIFT             (-6)

//Speed ramp increments                 
#define SPEED_LOOP_RAMP_UP              FRAC32(0.004000000000)
#define SPEED_LOOP_RAMP_DOWN            FRAC32(0.004000000000)

//Torque Controller - Parallel type     
#define TORQUE_LOOP_KP_GAIN             FRAC16(0.626560000000)
#define TORQUE_LOOP_KP_SHIFT            (-6)
#define TORQUE_LOOP_KI_GAIN             FRAC16(0.626560000000)
#define TORQUE_LOOP_KI_SHIFT            (-6)
#define TORQUE_LOOP_MAF                 (5)

//Sensoroless Control Module            
//----------------------------------------------------------------------
//Timer Frequency                       = 375000 [Hz]
//----------------------------------------------------------------------
#define N_MIN                           FRAC16(0.060000000000)
#define N_START_TRH                     FRAC16(0.070000000000)
#define STARTUP_CMT_CNT                 (2)
#define STARTUP_CMT_PER                 (15000)
#define CMT_T_OFF                       FRAC16(0.220000000000)
#define FREEWHEEL_T_LONG                (1000)
#define FREEWHEEL_T_SHORT               (500)
#define SPEED_SCALE_CONST               (2250)
#define CMT_PER_MIN                     (375)
#define START_CMT_ACCELER               FRAC16(0.357142857143)
#define INTEG_TRH                       (98304)

//FreeMASTER Scale Variables            
//----------------------------------------------------------------------
//Note: Scaled at input = 1000          
//----------------------------------------------------------------------
#define FM_I_SCALE                      (8250)
#define FM_U_DCB_SCALE                  (15000)
#define FM_N_SCALE                      (5000000)

#endif
/**********************************************************************/
/**********************************************************************/
