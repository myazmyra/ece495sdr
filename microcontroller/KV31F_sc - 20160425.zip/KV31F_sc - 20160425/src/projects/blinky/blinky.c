/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */

#include "common.h"
#include "uart.h"
#include "smc.h"
#include "lptmr.h"
#include "adc16.h"

#define UART_SIGNATURE 0xA0
#define UART_MASK 0xE0
#define BUFFER_MAX 8
#define EEPROM_MAX 114
#define DBOARD_A 0
#define UART_SIZE 8
#define UART_TIME_OUT 8 //(UART_TIME_OUT * (1/8) = seconds til timeout

/*Function declarations */

void i2c0_isr(void);
void i2c1_isr(void);
void pit_isr(void);
void initializeGpio(void);
unsigned int readADC0(int channel);
void initializeUART0(void);
void initializeADC0(void);
void initializePIT0(void);
void initializeI2C(I2C_MemMapPtr I2Cptr,int I2C_address);
void initializeFTM0(void);
void tuneFTM0(int freq, int duty);
unsigned int readHex(void);
void writeGpio(char state);
char checksum(char byte);




const char eeprom_lftx[EEPROM_MAX] = {0x00,0x00,0x01,0x04,0x12,0xFF,0x13,0xFF,0x14,0xFF,0x15,0xFF,0x02,0x00,0x03,0x50,0x04,0xC2,0x05,0x85,0x06,0x33,0x07,0x85,0x0C,0xC0,0x0D,0xA8,0x0E,0x0A,0x0F,0x02,0x08,0xFF,0x09,0xFF,0x0A,0xFF,0x0B,0xFF,0x38,0xFF,0x39,0xFF,0x3A,0xFF,0x3B,0xFF,0x17,0xFF,0x18,0xFF,0x19,0xFF,0x1A,0xFF,0x1B,0xFF,0x1C,0xFF,0x1D,0xFF,0x1E,0xFF,0x1F,0xFF,0x20,0xFF,0x21,0xFF,0x22,0xFF,0x23,0xFF,0x24,0xFF,0x25,0xFF,0x26,0xFF,0x27,0xFF,0x28,0xFF,0x29,0xFF,0x2A,0xFF,0x2B,0xFF,0x2C,0xFF,0x2D,0xFF,0x2E,0xFF,0x2F,0xFF,0x30,0xFF,0x31,0xFF,0x32,0xFF,0x33,0xFF,0x34,0xFF,0x35,0xFF,0x36,0xFF,0x37,0xFF};
const char eeprom_lfrx[EEPROM_MAX] = {0x00,0x00,0x01,0x04,0x12,0xFF,0x13,0xFF,0x14,0xFF,0x15,0xFF,0x02,0x00,0x03,0x50,0x04,0xC2,0x05,0x85,0x06,0x33,0x07,0x85,0x0C,0xC0,0x0D,0xA8,0x0E,0x0A,0x0F,0x02,0x08,0xFF,0x09,0xFF,0x0A,0xFF,0x0B,0xFF,0x38,0xFF,0x39,0xFF,0x3A,0xFF,0x3B,0xFF,0x17,0xFF,0x18,0xFF,0x19,0xFF,0x1A,0xFF,0x1B,0xFF,0x1C,0xFF,0x1D,0xFF,0x1E,0xFF,0x1F,0xFF,0x20,0xFF,0x21,0xFF,0x22,0xFF,0x23,0xFF,0x24,0xFF,0x25,0xFF,0x26,0xFF,0x27,0xFF,0x28,0xFF,0x29,0xFF,0x2A,0xFF,0x2B,0xFF,0x2C,0xFF,0x2D,0xFF,0x2E,0xFF,0x2F,0xFF,0x30,0xFF,0x31,0xFF,0x32,0xFF,0x33,0xFF,0x34,0xFF,0x35,0xFF,0x36,0xFF,0x37,0xFF};
int eeprom_ptr = 0;
int i2cCounter = 0;
int i2c_dump = 0; 
int i2c0StartCount = 0; //Keeps track of repeated i2c start bits
char i2c1Data = 0; 
int i2c1StartCount = 0; //Keeps track of repeated i2c start bits
int e_buffer[BUFFER_MAX] = {0,0,0,0,0,0,0,0}; //Samples from envelope
int buffer_in = 0; //pointer for e_buffer
long buffer_avg = 0; //arithmetic average of e_buffer
int comp_out = 0; //Sample from comparator threshold
char uart_rx;
char pitCounter = 0;
char UART_buffer[UART_SIZE] = {'t','e','s','t','.','b','m','p'};
char I2C_buffer[UART_SIZE] = {'0','0','0','0','.','b','m','p'};
char UART_count = 0;
char I2C_count = 0;
char UART_error = 0;
char UART_timeout_cnt = 0;
char heartbeatON = 1;
int i_index = 0;;
int j_index = 0;


void main (void)
{

        printf("\nRunning the 'blinky' project running at %s %d MHz \n",
		   BRD_STRING, BRD_SYSCLOCK);
        
        /**************** BEGIN INITIALIZATIONS *******************************/
        
        /* Enable GPIOC interrupts in NVIC */
        //enable_irq(61);		/* GPIOC Vector is 77. IRQ# is 77-16=61 */
	//enable_irq(63);		/* GPIOC Vector is 79. IRQ# is 79-16=63 */
        //enable_irq(59);        // Interrupt priority for PORTA
        enable_irq(40 - 16); //I2C0 interrupt
        enable_irq(41 - 16); //I2C1 interrupt
        enable_irq(64 - 16); //PIT Interrupt
     
       
        /* Enable Interrupts globally */
        EnableInterrupts;
           
        
        //initializeI2C(I2C0_BASE_PTR,0x50); //Eeeprom @ address 0x50
        initializeI2C(I2C1_BASE_PTR,0x10); //Microcontroller @ address 0x10
        #if DBOARD_A
          initializeADC0();
          ADC_Cal(ADC0_BASE_PTR);
          initializeFTM0();
        #else
          initializeGpio();
        #endif
        initializeUART0();
        initializePIT0();
        /**************** END INITIALIZATIONS *******************************/

       /**************** MAIN PROGRAM *******************************/
	while(1)
	{
 
            //time_delay_ms(1000);
            #if DBOARD_A
              uart_rx = uart_getchar(UART1_BASE_PTR); //Wait for uart
              
              //If i2c1data doesnt exit and a non-zero byte was received, put uart byte into buffer
              if(uart_rx != 0)
              {
                UART_buffer[UART_count] = uart_rx;
                UART_count++;
                if(UART_count >= UART_SIZE) //message received
                {
                  //check for errors
                  UART_error = 0;
                  for(i_index = 0; i_index < UART_SIZE; i_index++)
                  {
                    if((UART_buffer[i_index] & 0x80) != (checksum(UART_buffer[i_index] & 0x7F) << 7))
                    {
                      UART_error = 1;
                      break;
                    }
                    UART_buffer[i_index] = UART_buffer[i_index] & 0x7F; //Remove checksum
                  }
                  
                  //If no errors and I2C hasnt asked for data yet, then pass to I2C
                  if(!UART_error && !I2C_count)
                  {
                    for(i_index = 0; i_index < UART_SIZE; i_index++)
                    {
                      I2C_buffer[i_index] = UART_buffer[i_index];
                    }
                     i2c1Data = 1;
                  }
                  
                  UART_count = 0; //Reset UART counter
                  UART_timeout_cnt = 0; //End the timeout count
                }
              }
              
            #else

            #endif
            
	}
}
void initializeUART0(void)
{
  //****** had to use uart1 due to pin limitations on frdm boards ****** 
  
  //Select uart pins RX on PTC3 (pin73) and TX on PTC4 (pin 76)
  SIM_BASE_PTR->SOPT5 &= ~SIM_SOPT5_UART1RXSRC_MASK;
  SIM_BASE_PTR->SOPT5 &= ~SIM_SOPT5_UART1TXSRC_MASK;
  PORTC_BASE_PTR->PCR[3] |= PORT_PCR_MUX_MASK & (3 << PORT_PCR_MUX_SHIFT);
  PORTC_BASE_PTR->PCR[4] |= PORT_PCR_MUX_MASK & (3 << PORT_PCR_MUX_SHIFT);


  //Enable clock
  SIM_BASE_PTR->SCGC4 |= SIM_SCGC4_UART1_MASK;
  
  //intialize at 100 baud
  uart_init(UART1_BASE_PTR, 80000, 611);
  #if BOARD_A
  
  #else
    //invert uart tx levels
    //UART1_BASE_PTR->C3 |= UART_C3_TXINV_MASK;
  #endif
}
void initializePIT0(void)
{
        //Enable clock to timer, timer continues to run in debug mode
        SIM_BASE_PTR->SCGC6 |= SIM_SCGC6_PIT_MASK;
        PIT_BASE_PTR->MCR  = 0;
        
        #if DBOARD_A
          /*Initialize timer start value for 1/8 second
          LDVAL = desired period/ clock period (PIT Clock runs at 50 MHz)
          */
          PIT_BASE_PTR->CHANNEL[0].LDVAL = 0x5F5E10;
        #else
          /*Initialize timer start value for 1/4 second
          LDVAL = desired period/ clock period (PIT Clock runs at 50 MHz)
          */
          PIT_BASE_PTR->CHANNEL[0].LDVAL = 0xBEBC20;
        #endif
 
        
        //Chain mode disabled, interrupt enabled, timer enabled
        PIT_BASE_PTR->CHANNEL[0].TCTRL = 0x03;
}
void initializeI2C(I2C_MemMapPtr I2Cptr,int I2C_address)
{
        
        int I2C_masterMode = 0; //0 for slave, 1 for master
        
        if(I2Cptr == I2C0_BASE_PTR)
        {
          //Clock Enabled to I2C0
          SIM_BASE_PTR->SCGC4 &= ~SIM_SCGC4_I2C0_MASK;
          SIM_BASE_PTR->SCGC4 |= SIM_SCGC4_I2C0_MASK & (1 << SIM_SCGC4_I2C0_SHIFT);
          
          //Map PORTC[6] (Pin 78 on 100 LQFP) to ALT7 (I2C0_SCL)
          //Enable open drain, disable pull up
          PORTC_BASE_PTR->PCR[6] &= ~PORT_PCR_MUX_MASK;
          PORTC_BASE_PTR->PCR[6] |= PORT_PCR_MUX_MASK & (0x07u << PORT_PCR_MUX_SHIFT);
          PORTC_BASE_PTR->PCR[6] |= PORT_PCR_ODE_MASK;
          PORTC_BASE_PTR->PCR[6] &= ~PORT_PCR_PE_MASK;
          
          //Map PORTC[7] (Pin 79 on 100 LQFP) to ALT7 (I2C0_SDA)
          //Enable open drain, disable pull up
          PORTC_BASE_PTR->PCR[7] &= ~PORT_PCR_MUX_MASK;
          PORTC_BASE_PTR->PCR[7] |= PORT_PCR_MUX_MASK & (0x07u << PORT_PCR_MUX_SHIFT);
          PORTC_BASE_PTR->PCR[7] |= PORT_PCR_ODE_MASK;
          PORTC_BASE_PTR->PCR[7] &= ~PORT_PCR_PE_MASK;
          
          //Set slave I2C0 address
          I2C0_BASE_PTR->A1 &= ~I2C_A1_AD_MASK;
          I2C0_BASE_PTR->A1 |=  I2C_A1_AD_MASK & (I2C_address << I2C_A1_AD_SHIFT);
        }else if(I2Cptr == I2C1_BASE_PTR)
        {
          //Clock Enabled to I2C1
          SIM_BASE_PTR->SCGC4 &= ~SIM_SCGC4_I2C1_MASK;
          SIM_BASE_PTR->SCGC4 |= SIM_SCGC4_I2C1_MASK & (1 << SIM_SCGC4_I2C1_SHIFT);
          
          //Map PORTC[10] (Pin 82 on 100 LQFP) to ALT2 (I2C1_SCL)
          //Enable open drain, disable pull up
          PORTC_BASE_PTR->PCR[10] &= ~PORT_PCR_MUX_MASK;
          PORTC_BASE_PTR->PCR[10] |= PORT_PCR_MUX_MASK & (0x02u << PORT_PCR_MUX_SHIFT);
          PORTC_BASE_PTR->PCR[10] |= PORT_PCR_ODE_MASK;
          PORTC_BASE_PTR->PCR[10] &= ~PORT_PCR_PE_MASK;
          
          //Map PORTC[11] (Pin 83 on 100 LQFP) to ALT2 (I2C1_SDA)
          //Enable open drain, disable pull up
          PORTC_BASE_PTR->PCR[11] &= ~PORT_PCR_MUX_MASK;
          PORTC_BASE_PTR->PCR[11] |= PORT_PCR_MUX_MASK & (0x02u << PORT_PCR_MUX_SHIFT);
          PORTC_BASE_PTR->PCR[11] |= PORT_PCR_ODE_MASK;
          PORTC_BASE_PTR->PCR[11] &= ~PORT_PCR_PE_MASK;
          
          //Set slave I2C1 address
          I2C1_BASE_PTR->A1 &= ~I2C_A1_AD_MASK;
          I2C1_BASE_PTR->A1 |=  I2C_A1_AD_MASK & (I2C_address << I2C_A1_AD_SHIFT);
        }
        
 
        
        //Set I2C0 Frequency Division
        //MULT = multiply factor
        //ICR = I2C clock rate
        //I2C baud rate = I2C module clock speed (Hz) / (MULT x SLC)
        //I2C0 baud rate set to 100kHz
        I2Cptr->F &= ~(I2C_F_MULT_MASK || I2C_F_ICR_MASK);
        I2Cptr->F |= I2C_F_MULT_MASK & (0x02u << I2C_F_MULT_SHIFT);//(0x10u << I2C_F_MULT_SHIFT);
        I2Cptr->F |= I2C_F_ICR_MASK & (0x00 << I2C_F_ICR_SHIFT);//(100 << I2C_F_ICR_SHIFT);
        
        //Set I2C mode
        I2Cptr->C1 &= ~I2C_C1_MST_MASK;
        I2Cptr->C1 |= I2C_C1_MST_MASK & (I2C_masterMode << I2C_C1_MST_SHIFT);

        //Set address
        //I2Cptr->RA &= ~I2C_RA_RAD_MASK;
        //I2Cptr->RA |= I2C_RA_RAD_MASK & (/*I2C_address*/ 0xFE << I2C_RA_RAD_SHIFT);
        
        //Allow the slave to run at a different baud rate than master
        I2Cptr->C2 |= I2C_C2_SBRC_MASK;
       
        //Enable Range Address Matching
        //I2Cptr->C2 &= ~I2C_C2_RMEN_MASK;
        //I2Cptr->C2 |= I2C_C2_RMEN_MASK & (1 << I2C_C2_RMEN_SHIFT);

        //Enable I2C0
        I2Cptr->C1 |= I2C_C1_IICEN_MASK & (1 << I2C_C1_IICEN_SHIFT);
        
        //Enable I2C0 interrupts
        I2Cptr->C1 |= I2C_C1_IICIE_MASK;
        I2Cptr->FLT |= I2C_FLT_SSIE_MASK; 
        
        //Enable transmit acknowledge
        I2Cptr->C1 &= ~I2C_C1_TXAK_MASK;
}
unsigned int readHex(void)
{
      char freq0;
      char freq1;
      char freq2;
      char freq3;
      printf("Enter 16 bit hex 0x");
      freq3 = uart_getchar(TERM_PORT);
      printf("%c",freq3);
      freq2 = uart_getchar(TERM_PORT);
      printf("%c",freq2);
      freq1 = uart_getchar(TERM_PORT);
      printf("%c",freq1);
      freq0 = uart_getchar(TERM_PORT);
      printf("%c\n",freq0);
      if((freq3 >= 'A') && (freq3 <= 'F'))
      {
        freq3 = freq3 - 'A' + 10;
      }else
      {
        freq3 = freq3 - '0';
      }
      if((freq2 >= 'A') && (freq2 <= 'F'))
      {
        freq2 = freq2 - 'A' + 10;
      }else
      {
        freq2 = freq2 - '0';
      }
      if((freq1 >= 'A') && (freq1 <= 'F'))
      {
        freq1 = freq1 - 'A' + 10;
      }else
      {
        freq1 = freq1 - '0';
      }
      if((freq0 >= 'A') && (freq0 <= 'F'))
      {
        freq0 = freq0 - 'A' + 10;
      }else
      {
        freq0 = freq0 - '0';
      }
      
      printf("hex = %x\n",(int)freq0 + (((int)freq1) << 4) + (((int)freq2) << 8) + (((int)freq3) << 12));
      return (int)freq0 + (((int)freq1) << 4) + (((int)freq2) << 8) + (((int)freq3) << 12);
}
unsigned int readADC0(int channel)
{
    /*ADC channels are...
      0 ... DADP0
      1 ... DADP1
      2 ... DADP2
      3 ... DADP3
      4 ... AD4
      5 ... AD5
         .
         .
         .
      23 ... AD23
      26 ... TEMP SENSOR
      27 ... Bandgap
      29 ... Vrefsh
      30 ... Vrefsl
      31 ... Module disabled
    */
  
    //Start conversion
    ADC0_BASE_PTR->SC1[0] = channel;
          
    //Wait for conversion to finish
    while((ADC0_BASE_PTR->SC1[0] & ADC_SC1_COCO_MASK) >> ADC_SC1_COCO_SHIFT != 0x1);
    
    return ADC0_BASE_PTR->R[0] & 0xFFFF;
}
void initializeADC0(void)
{
        //Route clock to ADC0
        SIM_BASE_PTR->SCGC6 |= SIM_SCGC6_ADC0_MASK & (1 << SIM_SCGC6_ADC0_SHIFT);
        
        //Route ADC0 to porte[18] (pin 12) and porte[19] (pin 13)
        //PORTB_BASE_PTR->PCR[3] = 0;
        PORTE_BASE_PTR->PCR[18] = 0;
        PORTE_BASE_PTR->PCR[19] = 0;

        
        ADC_Config(ADC0_BASE_PTR, 0x2C, 0x00, 0x0000, 0x0000, 0x00, 0x00, 0x1F, 0x1F, 0x00000000);
}
//freq in HZ, duty in percent from 0 to 100
void tuneFTM0(int freq, int duty)
{
    FTM0_BASE_PTR->MOD = 0xFFFF & (int) ((19916735.04)/(float) freq + 1);

    FTM0_BASE_PTR->SC = 0x00; 
    FTM_CnV_REG(FTM0_BASE_PTR,0) = 0xFFFF & (int)((float) freq/100 * duty);
    FTM0_BASE_PTR->SC = 0x09; 


    //FTM0_BASE_PTR->PWMLOAD |= FTM_PWMLOAD_CH0SEL_MASK;
    FTM0_BASE_PTR->PWMLOAD |= FTM_PWMLOAD_LDOK_MASK;
}
void initializeFTM0(void)
{
  //Initialize as an edge aligned pwm peripheral
  
  //FTM0 channel 0 pin is output of FTM0 Channel output
  SIM_BASE_PTR->SOPT8 &= ~SIM_SOPT8_FTM0OCH0SRC_MASK;
  
  //Enable clock to FTM0
  SIM_BASE_PTR->SCGC6 |= SIM_SCGC6_FTM0_MASK;
  
  //Set portC[1] (pin 71) to alt4 (FTM0_CH0)
  PORTC_BASE_PTR->PCR[1] = PORT_PCR_MUX_MASK & (4 << PORT_PCR_MUX_SHIFT);
  
  //Set Low Drive Strength
  PORTC_BASE_PTR->PCR[1] &= ~PORT_PCR_DSE_MASK;

  
  //Enable FTM0
  FTM0_BASE_PTR->MODE |= FTM_MODE_WPDIS_MASK;
  FTM0_BASE_PTR->MODE |= FTM_MODE_FTMEN_MASK;
  
  //Set quaden to 0
  FTM0_BASE_PTR->QDCTRL &= ~FTM_QDCTRL_QUADEN_MASK;
  
  //Initialize CNT,MOD,CNTIN
  FTM0_BASE_PTR->CNT = 0;
  FTM0_BASE_PTR->MOD = 0x7FFF;
  FTM0_BASE_PTR->CNTIN = 0x0000;
  
  //Setup channel-interrupt status flag control bits
  FTM_CnSC_REG(FTM0_BASE_PTR,0) = 0x28;
  
  //Reset SC register while no clock is fed to timer
  FTM0_BASE_PTR->SC = 0x00; 
  
    //Initialize CnV
  FTM_CnV_REG(FTM0_BASE_PTR,0) = 0x1FFF;
  
  //combine,decapen,quaden = 0
  FTM0_BASE_PTR->COMBINE &= ~FTM_COMBINE_COMBINE0_MASK;
  FTM0_BASE_PTR->COMBINE &= ~FTM_COMBINE_DECAPEN0_MASK;
  
  //Select system clock, divide clock by 2, CPWMS =0
  FTM0_BASE_PTR->SC = 0x09; 
  
}
/* ISR for PIT */
void pit_isr(void)
{         
      #if DBOARD_A //Derive comparator threshold from envelope and set PWM accordingly
        unsigned int pwm_filter;
        e_buffer[buffer_in] = readADC0(6); //Sample envelope
        buffer_in = (buffer_in + 1) % BUFFER_MAX;
        
        //Average envelope
        buffer_avg = (e_buffer[0]+e_buffer[1]+e_buffer[2]+e_buffer[3]+e_buffer[4]+e_buffer[5]+e_buffer[6]+e_buffer[7])/BUFFER_MAX;
        
        
        //Sample PWM average on channel 7, compare to buffer average and adjust PWM duty
        pwm_filter = readADC0(7);
        if(pwm_filter < (unsigned int) buffer_avg)
        {
          if(pwm_filter + 0xFF < (unsigned int) buffer_avg)
          {
            comp_out+=5;
          }else
          {
            comp_out++;
          }
        }else
        {
          if(comp_out > 0)
          {
            comp_out--;
          }
        }
        tuneFTM0(1000,comp_out); 
        
        //If UART data has been read, start a timeout counter
        //Once the counter reaches UART_TIME_OUT, reset the UART buffer
        //The timeout counter is reset in the main while loop when 
        //a full UART message is received
        if(UART_timeout_cnt > 0) //timeout has started, so keep counting
        {
          UART_timeout_cnt++;
          if(UART_timeout_cnt >= UART_TIME_OUT) //If timeout has reached threshold, then UART data is an error
          {
            UART_count = 0; //Effectively erase UART buffer
            UART_timeout_cnt = 0;
          }
        }else if(UART_count > 0) //atleast a byte of uart detected, start timeout count
        {
          UART_timeout_cnt = 1;
        }
      #else
          //Generate heartbeat and embed uart data if available
          switch(pitCounter)
          {
            case 0:
              writeGpio(1);
              break;
            case 2:
              if(heartbeatON)
              {
                writeGpio(0);
              }
              break;
            case 3:
              /*//TEMP
              j_index++;
              if(j_index == 10)
              {
                j_index = 0;
                UART_count = UART_SIZE;
              }
              //END TEMP */
              
              if(UART_count == UART_SIZE) //Transmit UART if UART_buffer is full
              {
                for(UART_count = 0; UART_count < UART_SIZE; UART_count++)
                {
                  UART_buffer[UART_count] &= 0x7F;
                  UART_buffer[UART_count] |= (checksum(UART_buffer[UART_count]) << 7);
                  uart_putchar(UART1_BASE_PTR, UART_buffer[UART_count]);
                }
                UART_count = 0;
              }
              break;
          }
          pitCounter = (pitCounter + 1) % 4;
      #endif

      PIT_BASE_PTR->CHANNEL[0].TFLG = 1;
}
char checksum(char byte)
{
  int i;
  char sum = 0;
  for(i = 0; i < 8; i++)
  {
    sum += byte & 0x01;
    byte = byte >> 1;
  }
  return(sum % 2);
}
 /* ISR for I2C0 */
void i2c0_isr(void)
{
     //printf("entered i2c0 interrupt\n");
     //printf("addressed = %d\n\n",(I2C0_BASE_PTR->S & I2C_S_IAAS_MASK) >> I2C_S_IAAS_SHIFT);
     //Is stop flag set?
     if((I2C0_BASE_PTR->FLT & I2C_FLT_STOPF_MASK) >> I2C_FLT_STOPF_SHIFT)
     {
       //Clear stop and interrupt flag, reset start log, exit interrupt
       I2C0_BASE_PTR->FLT |= I2C_FLT_STOPF_MASK;
       I2C0_BASE_PTR->S |= I2C_S_IICIF_MASK;
       i2c0StartCount = 0;
       //printf("Stop bit detected\n");
       return;
     }
     //Is start flag set?
     if((I2C0_BASE_PTR->FLT & I2C_FLT_STARTF_MASK) >> I2C_FLT_STARTF_SHIFT)
     {
        //Clear start and interrupt flag, log start count
        I2C0_BASE_PTR->FLT |= I2C_FLT_STARTF_MASK;
        I2C0_BASE_PTR->S |= I2C_S_IICIF_MASK;
        //printf("Start bit detected\n");
        i2c0StartCount++;
        
        //Is this a repeated start? Exit
        if(i2c0StartCount > 1)
        {
          //printf("Repeated start\n");
          return; 
        }
        
     }else
     {
        //Clear interrupt flag
        I2C0_BASE_PTR->S |= I2C_S_IICIF_MASK;
     }

     //Has slave been addressed?
     //printf("addressed = %x\n",(I2C0_BASE_PTR->S & I2C_S_IAAS_MASK));
     //printf("address = %x\n\n",I2C0_BASE_PTR->A1);
     if((I2C0_BASE_PTR->S & I2C_S_IAAS_MASK) >> I2C_S_IAAS_SHIFT) //Slave addressed
     {
      
       //Is slave transmitting data?
       if((I2C0_BASE_PTR->S & I2C_S_SRW_MASK) >> I2C_S_SRW_SHIFT) //Master reading
       {
         //printf("Enter tx mode\n");
         I2C0_BASE_PTR->C1 |= I2C_C1_TX_MASK; //Enter TX mode     
         while(!((I2C0_BASE_PTR->S & I2C_S_RXAK_MASK) >> I2C_S_RXAK_SHIFT))
         {
            #if DBOARD_A
              I2C0_BASE_PTR->D = eeprom_lftx[eeprom_ptr];
            #else
              I2C0_BASE_PTR->D = eeprom_lfrx[eeprom_ptr];
            #endif
            //I2C0_BASE_PTR->S |= I2C_S_TCF_MASK;
         }
         while((!((I2C0_BASE_PTR->FLT & I2C_FLT_STOPF_MASK) >> I2C_FLT_STOPF_SHIFT)))
         {
            I2C0_BASE_PTR->D = 0xFF;
         }
         eeprom_ptr = (eeprom_ptr + 1) % EEPROM_MAX;
         i2cCounter++;
         
       }else //Master writing
       {
         //printf("Enter rx mode\n");
         I2C0_BASE_PTR->C1 &= ~I2C_C1_TX_MASK; //Enter RX mode
         while(!((I2C0_BASE_PTR->FLT & I2C_FLT_STOPF_MASK) >> I2C_FLT_STOPF_SHIFT))
         {
            i2c_dump = I2C0_BASE_PTR->D;
         }
         eeprom_ptr = (eeprom_ptr + 1) % EEPROM_MAX;
         i2cCounter++;
         //printf("I2C data = %x\n", i2c0Data);
       }
     }


   
   
}
void i2c1_isr(void)
{
     //printf("entered i2c1 interrupt\n");
     //printf("addressed = %d\n\n",(I2C1_BASE_PTR->S & I2C_S_IAAS_MASK) >> I2C_S_IAAS_SHIFT);
     //Is stop flag set?
     if((I2C1_BASE_PTR->FLT & I2C_FLT_STOPF_MASK) >> I2C_FLT_STOPF_SHIFT)
     {
       //Clear stop and interrupt flag, reset start log, exit interrupt
       I2C1_BASE_PTR->FLT |= I2C_FLT_STOPF_MASK;
       I2C1_BASE_PTR->S |= I2C_S_IICIF_MASK;
       
       i2c1StartCount = 0;
       return;
     }
     //Is start flag set?
     if((I2C1_BASE_PTR->FLT & I2C_FLT_STARTF_MASK) >> I2C_FLT_STARTF_SHIFT)
     {
        //Clear start and interrupt flag, log start count
        I2C1_BASE_PTR->FLT |= I2C_FLT_STARTF_MASK;
        I2C1_BASE_PTR->S |= I2C_S_IICIF_MASK;
        //printf("Start bit detected\n");
        i2c1StartCount++;
        
        //Is this a repeated start? Exit
        if(i2c1StartCount > 1)
        {
          //printf("Repeated start\n");
          return; 
        }
        
     }else
     {
        //Clear interrupt flag
        I2C1_BASE_PTR->S |= I2C_S_IICIF_MASK;
     }

     //Has slave been addressed?
     if((I2C1_BASE_PTR->S & I2C_S_IAAS_MASK) >> I2C_S_IAAS_SHIFT) //Slave addressed
     {
       //printf("Slave addressed\n");
       //Is slave transmitting data?
       if((I2C1_BASE_PTR->S & I2C_S_SRW_MASK) >> I2C_S_SRW_SHIFT) //Master reading
       {
         //printf("Enter tx mode\n");
         I2C1_BASE_PTR->C1 |= I2C_C1_TX_MASK; //Enter TX mode     
         while(!((I2C1_BASE_PTR->S & I2C_S_RXAK_MASK) >> I2C_S_RXAK_SHIFT))
         {
            if(i2c1Data) //If a uart message is available, send it, otherwise, send a zero
            {
              I2C1_BASE_PTR->D = I2C_buffer[I2C_count];
            }
            else
            {
              I2C1_BASE_PTR->D = 0;
            }
            //I2C1_BASE_PTR->S |= I2C_S_TCF_MASK;
         }
         if(i2c1Data)
         {
           I2C_count++;
         }
         while((!((I2C1_BASE_PTR->FLT & I2C_FLT_STOPF_MASK) >> I2C_FLT_STOPF_SHIFT)))
         {
            I2C1_BASE_PTR->D = 0xFF;
         }
         
         if(I2C_count >= UART_SIZE) //UART message sent, turn off i2c data flag and reset I2C count
         {
          i2c1Data = 0;
          I2C_count = 0;
         }

         
       }else //Master writing
       {
         //printf("Enter rx mode\n");
         I2C1_BASE_PTR->C1 &= ~I2C_C1_TX_MASK; //Enter RX mode
         if(UART_count < UART_SIZE)
         {
            while(!((I2C1_BASE_PTR->FLT & I2C_FLT_STOPF_MASK) >> I2C_FLT_STOPF_SHIFT))
            {
              UART_buffer[UART_count] = I2C1_BASE_PTR->D;
            }
            if((unsigned char) UART_buffer[UART_count] < 2) //Command received
            {
              heartbeatON = UART_buffer[UART_count];
            }else //Data received
            {
              UART_count++;
            }
         }
       }
     }
}

void initializeGpio()
{
    //Enable clock to portc
    SIM_BASE_PTR->SCGC5 |= SIM_SCGC5_PORTC_MASK;  
  
    /*
    * Set PTC5 (Pin 77) to alt 1 
    */
    PORTC_BASE_PTR->PCR[5] |= PORT_PCR_MUX_MASK & (1 << PORT_PCR_MUX_SHIFT);
    
    //Enable ptc5 as output
    PTC_BASE_PTR->PDDR |= GPIO_PDDR_PDD_MASK & (0x20 << GPIO_PDDR_PDD_SHIFT);
    PTC_BASE_PTR->PCOR = 0x20; //Clear PTC5
}
void writeGpio(char state)
{
  if(state)
  {
    PTC_BASE_PTR->PSOR = 0x20; //Set PTC5
  }
  else
  {
    PTC_BASE_PTR->PCOR = 0x20; //Clear PTC5
  }
}