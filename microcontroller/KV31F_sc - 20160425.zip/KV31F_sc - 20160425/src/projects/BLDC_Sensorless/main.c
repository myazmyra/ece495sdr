/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2004-2011 Freescale Semiconductor, Inc.
* ALL RIGHTS RESERVED.
*
******************************************************************************
*
* @file      main.c   
*
* @author    Petr Staszko
* 
* @version   1.0.0.0
*
* @date      15.8-2013
* 
* @brief     Sensorless BLDC motor control application
*
* @remark    
*
*******************************************************************************
*
* The main file of Sensorless BLDC motor control application for Kinetis KV10
*
******************************************************************************/

#include "main.h"
#include "BLDC_appconfig.h"
#include "peripherals_init.h"
#include "freemaster.h"
#include "state_machine.h"
#include "M1_StateMachine.h" /* Motor 1's state machine */

#include "motor_structure.h"

/******************************************************************************
* Global variables
******************************************************************************/
extern MCSTRUC_BLDC_SNLS_INT_T gsM1_Drive;
volatile UInt16                uw16TriggerErrorCnt;

static bool                    bDemoMode; // demo mode enabled/dissabled by SW2 button 
static UWord32                 uw32SpeedStimulatorCnt;  // used for demo mode
static UWord32                 uw32ButtonFilter;  // Used for demo mode


volatile UInt16 uw16Test;

/******************************************************************************
* Global functions
******************************************************************************/
void UpdateBldcHwModules(MCSTRUC_BLDC_SNLS_INT_T *);
extern void ReadSwFaults(MCSTRUC_BLDC_SNLS_INT_T *);
extern void TimeEvent(MCSTRUC_BLDC_SNLS_INT_T *);
extern void FastControlLoop(MCSTRUC_BLDC_SNLS_INT_T *);
extern void SlowControlLoop(MCSTRUC_BLDC_SNLS_INT_T *);
extern void Demonstration(MCSTRUC_BLDC_SNLS_INT_T *);
extern void SM_StateMachine(SM_APP_CTRL_T *sAppCtrl);
extern void M1_SetSpeed(MCSTRUC_BLDC_SNLS_INT_T * sM_Drive, int intValue);
/******************************************************************************
* Local functions
******************************************************************************/

void main(void)
{
  DisableInterrupts;
  MCU_init();

  FMSTR_Init();
  SM_StateMachine(&gsM1_Ctrl);          // Application variables init
  
  /* Enable Interrupts globally */
  EnableInterrupts;
  
  /* Disable demo mode */
  bDemoMode = FALSE;
  uw32SpeedStimulatorCnt = 0;
  uw32ButtonFilter = 0;
  
  M1_SetAppSwitch(0);

  PTD_BASE_PTR->PCOR = 1 << 1;   // Turn on red LED
  
    /* infinite loop */
    while(1)
    {
       FMSTR_Poll();
    }
}

/***************************************************************************//*!
 * @brief   ADC Callback function
 *
 * Description:
 * Three analogue signals are measured by the ADC module
 *
 *   1) DC Bus current  - triggered by H/W - ADC0
 *   2) Phase voltage   - triggered by H/W (Back to back PDB mode) ADC0/1
 *   3) DC Bus voltage  - triggered by H/W - ADC1
 * 
 * After second ADC0 sample is converted (2), ADC interrupt service routine
 * is executed. It is waited until the ADC1 conversion are completed as well. Then we retrieve the measured DCBV&DCBI
 * 
 * 
 ******************************************************************************/
void ADC0_Isr(void)
{
  // Read timer counter and value registers
  gsM1_Drive.uw16TimeCurrent      = FTM1_BASE_PTR->CNT;
  gsM1_Drive.uw16TimeCurrentEvent = FTM1_BASE_PTR->CONTROLS[0].CnV;
  
  // Wait till the ADC1 conversion is done as well
  while (!(ADC1_BASE_PTR->SC1[1] & ADC_SC1_COCO_MASK)) {}
  
  // Read ADC results
  // (ADC triggered by H/W trigger from PDB)
  gsM1_Drive.f16DcBusCurrentRaw = ADC1_BASE_PTR->R[1] << 3;       
  gsM1_Drive.f16DcbVoltage = ADC0_BASE_PTR->R[1] << 3;            
    
  /* Determine which ADC has desired phase voltage value */
  if(bldcAdcSelCfg[gsM1_Drive.w16CmtSector])
  {
      /* ADC1 */
      gsM1_Drive.f16PhaseVoltage = ADC1_BASE_PTR->R[0] << 3; 
  }
  else
  {
      /* ADC0 */
      gsM1_Drive.f16PhaseVoltage = ADC0_BASE_PTR->R[0] << 3;
  }
  
  // Filtered DC Bus current value 
  gsM1_Drive.f16DcBusCurrentNoFiltered = MLIB_ShLSat_F16(gsM1_Drive.f16DcBusCurrentRaw - gsM1_Drive.f16DcBusCurrentOffset, 1);
  gsM1_Drive.f16DcBusCurrent = GDFLIB_FilterMA_F16(gsM1_Drive.f16DcBusCurrentNoFiltered, &gsM1_Drive.trCurrentMaFilter);
  gsM1_Drive.f16PhaseBemf = gsM1_Drive.f16PhaseVoltage - (gsM1_Drive.f16DcbVoltage >> 1);

  FMSTR_Recorder();     // Back-EMF voltage (must be located before FastControlLoop, because it is modified in FastControlLoop)
  
  DemoSpeedStimulator();
  
  FastControlLoop(&gsM1_Drive);
  
  /* Configure ADCs for next measurement */
  ADC0_BASE_PTR->SC1[0] = bldcAdc0SectorCfg[gsM1_Drive.w16CmtSector];  
  ADC0_BASE_PTR->SC1[1] = ADC_CHANNEL_DCBV | ADC_SC1_AIEN_MASK;
  ADC1_BASE_PTR->SC1[0] = bldcAdc1SectorCfg[gsM1_Drive.w16CmtSector]; 
  ADC1_BASE_PTR->SC1[1] = ADC_CHANNEL_DCBI;
  
  ReadSwFaults(&gsM1_Drive);

  SM_StateMachine(&gsM1_Ctrl);

  UpdateBldcHwModules(&gsM1_Drive);
}

/***************************************************************************//*!
 * @brief   FTM1 interrupt service routine
 * - Forced commutation control
 ******************************************************************************/
void FTM1_Isr(void)
{
  // Read timer counter and value registers
  gsM1_Drive.uw16TimeCurrent      = FTM1_BASE_PTR->CNT;
  gsM1_Drive.uw16TimeCurrentEvent = FTM1_BASE_PTR->CONTROLS[0].CnV;
  
  TimeEvent(&gsM1_Drive);
  
  SM_StateMachine(&gsM1_Ctrl);
  
  UpdateBldcHwModules(&gsM1_Drive);
  
  FTM1_BASE_PTR->CONTROLS[0].CnSC &= ~FTM_CnSC_CHF_MASK;
}

/***************************************************************************//*!
 * @brief   FTM2 interrupt service routine
 * - slow control loop
 * - Low priority ISR
 ******************************************************************************/
void FTM2_Isr(void)
{
  SlowControlLoop(&gsM1_Drive);
   
  
  FTM2_BASE_PTR->CONTROLS[0].CnV += SLOW_TIMER_PERIOD;
  FTM2_BASE_PTR->CONTROLS[0].CnSC &= ~FTM_CnSC_CHF_MASK;
}

/***************************************************************************//*!
 * @brief   PDB0 interrupt service routine
 * Trigger error clear routine
 ******************************************************************************/
void PDB0_Isr(void)
{
  if ((PDB0_BASE_PTR->CH[0].S & PDB_S_ERR_MASK)||(PDB0_BASE_PTR->CH[1].S & PDB_S_ERR_MASK))
  {
    if (uw16TriggerErrorCnt < 0xffff) uw16TriggerErrorCnt++;
    PDB0_BASE_PTR->SC &= ~PDB_SC_PDBEN_MASK;      // disable PDB
    PDB0_BASE_PTR->CH[0].S &= ~PDB_S_ERR_MASK;
    PDB0_BASE_PTR->CH[1].S &= ~PDB_S_ERR_MASK;
    PDB0_BASE_PTR->SC |= PDB_SC_PDBEN_MASK;       // Enable PDB
  }
}

/***************************************************************************//*!
 * @brief   Update of W/H modules used by BLDC algorithm based on request flags
 ******************************************************************************/
void UpdateBldcHwModules(MCSTRUC_BLDC_SNLS_INT_T * sM_Drive)
{
  // Disable PWM outputs
  // If uw16TriggerErrorCnt > 1 then there is probably issue with ADC ISR (it is probably not executed), therefore PWM outputs are disabled to protect output MOSFETs; 1 error is allowed.
  // "uw16TriggerErrorCnt > 1" condition should be deleted in the final application.
  if ((sM_Drive->uw16HwUpdateRequests & UPDATE_PWM_DISABLE_REQ) | (uw16TriggerErrorCnt > 1))
  {
    sM_Drive->uw16HwUpdateRequests &= ~(UPDATE_PWM_DISABLE_REQ | UPDATE_BRAKE_RESISTOR_ON_REQ | UPDATE_DUTYCYCLE_REQ | UPDATE_PWM_CONFIG_REQ | UPDATE_PWM_ALIGNMENT_REQ);
    FTM0_SetPwmOutput(7);                     // Disable PWM outputs
    //BRAKE_RESISTOR_OFF;
  }

  // Request to set new time event (update timer value register)
  if (sM_Drive->uw16HwUpdateRequests & UPDATE_TIME_EVENT_REQ)
  {
    sM_Drive->uw16HwUpdateRequests &= ~UPDATE_TIME_EVENT_REQ;
    FTM1_BASE_PTR->CONTROLS[0].CnV = sM_Drive->uw16TimeNextEvent;
  }
  
  // Update PWM duty cycle if requested
  if (sM_Drive->uw16HwUpdateRequests & UPDATE_DUTYCYCLE_REQ)
  {
    sM_Drive->uw16HwUpdateRequests &= ~UPDATE_DUTYCYCLE_REQ;
    FTM0_SetDutyCycle(sM_Drive->f16DutyCycle);
  }

  // Apply commutation vector (alternatively enable PWM outputs)
  if (sM_Drive->uw16HwUpdateRequests & UPDATE_PWM_CONFIG_REQ)
  {
    sM_Drive->uw16HwUpdateRequests &= ~UPDATE_PWM_CONFIG_REQ;
    FTM0_SetPwmOutput(sM_Drive->w16CmtSector);             // apply commutation vector    
  }
   
  // Apply alignment vector
  if (sM_Drive->uw16HwUpdateRequests & UPDATE_PWM_ALIGNMENT_REQ)
  {
    sM_Drive->uw16HwUpdateRequests &= ~UPDATE_PWM_ALIGNMENT_REQ;
    FTM0_SetPwmOutput(6);                    // Apply alignment vector
  }
  
}

/*************************************************************************
 * Function Name: PORTC_IRQHandler
 * Parameters: none
 *
 * Return: none
 *
 * Description: port A interrupt handler 
 *
 *************************************************************************/
void Ports_ISR_Handler(void)
{ 
  if (PORTA_BASE_PTR->PCR[4] | PORT_PCR_ISF_MASK)
  { 
    PORTA_BASE_PTR->PCR[4] |= PORT_PCR_ISF_MASK; // clear the flag
    if(uw32ButtonFilter > 2000) // Proceede only if more then 200ms passed
    {
      uw32ButtonFilter = 0;
      if(bDemoMode)
      {      
        PTD_BASE_PTR->PSOR = 1 << 7;  // Turn off green LED
        PTD_BASE_PTR->PCOR = 1 << 1;   // Turn on red LED
        M1_SetSpeed(&gsM1_Drive, 0);
        M1_SetAppSwitch(0);
        bDemoMode = FALSE;
      }
      else
      {
        PTD_BASE_PTR->PCOR = 1 << 7;   // Turn on green LED
        PTD_BASE_PTR->PSOR = 1 << 1;   // Turn off red LED
        M1_SetAppSwitch(1);
        bDemoMode = TRUE;  
        uw32SpeedStimulatorCnt = 0;
      }  
    }
  }
}  

 


/*************************************************************************
 * Function Name: DemoSpeedStimulator
 * Parameters: none
 *
 * Return: none
 *
 * Description: When demo mode is enabled it changes the required speed according 
 *              to predefined profile
 *
 *************************************************************************/
void DemoSpeedStimulator(void)
{    
    // Increase if less then 1s
    if(uw32ButtonFilter < 10000) uw32ButtonFilter++;            
    if ( bDemoMode )
    {
      uw32SpeedStimulatorCnt++;
      switch (uw32SpeedStimulatorCnt)
      {
      case 1:
        M1_SetSpeed(&gsM1_Drive, FRAC16(1000/N_MAX));
      break;        
      case 50000:
        M1_SetSpeed(&gsM1_Drive, FRAC16(2000/N_MAX));
      break;
      case 100000:
        M1_SetSpeed(&gsM1_Drive, FRAC16(3000/N_MAX));
      break;
      case 150000:
        M1_SetSpeed(&gsM1_Drive, FRAC16(1000/N_MAX));
      break; 
      case 200000:
        M1_SetSpeed(&gsM1_Drive, -FRAC16(2000.0/N_MAX));
      break;
      case 400000:
        uw32SpeedStimulatorCnt = 0;
      break;
      }
    }
}
