/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */

/*
 * File:		blinky_green.c
 * Purpose:		Toggle Green LED D7 for MSD feature demonstration
 *
 *		Configures GPIO for the Green LED on TWR-KV31F120M
 *		Green LED (D7)      - PTD7
 */

#define GPIO_PIN_MASK			0x1Fu
#define GPIO_PIN(x)			(((1)<<(x & GPIO_PIN_MASK)))

#include "common.h"
#include "uart.h"
#include "smc.h"
#include "lptmr.h"

/*Function declarations */
void init_gpio();

void main (void)
{
        
        printf("\nRunning the 'Blinky Green' project for the %s %d MHz family\n",
		   TWR_STRING, TWR_HS_SYSCLOCK);
        init_gpio();
        
	while(1)
	{
          /*Toggle Green LED (PTE1) each 200 ms*/
          GPIOD_PTOR |= GPIO_PTOR_PTTO(GPIO_PIN(7));
          time_delay_ms(200);
	}
}

/*
 * Initialize GPIO for Tower LED's
 *   PTE1 - Yellow LED (D3)
 *   PTE0 - Blue/RED LED (D4)
 *   PTB19 - Orange LED (D6)
 *   PTD7 - Green LED (D7)
*/
void init_gpio()
{
	
	/*
	 * Set PTE1, PTE0, PTB19, and PTD7 (connected to LED's)
	 * for GPIO functionality
	 */
	PORTE_PCR1 = (0 | PORT_PCR_MUX(1));
	PORTE_PCR0 = (0 | PORT_PCR_MUX(1));
        PORTB_PCR19= (0 | PORT_PCR_MUX(1));
	PORTD_PCR7 = (0 | PORT_PCR_MUX(1));

	/* Change PTE1, PTE0, PTB19, and PTD7 to outputs */
	GPIOE_PDDR = GPIO_PDDR_PDD(GPIO_PIN(0) | GPIO_PIN(1));
        GPIOB_PDDR = GPIO_PDDR_PDD(GPIO_PIN(19));
        GPIOD_PDDR = GPIO_PDDR_PDD(GPIO_PIN(7));
        
        /*Turn Off All LEDs*/
        GPIOE_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(1));
        GPIOE_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(0));
        GPIOB_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(19));
        GPIOD_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(7));               
}