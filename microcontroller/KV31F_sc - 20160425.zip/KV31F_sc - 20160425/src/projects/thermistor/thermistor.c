/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */

#include "common.h"
#include "uart.h"
#include "smc.h"
#include "adc16.h"
#include "lptmr.h"

/*Function declarations */
void portc_isr(void);
void porta_isr(void);
void porte_isr(void);
void init_gpio(void);
void adc1_differential_channel1(void);
void adc1_differential_channel_init(void);
extern signed char result[20];

#define GPIO_PIN_MASK			0x1Fu
#define GPIO_PIN(x)				(((1)<<(x & GPIO_PIN_MASK)))

int  adc_thresholdh,adc_thresholdc;

/******************************************************************************
* Global variables
******************************************************************************/
tADC_Config Master_Adc_Config;  
tADC_Cal_Blk CalibrationStore[2];

void main (void)
{
        int i,adc_result;

        printf("\nRunning the 'thermistor' project running at %s %d MHz \n",
		   BRD_STRING, BRD_SYSCLOCK);
        adc_thresholdh = 0;
        adc_thresholdc = 0x3fff;
        printf("\r\nBLUE flashing if the temperature is getting Colder");        
        printf("\r\nRED  flashing if the temperature is getting Hotter");        
        printf("\r\nPress push buttons to clear Cold and Hot threshold\n\n");
	/* Enable GPIOC interrupts in NVIC */
        enable_irq(61);		/* GPIOC Vector is 77. IRQ# is 77-16=61 */
	enable_irq(63);		/* GPIOC Vector is 79. IRQ# is 79-16=63 */
        enable_irq(59);       // Interrupt priority for PORTA

	/* Initialize GPIO on board for -K22F120M */
	init_gpio();
        adc1_differential_channel_init();

	while(1)
	{
            adc1_differential_channel1();
            for (i=0;i<0xffff;i++){
               if ((ADC1_SC1A & ADC_SC1_COCO_MASK)>>ADC_SC1_COCO_SHIFT == 1){
                 
                  adc_result = (~(ADC1_RA - 1))&0x7fff;                        
                  printf(" Thermistor Reading 0x%02X \r", adc_result);
                  break;
               }
            }  
            if (adc_result > adc_thresholdh){  
                       adc_thresholdh = adc_result;
                       LED0_ON; //on RED
                       LED2_OFF; //off BLUE
                       time_delay_ms(100);
                       LED0_OFF; //off RED
                  }
            if (adc_result < adc_thresholdc){  
                       adc_thresholdc = adc_result;  
                       LED0_OFF; //off RED
                       LED2_ON; //on BLUE
                       time_delay_ms(100);
                       LED2_OFF; //off BLUE
                  }
            time_delay_ms(100);
                 
	}
}

 /* ISR for PORTC interrupts */
void portc_isr(void)
{
	if (PORTC_ISFR & GPIO_PIN(6)) {
		PORTC_ISFR = (1<<6);	/* Clear Port C ISR flags */
		printf("\n  SW1 ");
	}
	if (PORTC_ISFR & GPIO_PIN(11)) {
		PORTC_ISFR = (1<<11);	/* Clear Port C ISR flags */
		printf("\n  SW2 ");
	}
	printf("Pressed\n");
}

/* ISR for PORTA interrupts */
void porta_isr(void)
{
  if (PORTA_BASE_PTR->PCR[4] | PORT_PCR_ISF_MASK)
  { 
    PORTA_BASE_PTR->PCR[4] |= PORT_PCR_ISF_MASK; // clear the flag
    #if (defined(TOWER))
    printf("\n  SW3 ");
    #elif (defined(FREEDOM))
    printf("\n  SW2 ");
    #endif
    }
    printf("Pressed\n");
    adc_thresholdh = 0;
    adc_thresholdc = 0x3fff;
}

/* ISR for PORTE interrupts */
void porte_isr(void)
{
    if (PORTE_ISFR & GPIO_PIN(25)) {
    	PORTE_ISFR = (1<<25);	/* Clear Port E ISR flags */
    	printf("\n  SW4 ");
    }
    if (PORTE_ISFR & GPIO_PIN(4)) {
    	PORTE_ISFR = (1<<4);	/* Clear Port E ISR flags */
    	printf("\n  SW3 ");       /* SW3 on FRDM-KC31F */
    }
    printf("Pressed\n");
    adc_thresholdh = 0;
    adc_thresholdc = 0x3fff;
}
/*
 * Initialize GPIO for Board switches and LED's
 *    Device            TOWER       FRDM
 *    SW1 -             PTC6        RESET
 *    SW2 -             PTC11       PTA4
 *    SW3 -             PTA4        PTE4
 *    SW4 -             PTE25       n/a
 *  
 *  Yellow LED (D3)     PTE1        N/A
 *  Blue LED (D4)       PTE0        PTE25
 *  Orange/RED LED (D6) PTB19       PTD1
 *  Green LED (D7)      PTD7        PTD7
*/
void init_gpio()
{
	/*
	 * Set PTD1, PTC6, PTC7, PTA4 PTE4 and PTE25 for GPIO functionality,
	 * falling IRQ, and to use internal pull-ups. (pin defaults to input state)
	 */
	PORTC_PCR6 =
	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
	    PORT_PCR_PS_MASK;
	PORTC_PCR11 =
	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
	    PORT_PCR_PS_MASK;
        PORTA_PCR4 =
	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
	    PORT_PCR_PS_MASK;
       #if (defined(TOWER))
       PORTE_PCR25 =
       	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
       	    PORT_PCR_PS_MASK;
       #elif (defined(FREEDOM))
       PORTE_PCR4 =
       	    PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA) | PORT_PCR_PE_MASK |
       	    PORT_PCR_PS_MASK;
       #endif

	/*
	 * Set PTE1, PTE0, PTB19, and PTD7 (connected to LED's)
	 * for GPIO functionality
	 */
       LED0_EN;
       LED1_EN;
       LED2_EN;
       /* Change to outputs */
       LED0_DIR;
       LED1_DIR;
       LED2_DIR;
       
       LED0_OFF;
       LED1_OFF;
       LED2_OFF;
       
#if (defined(TOWER))
       LED3_EN;
       /* Change to outputs */
       LED3_DIR;
       LED3_OFF;
#endif

}
/*************************************************************************
 * Function Name: ADC_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the adc complete interrupt
 *
 *************************************************************************/
void ADC_ISR_Handler(void)
{
    /* StateMachine call */

  
  
}