/******************************************************************************
* 
* Copyright (c) 2008 Freescale Semiconductor;
* All Rights Reserved                       
*
*******************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* @file      ACLIB_TrackObsrv.h
*
* @author    r59400, plcm001
* 
* @version   1.0.2.0
* 
* @date      Oct-25-2013
* 
* @brief     Header for controller tracking observer
*
*******************************************************************************
*
* Detailed Description of the file.
*
******************************************************************************/
#ifndef _ACLIB_TRACK_OBSRV_H
#define _ACLIB_TRACK_OBSRV_H

/******************************************************************************
* Includes
******************************************************************************/
#include "SWLIBS_Defines.h"
#include "mlib.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros 
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/
typedef struct
{
	Frac32	f32I_1;
	Frac16	f16Theta;
	Frac16	f16Speed;
	Frac16	f16IntegScale;
	Word16	i16IntegShift;
	Frac16	f16PropScale;
	Word16	i16PropShift;
	Frac16	f16ThScaled;
	Word16	i16ThShift;
	
}ACLIB_TRACK_OBSRV_T_F16;

/******************************************************************************
* Global variables
******************************************************************************/
   
/******************************************************************************
* Global functions
******************************************************************************/
extern Frac16 ACLIB_TrackObsrv_F16
(
    Frac16 f16ThetaErr, 
    ACLIB_TRACK_OBSRV_T_F16 * const pudtCtrl
);
/******************************************************************************
* Inline functions
******************************************************************************/

#endif /* _ACLIB_ANGLE_TRACK_OBSRV_H */
