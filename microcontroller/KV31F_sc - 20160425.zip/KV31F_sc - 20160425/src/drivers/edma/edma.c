/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */

#include "common.h"
#include "edma.h"

/*
 * \brief	Initialize a DMA channel to transfer data from a peripheral 
 *              FIFO or rx data register to a buffer in memory. This function
 *              does the configuration of the DMA channel's TCD and also 
 *              initializes the DMAMUX. 
 *
 *              To actually allow the tranfser to start, external requests 
 *              for the DMA channel still need to be enabled by writing the 
 *              DMA channel number to the DMA_SERQ register. Writing DMA_SERQ
 *              is done outside this function becuase it is important that both
 *              the DMA channel and the requesting peripheral are properly 
 *              configured before the external request is enabled.
 *
 *              This function will configure the DMA channel to assert an 
 *              interrupt when the entire DMA completes. To actually use the
 *              interrupt the NVIC must be configured to enabled the IRQ.
 *
 * \author
 * \param
 *		dma_source	DMAMUX source number for the peripheral DMA request
 *              ch              DMA channel to use to transfer data
 *              source_addr     DMA source address (address of peripheral FIFO/data register)
 *              dest_addr       DMA destination address (location of the buffer to be written)
 *              num_bytes       total number of bytes to transfer (size of the buffer)
 *              bytes_per_tranfer       number of bytes to transfer per assertion of the 
 *                                      DMA request. Usually corresponds to the size of
 *                                      the peripheral FIFO (DMA minor loop count). Valid
 *                                      options are 1, 2, 4, 16, and 32. 
 * \return
 *		none
 * \todo
 * \warning	The num_bytes parameter must be evenly divisible by the
 *              bytes_per_transfer.
 */
void DMA_RX_Init(uint8_t dma_source, int ch, uint32_t source_addr, uint32_t dest_addr, uint32_t num_bytes, uint32_t bytes_per_xfer)
{
  
  /* num_bytes is total bytes */
  /* setup depends on how many bytes per transfer */
  uint32_t      citer_biter = num_bytes / bytes_per_xfer; 
  uint32_t      ssize_dsize_attr;
   
  /* setup ssize and dsize parameter for TCD ATTR register based on transfer size assigned above */
  /* 0:8bit; 1:16-bit, 2:32-bit, 5:16-byte, 6:32-byte */
  switch(bytes_per_xfer)
  {
    case 1: default:
      ssize_dsize_attr = 0;  break;       /* 8-bit */
    case 2:
      ssize_dsize_attr = 1;  break;       /* 16-bit */
    case 4:
      ssize_dsize_attr = 2;  break;       /* 32-bit */
    case 16:
      ssize_dsize_attr = 5;  break;       /* 16-byte */
    case 32:
      ssize_dsize_attr = 6;  break;       /* 32-byte */
  }    

  /* Configure the DMA channel's transfer control descriptor (TCD) */
  DMA_SADDR_REG(DMA_BASE_PTR, ch)          = source_addr;                                        // Source address 
  DMA_SOFF_REG(DMA_BASE_PTR, ch)           = 0x0000;                                             // Source address increments 0 bytes (uint32)
  DMA_SLAST_REG(DMA_BASE_PTR, ch)          = 0;                                                  // After the major loop ends the source address decrements the size of the buffer
  DMA_DADDR_REG(DMA_BASE_PTR, ch)          = dest_addr;                                          // Destination address 
  DMA_DOFF_REG(DMA_BASE_PTR, ch)           = bytes_per_xfer;                                     // Destination offset increments 
  DMA_DLAST_SGA_REG(DMA_BASE_PTR, ch)      = -num_bytes;                                         // Destination address shift, go to back to beginning of buffer
  DMA_NBYTES_MLNO_REG(DMA_BASE_PTR, ch)    = bytes_per_xfer;                                     // The minor loop moves by bytes per transfer
  DMA_BITER_ELINKNO_REG(DMA_BASE_PTR, ch)  = citer_biter;                                        // Major loop iterations
  DMA_CITER_ELINKNO_REG(DMA_BASE_PTR, ch)  = citer_biter;                                        // Set current interation count  
  DMA_ATTR_REG(DMA_BASE_PTR, ch)           = (DMA_ATTR_SSIZE(ssize_dsize_attr)|DMA_ATTR_DSIZE(ssize_dsize_attr));   // Source a destination size 0:8bit; 1:16-bit, 2:32-bit, 5:16-byte, 6:32-byte
  DMA_CSR_REG(DMA_BASE_PTR, ch)            = DMA_CSR_INTMAJOR_MASK | DMA_CSR_DREQ_MASK;          // Enable end of loop DMA interrupt, disable request at end of major iteration              
  
  /* Configure the DMAMUX to link the desired DMA channel to the peripheral request */
  DMAMUX_CHCFG_REG(DMAMUX_BASE_PTR,ch)    = (DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(dma_source));     // DMA source DMA Mux to tie source to DMA channel
}

  
/*
 * \brief	Initialize a DMA channel to transfer data from a buffer in
 *              memory to a peripheral FIFO or rx data register. This function
 *              does the configuration of the DMA channel's TCD and also 
 *              initializes the DMAMUX. 
 *
 *              To actually allow the tranfser to start, external requests 
 *              for the DMA channel still need to be enabled by writing the 
 *              DMA channel number to the DMA_SERQ register. Writing DMA_SERQ
 *              is done outside this function becuase it is important that both
 *              the DMA channel and the requesting peripheral are properly 
 *              configured before the external request is enabled.
 *
 *              This function will configure the DMA channel to assert an 
 *              interrupt when the entire DMA completes. To actually use the
 *              interrupt the NVIC must be configured to enabled the IRQ.
 *
 * \author
 * \param
 *		dma_source	DMAMUX source number for the peripheral DMA request
 *              ch              DMA channel to use to transfer data
 *              source_addr     DMA source address (location of the buffer to be written)
 *              dest_addr       DMA destination address (address of peripheral FIFO/data register)
 *              num_bytes       total number of bytes to transfer (size of the buffer)
 *              bytes_per_tranfer       number of bytes to transfer per assertion of the 
 *                                      DMA request. Usually corresponds to the size of
 *                                      the peripheral FIFO (DMA minor loop count). Valid
 *                                      options are 1, 2, 4, 16, and 32. 
 * \return
 *		none
 * \todo
 * \warning	The num_bytes parameter must be evenly divisible by the
 *              bytes_per_transfer.
 */
void DMA_TX_Init(uint8_t dma_source, int ch, uint32_t source_addr, uint32_t dest_addr, uint32_t num_bytes, uint32_t bytes_per_xfer) 
{

  /* num_bytes is total bytes */
  /* setup depends on how many bytes per transfer */
  uint32_t      citer_biter = num_bytes / bytes_per_xfer;
  uint32_t      ssize_dsize_attr;
  
  /* setup ssize and dsize parameter for TCD ATTR register based on transfer size assigned above */
  /* 0:8bit; 1:16-bit, 2:32-bit, 5:16-byte, 6:32-byte */  
  switch(bytes_per_xfer)
  {
    case 1: default:
      ssize_dsize_attr = 0;  break;       /* 8-bit */
    case 2:
      ssize_dsize_attr = 1;  break;       /* 16-bit */
    case 4:
      ssize_dsize_attr = 2;  break;       /* 32-bit */
    case 16:
      ssize_dsize_attr = 5;  break;       /* 16-byte */
    case 32:
      ssize_dsize_attr = 6;  break;       /* 32-byte */
  }
      
  /* Configure the DMA channel's transfer control descriptor (TCD) */
  DMA_SADDR_REG(DMA_BASE_PTR, ch)          = source_addr;                                        // Source address 
  DMA_SOFF_REG(DMA_BASE_PTR, ch)           = bytes_per_xfer;                                     // Source address increments by number of bytes per transfer
  DMA_SLAST_REG(DMA_BASE_PTR, ch)          = -num_bytes;                                         // After the major loop ends, reset pointer to beginning of buffer
  DMA_DADDR_REG(DMA_BASE_PTR, ch)          = dest_addr ;                                         // Destination address 
  DMA_DOFF_REG(DMA_BASE_PTR, ch)           = 0x0;                                                // Destination offset increments 0 bytes (uint32)
  DMA_DLAST_SGA_REG(DMA_BASE_PTR, ch)      = 0;                                                  // Destination address shift
  DMA_NBYTES_MLNO_REG(DMA_BASE_PTR, ch)    = bytes_per_xfer;                                     // The minor loop moves 32 bytes per transfer
  DMA_BITER_ELINKNO_REG(DMA_BASE_PTR, ch)  = citer_biter;                                        // Major loop iterations
  DMA_CITER_ELINKNO_REG(DMA_BASE_PTR, ch)  = citer_biter;                                        // Set current interation count  
  DMA_ATTR_REG(DMA_BASE_PTR, ch)           = (DMA_ATTR_SSIZE(ssize_dsize_attr) | DMA_ATTR_DSIZE(ssize_dsize_attr));   // Source a destination size 0:8bit; 1:16-bit, 2:32-bit, 5:16-byte, 6:32-byte
  DMA_CSR_REG(DMA_BASE_PTR, ch)            = DMA_CSR_INTMAJOR_MASK | DMA_CSR_DREQ_MASK;          // Enable end of loop DMA interrupt; clear ERQ @ end of major iteration               
 
  /* Configure the DMAMUX to link the desired DMA channel to the peripheral request */  
  DMAMUX_CHCFG_REG(DMAMUX_BASE_PTR,ch)    = (DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(dma_source));     // DMA source DMA Mux
}
