/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */

 /*
 * File:	smc.c
 * Purpose:	Provides routines for entering low power modes.
 *
 * Notes:	Since the wakeup mechanism for low power modes
 *			will be application specific, these routines
 *			do not include code to setup interrupts to exit
 *			from the low power modes. The desired means of
 *			low power mode exit should be configured before
 *			calling any of these functions.
 *
 *			These routines do not include protection to
 *			prevent illegal state transitions in the mode
 *			controller, and all routines that write to the
 *			PMPROT register write a value to allow all
 *			possible low power modes (it is write once, so
 *			if only the currently requested mode is enabled
 *			a different mode couldn't be enabled later on).
 */

#include "common.h"
#include "smc.h"

/********************************************************************/
/* HSRUN mode entry routine. Puts the processor into high speed run mode.
 * In HSRUN mode:
 * 
 *  - the maximum allowable change in frequency of the system, bus, flash or
 *    core clocks is restricted to x2.
 *  - Stop mode entry is not permitted.
 *  - Modifications to clock gating control bits are prohibited.
 *  - Flash programming/erasing is not allowed.
 * 
 *
 * Mode transitions:
 * RUN -> HSRUN
 *
 * exit_hsrun() function can be used to switch from HSRUN back to RUN. 
 * 
 *
 * Parameters:
 * none
 *
 * Return value : PMSTAT value or error code
 *                PMSTAT = 
 *                         0000_0001 Current power mode is RUN
 *                         1000_0000 Current power mode is HSRUN
 *                ERROR Code =  0x14 - already in HSRUN mode
 *                              0x15 - not in RUN mode
 */   
int enter_hsrun(void)
{
  int i;
  if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)!= 0x01){
          //current mode is not normal run mode
         return 0x15;
         }
  if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 0x80){
          //already in HSRUN mode
         return 0x14;
         }
  /* The PMPROT register may have already been written by init code
     If so then this next write is not done.  
     PMPROT is write once after RESET  
     this write-once bit allows the MCU to enter High Speed Run Mode (HSRUN)*/
    SMC_PMPROT = SMC_PMPROT_AHSRUN_MASK;  
    
  /* Set the RUNM bits to 0b011 for HSRUN mode */
    SMC_PMCTRL = SMC_PMCTRL_RUNM(3);          
   /* Wait for HSRUN regulator mode to be confirmed */
   for (i = 0 ; i < 10000 ; i++)
    {     /* check that the value of SMC_PMSTAT is not 0x80
             once it is 0x80, we can stop checking */
      if (SMC_PMSTAT !=0x80){
       // 0x01 Current mode is normal run
       // 0x80 Current mode is high speed run
      }  
      else  break;
    }  
   if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK) == 0x80) {
         return 0x80;
   }
   else {
     return SMC_PMSTAT;
   }
}   
   
/********************************************************************/
/* HSRUN mode exit routine. Puts the processor into normal run mode
 * from HSRUN mode. You can transition from HSRUN to normal run using
 * this function or a reset. 
 *
 * Mode transitions:
 * HSRUN -> RUN
 *
 * Parameters:
 * none
 */
void exit_hsrun(void)
{
    /* check to make sure in HSRUN before exiting    */
    if  ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 0x80) {
      
       /* Clear RUNM */
       SMC_PMCTRL &= ~(SMC_PMCTRL_RUNM(0x3));
       
    }  //if in HSRUN mode
     // else if not in HSRUN, ignore call
}      
/*
 * WAIT mode entry routine. Puts the processor into wait mode.
 * In this mode the core clock is disabled (no code executing), but
 * bus clocks are enabled (peripheral modules are operational).
 *
 * Mode transitions:
 * RUN -> WAIT
 * VLPR -> VLPW
 *
 * This function can be used to enter normal wait mode or VLPW
 * mode. If you are executing in normal run mode when calling this
 * function, then you will enter normal wait mode. If you are in VLPR
 * mode when calling this function, then you will enter VLPW mode instead.
 *
 * NOTE: Some modules include a programmable option to disable them in
 * wait mode. If those modules are programmed to disable in wait mode,
 * they will not be able to generate interrupts to wake up the core.
 *
 * WAIT mode is exited using any enabled interrupt or RESET, so no
 * exit_wait routine is needed.
 *
 *
 * Parameters:
 * none
 */
void enter_wait(void)
{
	wait();
}

/* STOP mode entry routine. Puts the processor into normal stop mode.
 * In this mode core, bus and peripheral clocks are disabled.
 *
 * Mode transitions:
 * RUN -> STOP
 * VLPR -> VLPS
 *
 * This function can be used to enter normal stop mode or VLPS
 * mode. If you are executing in normal run mode when calling this
 * function, then you will enter normal stop mode. If you are in VLPR
 * mode when calling this function, then you will enter VLPS mode instead.
 *
 * STOP mode is exited using any enabled interrupt or RESET, so no
 * exit_stop routine is needed.
 *
 * Parameters:
 * none
 */
void enter_stop(void)
{
	/*
	 * Set the STOPM field to 0b000 for normal STOP mode
	 */
	SMC_PMCTRL = SMC_PMCTRL_STOPM(0);	/* set STOPM = 0b000 */
	stop();
}
/********************************************************************/
/* STOP mode entry routine. Puts the processor into normal stop mode.
 * In this mode core, bus and peripheral clocks are disabled.
 *
 * Mode transitions:
 * RUN -> STOP
 *
 * This function can be used to enter normal stop mode. 
 * If you are executing in normal run mode when calling this
 * function and AVLP = 0, then you will enter normal stop mode. 
 * If AVLP = 1 with previous write to PMPROT
 * then you will enter VLPS mode instead.
 *
 * STOP mode is exited using any enabled interrupt or RESET, so no
 * exit_stop routine is needed.
 *
 * Parameters:
 * Partial Stop Option:  
 *  0x00 = STOP - Normal Stop Mode
 *  0x40 = PSTOP1 - Partial Stop with both system and bus clocks disabled
 *  0x80 = PSTOP2 - Partial Stop with system clock disabled and bus clock enabled
 *  0xC0 = Reserved
 */
void enter_stop_opt(unsigned char partial_stop_opt)
{
  volatile unsigned int dummyread;
  /* The PMPROT register may have already been written by init code
     If so then this next write is not done since  
     PMPROT is write once after RESET  
     this write-once bit allows the MCU to enter the
     normal STOP mode.
     If AVLP is already a 1, VLPS mode is entered instead of normal STOP*/
  SMC_PMPROT = 0;  

  /* Set the STOPM field to 0b000 for normal STOP mode */
  SMC_PMCTRL &= ~SMC_PMCTRL_STOPM_MASK;
  SMC_PMCTRL |=  SMC_PMCTRL_STOPM(0); 
  SMC_STOPCTRL &= ~SMC_STOPCTRL_PSTOPO_MASK;
  SMC_STOPCTRL |= partial_stop_opt;
  /*wait for write to complete to SMC before stopping core */  
 // printf("[enter_stop]SMC_PMCTRL   = %#02X \r\n", (SMC_PMCTRL))  ;
 // printf("[enter_stop]SMC_STOPCTRL   = %#02X \r\n", (SMC_STOPCTRL))  ;
  dummyread = SMC_PMCTRL;
  stop();
}

/********************************************************************/
/*
 * VLPR mode entry routine. Puts the processor into very low power
 * run mode. In this mode all clocks are enabled, but the core, bus,
 * and peripheral clocks are limited to 4 MHz or less. The flash
 * clock is limited to 1 MHz or less.
 *
 * Mode transitions:
 * RUN -> VLPR
 *
 * exit_vlpr() function or an interrupt can be used
 * to switch from VLPR back to RUN.
 *
 * Parameters:
 * none
 */
void enter_vlpr(void)
{

	if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK) == 4) {
		printf(" \n[enter_vlpr] Already in VLPR Mode ! ");
		return;
	}
	/* write oneif not all set make sure all enabled */
	SMC_PMPROT = SMC_PMPROT_AVLP_MASK;
	/*
	 * this write-once bit allows the MCU to enter the
	 * very low power modes: VLPR, VLPW, and VLPS.
	 */


        SMC_PMCTRL = SMC_PMCTRL_RUNM(2) |
                  SMC_PMCTRL_STOPM(0x2) ;        
        
	/* Wait for VLPS regulator mode to be confirmed */
	while ((PMC_REGSC & PMC_REGSC_REGONS_MASK) == 0x04) {
		printf(" \n[enter_vlpr] Waiting on REGONS to clear ! ");
	}		/* 0 Regulator in stop Reg mode */
	/* 1 MCU is in Run regulation mode */
	printf("[enter_vlpr] Now in VLPR at 19200 baud  \r\n");

	while ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK) != 4) {
		printf(" \n[enter_vlpr] HALT PMSTAT does not indicate in VLPR Mode ! ");
	}
}

/*
 * VLPR mode exit routine. Puts the processor into normal run mode
 * from VLPR mode. You can transition from VLPR to normal run using
 * this function or an interrupt. 
 *
 * Mode transitions:
 * VLPR -> RUN
 *
 * Parameters:
 * none
 */
void exit_vlpr(void)
{
	/* check to make sure in VLPR before exiting    */
	if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK) == 4) {

		/* Clear RUNM */
		SMC_PMCTRL &= ~(SMC_PMCTRL_RUNM(0x3));

		/*
		 * Wait for normal RUN regulation mode to be confirmed
		 * 0 MCU is not in run regulation mode
		 * 1 MCU is in run regulation mode
		 */
		while (!(PMC_REGSC & PMC_REGSC_REGONS_MASK)) {
			printf(" \n[exit_vlpr] Waiting on REGONS bit to set to indicate "
				   "Run regulation mode ! ");
		}

	}		/* if in VLPR mode */
	/* else if not in VLPR ignore call */
}

/*
 * VLPS mode entry routine. Puts the processor into VLPS mode directly
 * from normal run mode.
 *
 * Mode transitions:
 * RUN -> VLPS
 *
 *
 * Parameters:  none
 * none
 */
void enter_vlps(void)
{
	/* Write to PMPROT to allow VLPS power modes */

	/* write oneif not all set make sure all enabled */
	SMC_PMPROT = SMC_PMPROT_AVLP_MASK;
	/*
	 * this write-once bit allows the MCU to enter the
	 * very low power modes: VLPR, VLPW, and VLPS.
	 *
	 * Set the LPLLSM field to 0b010 for VLPS mode
	 */
		SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
                 			  SMC_PMCTRL_STOPM(0x2);

	/* Now execute the stop instruction to go into VLPS */
	stop();
}

/****************************************************************/
/* LLS3 mode entry routine. Puts the processor into LLS mode from
 * normal run mode or VLPR. 
 *
 * Mode transitions:
 * RUN -> LLS3
 * VLPR -> LLS3
 *
 * NOTE: LLSx mode will always exit to RUN mode even if you were 
 * in VLPR mode before entering LLS.
 *
 * Wakeup from LLSx mode is controlled by the LLWU module. Most
 * modules cannot issue a wakeup interrupt in LLS mode, so make
 * sure to setup the desired wakeup sources in the LLWU before 
 * calling this function.
 *
 * Parameters:
 * none
 */
void enter_lls3(void)
{
    /* Write to PMPROT to allow LLS power modes */
    SMC_PMPROT = SMC_PMPROT_ALLS_MASK;   
    /*this write-once bit allows the MCU to enter the
      LLS low power mode    */
      
    /* Set the STOPM field to 0b011 for LLS mode  
       retain RUNM. No LPWUI bit in K22FN512 and K22FN256 */
    SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
                                SMC_PMCTRL_STOPM(0x3) ; 
     
    /* Set the LLSM field to 0x3 to enter LLS3 mode */
    SMC_STOPCTRL |= SMC_STOPCTRL_LLSM(0x3);
    
    /* Now execute the stop instruction to go into LLS3 */
    stop();
}

/****************************************************************/
/* LLS2 mode entry routine. Puts the processor into LLS2 mode from
 * normal run mode or VLPR. 
 *
 * Mode transitions:
 * RUN -> LLS2
 * VLPR -> LLS2
 *
 * NOTE: LLSx mode will always exit to RUN mode even if you were 
 * in VLPR mode before entering LLS.
 *
 * Wakeup from LLSx mode is controlled by the LLWU module. Most
 * modules cannot issue a wakeup interrupt in LLS mode, so make
 * sure to setup the desired wakeup sources in the LLWU before 
 * calling this function.
 *
 * Parameters:
 * none
 */
void enter_lls2(void)
{
    /* Write to PMPROT to allow LLS power modes */
    SMC_PMPROT = SMC_PMPROT_ALLS_MASK;   
    /*this write-once bit allows the MCU to enter the
      LLS low power mode    */

    
    /* Set the STOPM field to 0b011 for LLS mode  
       retain RUNM.  */
    SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
                                SMC_PMCTRL_STOPM(0x3) ; 
    /* Set the LLSM field to 0 to enter LLS2 mode */
    SMC_STOPCTRL &= ~SMC_STOPCTRL_LLSM_MASK;
    
    /* Now execute the stop instruction to go into LLS2 */
    stop();
}

/*
 * VLLS3 mode entry routine. Puts the processor into VLLS3 mode from
 * normal run mode or VLPR.
 *
 * Mode transitions:
 * RUN -> VLLS3
 * VLPR -> VLLS3
 *
 * NOTE: VLLSx modes will always exit to RUN mode even if you were
 * in VLPR mode before entering VLLSx.
 *
 * Wakeup from VLLSx mode is controlled by the LLWU module. Most
 * modules cannot issue a wakeup interrupt in VLLSx mode, so make
 * sure to setup the desired wakeup sources in the LLWU before
 * calling this function.
 *
 * Parameters:
 * none
 */
void enter_vlls3(void)
{
	/* Write to PMPROT to allow VLLS3 power modes */
	SMC_PMPROT = SMC_PMPROT_AVLLS_MASK;

	/*
	 * Set the VLLSM field to 0b100 for VLLS3 mode -
	 */
	SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
				  SMC_PMCTRL_STOPM(0x4);

	SMC_STOPCTRL = SMC_STOPCTRL_LLSM(3);	/* set VLLSM = 0b11 */

	/* Now execute the stop instruction to go into VLLS3 */
	stop();
}

/*
 * VLLS2 mode entry routine. Puts the processor into VLLS2 mode from
 * normal run mode or VLPR.
 *
 * Mode transitions:
 * RUN -> VLLS2
 * VLPR -> VLLS2
 *
 * NOTE: VLLSx modes will always exit to RUN mode even if you were
 * in VLPR mode before entering VLLSx.
 *
 * Wakeup from VLLSx mode is controlled by the LLWU module. Most
 * modules cannot issue a wakeup interrupt in VLLSx mode, so make
 * sure to setup the desired wakeup sources in the LLWU before
 * calling this function.
 *
 * Parameters:
 * none
 */
void enter_vlls2(void)
{
	/* Write to PMPROT to allow VLLS2 power modes */
	SMC_PMPROT = SMC_PMPROT_AVLLS_MASK;

	/*
	 * Set the VLLSM field to 0b100 for VLLS2 mode -
	 */
	SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
				  SMC_PMCTRL_STOPM(0x4);

	SMC_STOPCTRL = SMC_STOPCTRL_LLSM(2);	/* set VLLSM = 0b10 */

	/* Now execute the stop instruction to go into VLLS2 */
	stop();
}

/*
 * VLLS1 mode entry routine. Puts the processor into VLLS1 mode from
 * normal run mode or VLPR.
 *
 * Mode transitions:
 * RUN -> VLLS1
 * VLPR -> VLLS1
 *
 * NOTE: VLLSx modes will always exit to RUN mode even if you were
 * in VLPR mode before entering VLLSx.
 *
 * Wakeup from VLLSx mode is controlled by the LLWU module. Most
 * modules cannot issue a wakeup interrupt in VLLSx mode, so make
 * sure to setup the desired wakeup sources in the LLWU before
 * calling this function.
 *
 * Parameters:
 * none
 */
void enter_vlls1(void)
{
	/*
	 * Write to PMPROT to allow all possible power modes
	 * Set the VLLSM field to 0b100 for VLLS1 mode -
	 */
	SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
				  SMC_PMCTRL_STOPM(0x4);

	SMC_STOPCTRL = SMC_STOPCTRL_LLSM(1);	/* set VLLSM = 0b01 */

	/* Now execute the stop instruction to go into VLLS1 */
	stop();
}

/*
 * VLLS0 mode entry routine. Puts the processor into VLLS0 mode from
 * normal run mode or VLPR.
 *
 * Mode transitions:
 * RUN -> VLLS0
 * VLPR -> VLLS0
 *
 * NOTE: VLLSx modes will always exit to RUN mode even if you were
 * in VLPR mode before entering VLLSx.
 *
 * Wakeup from VLLSx mode is controlled by the LLWU module. Most
 * modules cannot issue a wakeup interrupt in VLLSx mode, so make
 * sure to setup the desired wakeup sources in the LLWU before
 * calling this function.
 *
 * Parameters:
 * none
 */
void enter_vlls0(void)
{
	/*
	 * Write to PMPROT to allow all possible power modes
	 * Set the VLLSM field to 0b100 for VLLS1 mode -
	 */
	SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
				  SMC_PMCTRL_STOPM(0x4);

	SMC_STOPCTRL = SMC_STOPCTRL_LLSM(0);	/* set PORPO = 0b00 */
	/* Now execute the stop instruction to go into VLLS1 */
	printf("[enter_vlls0]SMC_PMPROT   = %#02X \r\n", (SMC_PMPROT));
	printf("[enter_vlls0]SMC_PMCTRL   = %#02X \r\n", (SMC_PMCTRL));
	printf("[enter_vlls0]SMC_STOPCTRL   = %#02X \r\n", (SMC_STOPCTRL));
	printf("[enter_vlls0]SMC_PMSTAT   = %#02X \r\n\n", (SMC_PMSTAT));
	stop();
}

/*
 * VLLS0 mode entry routine. Puts the processor into VLLS0 mode from
 * normal run mode or VLPR with the POR circuit disabled
 *
 * Mode transitions:
 * RUN -> VLLS0
 * VLPR -> VLLS0
 *
 * NOTE: VLLSx modes will always exit to RUN mode even if you were
 * in VLPR mode before entering VLLSx.
 *
 * Wakeup from VLLSx mode is controlled by the LLWU module. Most
 * modules cannot issue a wakeup interrupt in VLLSx mode, so make
 * sure to setup the desired wakeup sources in the LLWU before
 * calling this function.
 *
 * Parameters:
 * none
 */
void enter_vlls0_nopor(void)
{
	/*
	 * Write to PMPROT to allow all possible power modes
	 * Set the VLLSM field to 0b100 for VLLS1 mode
	 */
	SMC_PMCTRL = (SMC_PMCTRL & SMC_PMCTRL_RUNM_MASK) |
				  SMC_PMCTRL_STOPM(0x4);

	/* set PORPO = 0b01 */
	SMC_STOPCTRL = SMC_STOPCTRL_LLSM(0) | SMC_STOPCTRL_PORPO_MASK;
	/* Now execute the stop instruction to go into VLLS0 */
	printf("[enter_vlls0_nopor]SMC_PMPROT   = %#02X \r\n", (SMC_PMPROT));
	printf("[enter_vlls0_nopor]SMC_PMCTRL   = %#02X \r\n", (SMC_PMCTRL));
	printf("[enter_vlls0_nopor]SMC_STOPCTRL   = %#02X \r\n", (SMC_STOPCTRL));
	printf("[enter_vlls0_nopor]SMC_PMSTAT   = %#02X \r\n\n", (SMC_PMSTAT));
	stop();
}

int switch_to_hsrun_freq(void)
{
  int mcg_clock_hz;

	SIM_CLKDIV1 = (0 | SIM_CLKDIV1_OUTDIV1(CORE_CLK_DIV_HS) |	/* Core/system	 */
				   SIM_CLKDIV1_OUTDIV2(BUS_CLK_DIV_HS) |		/* Busclk		*/
#if defined(MCU_MKV31F512VLL12)
				   SIM_CLKDIV1_OUTDIV3(FLEXBUS_CLK_DIV_HS) |		/* FlexBus		*/
#endif
				   SIM_CLKDIV1_OUTDIV4(FLASH_CLK_DIV_HS));		/* Flash		*/  
   enter_hsrun();
   pee_pbe(CLK0_FREQ_HZ);
   pbe_fbe(CLK0_FREQ_HZ);
   fbe_pbe(CLK0_FREQ_HZ,PLL0_PRDIV_HS,PLL0_VDIV_HS);
   mcg_clock_hz = pbe_pee(CLK0_FREQ_HZ);
   return mcg_clock_hz;
}

int switch_to_run_freq(void)
{
  int mcg_clock_hz;

   pee_pbe(CLK0_FREQ_HZ);
   pbe_fbe(CLK0_FREQ_HZ);
   fbe_pbe(CLK0_FREQ_HZ,PLL0_PRDIV,PLL0_VDIV);
   mcg_clock_hz = pbe_pee(CLK0_FREQ_HZ);
	SIM_CLKDIV1 = (0 | SIM_CLKDIV1_OUTDIV1(CORE_CLK_DIV) |	/* Core/system	 */
				   SIM_CLKDIV1_OUTDIV2(BUS_CLK_DIV) |		/* Busclk		*/
#if defined(MCU_MKV31F512VLL12)
				   SIM_CLKDIV1_OUTDIV3(FLEXBUS_CLK_DIV) |		/* FlexBus		*/
#endif
				   SIM_CLKDIV1_OUTDIV4(FLASH_CLK_DIV));		/* Flash		*/  
   exit_hsrun();
   return mcg_clock_hz;
}