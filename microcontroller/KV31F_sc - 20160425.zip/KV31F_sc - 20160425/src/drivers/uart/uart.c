/*
 * All software, source code, included documentation, and any implied know-how
 * are property of Freescale Semiconductor and therefore considered
 * CONFIDENTIAL INFORMATION.
 * This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.
 *
 * All Confidential Information remains the property of Freescale Semiconductor
 * and will not be copied or reproduced without the express written permission
 * of the Discloser, except for copies that are absolutely necessary in order
 * to fulfill the Purpose.
 *
 * Services performed by FREESCALE in this matter are performed AS IS and
 * without any warranty.
 * CUSTOMER retains the final decision relative to the total design and
 * functionality of the end product.
 * FREESCALE neither guarantees nor will be held liable by CUSTOMER for the
 * success of this project.
 *
 * FREESCALE disclaims all warranties, express, implied or statutory
 * including, but not limited to, implied warranty of merchantability or
 * fitness for a particular purpose on any hardware, software ore advise
 * supplied to the project by FREESCALE, and or any product resulting from
 * FREESCALE services.
 * In no event shall FREESCALE be liable for incidental or consequential
 * damages arising out of this agreement. CUSTOMER agrees to hold FREESCALE
 * harmless against any and all claims demands or actions by anyone on account
 * of any damage,or injury, whether commercial, contractual, or tortuous,
 * rising directly or indirectly as a result of the advise or assistance
 * supplied CUSTOMER in connectionwith product, services or goods supplied
 * under this Agreement.
 */
 
#include "common.h"
#include "uart.h"

/*
 * \brief	Initialize the UART for 8N1 operation, interrupts disabled, and
 * \brief	no hardware flow-control
 * \author
 * \param
 *		uartch		UART channel to initialize
 *		sysclk		UART module Clock in kHz(used to calculate baud)
 *		baud		UART baud rate
 * \return
 *		none
 * \todo
 * \warning	Since the UARTs are pinned out in multiple locations on most
 *			Kinetis devices, this driver does not enable UART pin functions.
 *			The desired pins should be enabled before calling this init function.
 */
void uart_init(UART_MemMapPtr uartch, long sysclk, int baud)
{
	register uint16 sbr, brfa;
	uint8 temp;

	/* Enable the clock to the selected UART */
	if (uartch == UART0_BASE_PTR)
        {
		SIM_SCGC4 |= SIM_SCGC4_UART0_MASK;
        }
	else if (uartch == UART1_BASE_PTR)
		SIM_SCGC4 |= SIM_SCGC4_UART1_MASK;
	else
		SIM_SCGC4 |= SIM_SCGC4_UART2_MASK;
	
	/*
	 * Make sure that the transmitter and receiver are disabled while we
	 * change settings.
	 */
	UART_C2_REG(uartch) &= ~(UART_C2_TE_MASK | UART_C2_RE_MASK);

	/*
	 * Configure the UART for 8-bit mode, no parity
	 * We need all default settings, so entire register is cleared
	 */
	UART_C1_REG(uartch) = 0;

	/* Calculate baud settings */
	sbr = (uint16) (((long) sysclk * 1000) / (long) (baud * 16));
       
	/* Save off the current value of the UARTx_BDH except for the SBR field */
	temp = UART_BDH_REG(uartch) & ~(UART_BDH_SBR(0x1F));

	UART_BDH_REG(uartch) = temp | UART_BDH_SBR(((sbr & 0x1F00) >> 8));
	UART_BDL_REG(uartch) = (uint8) (sbr & UART_BDL_SBR_MASK);

	/*
	 * Determine if a fractional divider is needed to get
	 * closer to the baud rate
	 */
	brfa = ((((long) sysclk * 32000) / (long) (baud * 16)) - (long)(sbr * 32));

	/*
	 * Save off the current value of the UARTx_C4 register except for the
	 * BRFA field
	 */
	temp = UART_C4_REG(uartch) & ~(UART_C4_BRFA(0x1F));

	UART_C4_REG(uartch) = temp | UART_C4_BRFA(brfa);

	/* Enable receiver and transmitter */
	UART_C2_REG(uartch) |= (UART_C2_TE_MASK | UART_C2_RE_MASK);
}

/*
 * \brief	Wait for a character to be received on the specified UART
 * \author
 * \param	channel		UART channel to read from
 * \return	the received character
 * \todo
 * \warning
 */
char uart_getchar(UART_MemMapPtr channel)
{
	/* Wait until character has been received */
	while (!(UART_S1_REG(channel) & UART_S1_RDRF_MASK)) ;

	/* Return the 8-bit data from the receiver */
	return UART_D_REG(channel);
}

/*
 * \brief	Wait for space in the UART Tx FIFO and then send a character
 * \author
 * \param	channel	UART channel to send to
 * \param	ch		character to send
 * \return	none
 * \todo
 * \warning
 */
void uart_putchar(UART_MemMapPtr channel, char ch)
{
	/* Wait until space is available in the FIFO */
	while (!(UART_S1_REG(channel) & UART_S1_TDRE_MASK)) ;

	/* Send the character */
	UART_D_REG(channel) = (uint8) ch;
}

/*
 * \brief	Check to see if a character has been received
 * \author
 * \param	channel	UART channel to check for a character
 * \param	ch		character to send
 * \return	0		No character received
 * \return	1		Character has been received
 * \todo
 * \warning
 */
int uart_getchar_present(UART_MemMapPtr channel)
{
	return (UART_S1_REG(channel) & UART_S1_RDRF_MASK);
}


/*******************************************************************************************************/
void uart_configure(int mcg_clock_hz)
{
  /* UART0 and UART1 are clocked from the core clock, but all other UARTs are
         * clocked from the peripheral clock. So we have to determine which clock
         * to send to the uart_init function.
         */
      int mcg_clock_khz;
      int core_clock_khz;
      int periph_clock_khz;

      mcg_clock_khz = mcg_clock_hz / 1000;
      core_clock_khz = mcg_clock_khz / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV1_MASK) >> SIM_CLKDIV1_OUTDIV1_SHIFT)+ 1);
      periph_clock_khz = mcg_clock_khz / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV2_MASK) >> SIM_CLKDIV1_OUTDIV2_SHIFT)+ 1);

      if ((TERM_PORT == UART0_BASE_PTR) | (TERM_PORT == UART1_BASE_PTR))
          uart_init (TERM_PORT, core_clock_khz, TERMINAL_BAUD);
      else
          uart_init (TERM_PORT, periph_clock_khz, TERMINAL_BAUD);
}