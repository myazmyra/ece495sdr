/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file         motor_structure.h
*
* @brief        Motor control structure
* 
*******************************************************************************/

#ifndef _MCSTRUC_H_
#define _MCSTRUC_H_

/******************************************************************************
* Includes
******************************************************************************/
#include "gflib.h"
#include "gmclib.h"
#include "gdflib.h"
#include "aclib.h"

#include "SWLIBS_Typedefs.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros 
******************************************************************************/


/******************************************************************************
* Types
******************************************************************************/

typedef struct
{
    Frac16                    f16UdReq;            /* Required D voltage at alignment */
    UWord16                   uw16Time;            /* Alignment time duration */
    UWord16                   uw16TimeHalf;        /* Alignment half time duration */
}MCS_ALIGNMENT_A1_T;          /* PMSM simple two-step Ud voltage alignment */

typedef struct
{
    GFLIB_CONTROLLER_PIAW_P_T           sIdPiParams;        /* Id PI controller parameters */
    GFLIB_CONTROLLER_PIAW_P_T           sIqPiParams;        /* Iq PI controller parameters */
    GDFLIB_FILTER_IIR1_T                sUDcBusFilter;      /* Dc bus voltage filter */
    MCLIB_3_COOR_SYST_T                 sIABC;              /* Measured 3-phase current */
    MCLIB_2_COOR_SYST_ALPHA_BETA_T      sIAlBe;             /* Alpha/Beta current */
    MCLIB_2_COOR_SYST_D_Q_T             sIDQ;               /* DQ current */
    MCLIB_2_COOR_SYST_D_Q_T             sIDQReq;            /* DQ required current */
    MCLIB_2_COOR_SYST_D_Q_T             sIDQError;          /* DQ current error */
    MCLIB_3_COOR_SYST_T                 sDutyABC;           /* Applied duty cycles ABC */
    MCLIB_2_COOR_SYST_ALPHA_BETA_T      sUAlBeReq;          /* Required Alpha/Beta voltage */
    MCLIB_2_COOR_SYST_ALPHA_BETA_T      sUAlBeComp;         /* Compensated to DC bus Alpha/Beta voltage */
    MCLIB_2_COOR_SYST_D_Q_T             sUDQReq;            /* Required DQ voltage */
    MCLIB_ANGLE_T                       sAnglePosEl;        /* Electrical position sin/cos (at the moment of PWM current reading) */
    MCLIB_ANGLE_T                       sAnglePosElReload;  /* Compensated electrical position sin/cos (at the moment of PWM update) */ 
    GMCLIB_ELIM_DC_BUS_RIP_T            sElimDCBRip;        /* DCB ripple elimination parameters structure */ 
    UWord16                             uw16SectorSVM;      /* SVM sector */
    Frac16                              f16PosElReload;     /* Electrical position (at the moment of PWM update) */ 
    Frac16                              f16DutyCycleLimit;  /* Max. allowable duty cycle in frac */
    Frac16                              f16UDcBus;          /* DC bus voltage */
    Frac16                              f16UDcBusFilt;      /* Filtered DC bus voltage */
    Int16                               i16IdPiSatFlag;     /* Id PI controller saturation flag */
    Int16                               i16IqPiSatFlag;     /* Iq PI controller saturation flag */
} MCS_PMSM_FOC_A1_T;

typedef struct
{
    GFLIB_RAMP_T_F32                    sFreqRampParams;    /* Parameters of frequency ramp */
    MCLIB_2_COOR_SYST_D_Q_T             sUDQReq;            /* Required voltage vector in d,q coordinates */
    GFLIB_INTEGRATOR_TR_T               sFreqIntegrator;    /* structure contains the integrator parameters (integrates the omega in order to get the position */
    Frac32                              f32FreqCmd;         /* required electrical frequency from master system */
    Frac16                              f16FreqRamp;        /* Required frequency limited by ramp - the ramp output */
    Frac16                              f16PosElScalar;     /* Electrical angle of the rotor */ 
    Frac16                              f16VHzGain;         /* VHz_factor constant gain for scalar control */    
    Word16                              f16VHzGainShift;    /* VHz_factor constant shift for scalar control */
}MCS_PMSM_SCALAR_CTRL_A1_T;


typedef struct
{
    GDFLIB_FILTER_IIR1_T                sSpeedFilter;       /* Speed filter */                
    GFLIB_CONTROLLER_PIAW_P_T           sSpeedPiParams;     /* Speed PI controller parameters */
    GFLIB_RAMP_T_F32                    sSpeedRampParams;   /* Speed ramp parameters */
    Frac16                              f16Speed;           /* Speed */
    Frac16                              f16SpeedFilt;       /* Speed filtered */
    Frac16                              f16SpeedError;      /* Speed error */
    Frac16                              f16SpeedRamp;       /* Required speed (ramp output) */
    Frac16                              f16SpeedReq;        /* Required speed (ramp input) */
    Frac16                              f16SpeedCmd;        /* Speed command (entered by user or master layer) */
    Int16                               i16SpeedPiSatFlag;  /* Speed PI controller saturation flag */
} MCS_SPEED_A1_T;

typedef struct{
    MCLIB_2_COOR_SYST_D_Q_T             sIDQReqMCAT;        /* required dq current entered from MCAT tool */
    MCLIB_2_COOR_SYST_D_Q_T             sUDQReqMCAT;        /* required dq voltage entered from MCAT tool */
    UWord16                             uw16PospeSensor;    /* position sensor type information */
} MCS_MCAT_CTRL_A1_T;


typedef struct
{
    GFLIB_INTEGRATOR_TR_T               sSpeedIntegrator;           /* Speed integrator structure */
    GFLIB_RAMP_T_F32                    sSpeedRampOpenLoopParams;   /* Parameters of startup speed ramp */
    Frac32                              f32SpeedReq;                /* Required speed */ 
    Frac16                              f16PosEst;                  /* Fractional electrical position */ 
    Frac16                              f16SpeedRampOpenLoop;       /* Open loop startup speed ramp */
    Frac16                              f16CoeffMerging;            /* increment of merging weight for position merging */ 
    Frac16                              f16RatioMerging;            /* merging weight coefficient */ 
    Frac16                              f16PosGen;                  /* generated open loop position from the speed ramp integration */
    Frac16                              f16PosMerged;               /* merged position */    
    Frac16                              f16SpeedCatchUp;            /* merging speed threshold */    
    Frac16                              f16CurrentStartup;          /* required Iq current during open loop start up */ 
    UWord16                             uw16TimeStartUpFreeWheel;   /* Free-wheel duration if start-up aborted by user input (required zero speed) */
    bool                                bOpenLoop;                  /* Position estimation loop is open */     
} MCS_PMSM_STARTUP_A1_T;              /* simple open-loop start-up with merged position and constant start-up current */

/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void MCS_PMSMFocCtrlVoltageA1(MCS_PMSM_FOC_A1_T *psFocPMSM);
extern void MCS_PMSMFocCtrlCurrentA1(MCS_PMSM_FOC_A1_T *psFocPMSM);
extern void MCS_PMSMFocCtrlCurrentCallLessA1(MCS_PMSM_FOC_A1_T *psFocPMSM);
extern void MCS_PMSMFocCtrlSpeedA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_SPEED_A1_T *psSpeed);
extern void MCS_PMSMAlignmentA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_ALIGNMENT_A1_T *psAlignment); 
extern void MCS_PMSMOpenLoopStartUpA1(MCS_PMSM_STARTUP_A1_T *psStartUp); 
extern void MCS_PMSMScalarCtrlA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_PMSM_SCALAR_CTRL_A1_T *psScalarPMSM);

#ifdef __cplusplus
}
#endif
/******************************************************************************
* Inline functions
******************************************************************************/

#endif /* _MCSTRUC_H_ */