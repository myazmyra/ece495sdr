/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file         motor_structure.c
*
* @brief        Motor control structure
* 
*******************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "motor_structure.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros 
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/

/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Global functions
******************************************************************************/

/***************************************************************************//*!
*
* @brief   PMSM field oriented voltage control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN: -> sAnglePosElReload - angle where the next PWM reload
*            IN: -> f16AnglePosReload - position where next PWM reload
*            IN: -> f16UDcBusFilt - actual DCBus voltage value
*            IN: -> sUDQReq - D and Q required voltages
*            IN/OUT -> sUAlBeReq - D nad Q Alpha/Beta voltages
*            OUT -> sDutyABC - ABC duty cycles
*            OUT -> uw16SectorSVM - Next step SVM sector
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMFocCtrlVoltageA1(MCS_PMSM_FOC_A1_T *psFocPMSM)
{
    /* Position angle of the last PWM update */
    psFocPMSM -> sAnglePosEl = psFocPMSM -> sAnglePosElReload;
    
    /* calculation of rotor position sinus and cosinus */
    psFocPMSM -> sAnglePosElReload.f16Sin = GFLIB_Sin(psFocPMSM -> f16PosElReload);
    psFocPMSM -> sAnglePosElReload.f16Cos = GFLIB_Cos(psFocPMSM -> f16PosElReload);
    
    /* 2-phase to 2-phase transformation to stationary ref. frame */
    GMCLIB_ParkInv(&psFocPMSM -> sUAlBeReq, &psFocPMSM -> sAnglePosElReload, &psFocPMSM -> sUDQReq);

    psFocPMSM -> sElimDCBRip.f16ArgDcBusMsr  = psFocPMSM -> f16UDcBusFilt;
    
    /* Begin - voltage control */
    GMCLIB_ElimDcBusRip(&psFocPMSM -> sUAlBeComp,&psFocPMSM -> sUAlBeReq,&psFocPMSM -> sElimDCBRip) ;   

    psFocPMSM -> uw16SectorSVM = GMCLIB_SvmStd(&psFocPMSM -> sDutyABC,&psFocPMSM -> sUAlBeComp); 
}

/***************************************************************************//*!
*
* @brief   PMSM field oriented current control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN: -> sIABC - input ABC phases currents
*            IN: -> sAnglePosEl - angle where the currents were measured
*            IN: -> sAnglePosElReload - angle where the next PWM reload
*            IN: -> f16UDcBusFilt - DC bus voltage
*            IN: -> f16UDcBusFilt - actual DCBus voltage value
*            IN: -> f16DutyCycleLimit - determines the max. value of duty cycle
*            IN/OUT -> sIdPiParams - D current controller structure
*            IN/OUT -> sIqPiParams - Q current controller structure
*            IN/OUT -> i16IdPiSatFlag - D current controller saturation flag
*            IN/OUT -> i16IqPiSatFlag - Q current controller saturation flag
*            OUT -> sDutyABC - ABC duty cycles
*            OUT -> uw16SectorSVM - Next step SVM sector
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMFocCtrlCurrentA1(MCS_PMSM_FOC_A1_T *psFocPMSM)
{
    /* Position angle of the last PWM update */
    psFocPMSM -> sAnglePosEl = psFocPMSM -> sAnglePosElReload;
    
   /* sine and cosine of the angle */
    psFocPMSM -> sAnglePosElReload.f16Sin = GFLIB_Sin(psFocPMSM -> f16PosElReload);
    psFocPMSM -> sAnglePosElReload.f16Cos = GFLIB_Cos(psFocPMSM -> f16PosElReload);
    
    /* 3-phase to 2-phase transformation to stationary ref. frame */
    GMCLIB_Clark(&psFocPMSM -> sIAlBe, &psFocPMSM -> sIABC, F16);
    
    /* 2-phase to 2-phase transformation to rotary ref. frame */
    GMCLIB_Park(&psFocPMSM -> sIDQ, &psFocPMSM -> sAnglePosEl, &psFocPMSM -> sIAlBe, F16);
    
    /* D current error calculation */
    psFocPMSM -> sIDQError.f16D = MLIB_SubSat_F16(psFocPMSM -> sIDQReq.f16D, psFocPMSM -> sIDQ.f16D);

    /* Q current error calculation */
    psFocPMSM -> sIDQError.f16Q = MLIB_SubSat_F16(psFocPMSM -> sIDQReq.f16Q, psFocPMSM -> sIDQ.f16Q);    
    
    /*** D - controller limitation calculation ***/
    psFocPMSM -> sIdPiParams.f16UpperLimit = MLIB_Mul_F16(psFocPMSM -> f16DutyCycleLimit, psFocPMSM -> f16UDcBusFilt);
    psFocPMSM -> sIdPiParams.f16LowerLimit = MLIB_Neg_F16(psFocPMSM -> sIdPiParams.f16UpperLimit);    

    /* D current PI controller */  
    psFocPMSM -> sUDQReq.f16D = GFLIB_ControllerPIpAW(psFocPMSM -> sIDQError.f16D, &psFocPMSM -> sIdPiParams);

    /* D current controller saturation flag */
    psFocPMSM -> i16IdPiSatFlag = psFocPMSM -> sIdPiParams.u16LimitFlag;

    /*** Q - controller limitation calculation ***/
    psFocPMSM -> sIqPiParams.f16UpperLimit = GFLIB_Sqrt(MLIB_Sub_F16(MLIB_Mul_F16(psFocPMSM -> sIdPiParams.f16UpperLimit,psFocPMSM -> sIdPiParams.f16UpperLimit), \
                                                        MLIB_Mul_F16(psFocPMSM ->sUDQReq.f16D,psFocPMSM ->sUDQReq.f16D)));
    psFocPMSM -> sIqPiParams.f16LowerLimit = MLIB_Neg_F16(psFocPMSM -> sIqPiParams.f16UpperLimit);   

    /* Q current PI controller */
    psFocPMSM -> sUDQReq.f16Q = GFLIB_ControllerPIpAW(psFocPMSM -> sIDQError.f16Q, &psFocPMSM -> sIqPiParams,F16);
    
    /* Q current controller saturation flag */
    psFocPMSM -> i16IqPiSatFlag = psFocPMSM -> sIqPiParams.u16LimitFlag;    
    
    /* 2-phase to 2-phase transformation to stationary ref. frame */
    GMCLIB_ParkInv(&psFocPMSM -> sUAlBeReq, &psFocPMSM -> sAnglePosEl, &psFocPMSM -> sUDQReq);

    /* DCBus ripple elimination */
    psFocPMSM -> sElimDCBRip.f16ArgDcBusMsr  = psFocPMSM -> f16UDcBusFilt;
    GMCLIB_ElimDcBusRip(&psFocPMSM -> sUAlBeComp,&psFocPMSM -> sUAlBeReq,&psFocPMSM -> sElimDCBRip) ;   

    /* space vector modulation */
    psFocPMSM -> uw16SectorSVM = GMCLIB_SvmStd(&psFocPMSM -> sDutyABC,&psFocPMSM -> sUAlBeComp); 

    /* End - voltage control */    
}

/***************************************************************************//*!
*
* @brief   PMSM field oriented current control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN: -> sIABC - input ABC phases currents
*            IN: -> sAnglePosEl - angle where the currents were measured
*            IN: -> sAnglePosElReload - angle where the next PWM reload
*            IN: -> f16UDcBusFilt - DC bus voltage
*            IN: -> f16UDcBusFilt - actual DCBus voltage value
*            IN: -> f16DutyCycleLimit - determines the max. value of duty cycle
*            IN/OUT -> sIdPiParams - D current controller structure
*            IN/OUT -> sIqPiParams - Q current controller structure
*            IN/OUT -> i16IdPiSatFlag - D current controller saturation flag
*            IN/OUT -> i16IqPiSatFlag - Q current controller saturation flag
*            OUT -> sDutyABC - ABC duty cycles
*            OUT -> uw16SectorSVM - Next step SVM sector
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMFocCtrlCurrentCallLessA1(MCS_PMSM_FOC_A1_T *psFocPMSM)
{
    
  /* Position angle of the last PWM update */
    psFocPMSM -> sAnglePosEl = psFocPMSM -> sAnglePosElReload;
    
   /* sine and cosine of the angle */
    //psFocPMSM -> sAnglePosElReload.f16Sin = GFLIB_Sin(psFocPMSM -> f16PosElReload);
       
    Frac16 f16X;
    Frac16 f16Y;
    Frac16 f16Z;
    const Frac16 f16gflibSinCoef[] = {-142, 2604, -21165, 18704};
    const Frac16 f16gflibCosCoef[] = {-142, 2604, -21165, 18704};
    Frac16    f16A;
    Frac16    f16B;
    Frac16    f16Sin;
    Frac16    f16Cos;
    Frac32    f32Arg1, f32Arg2;
    Frac32 f32Tmp;
    
    register Frac32    f32Proportional;
    register Frac32    f32Integral;
    register Frac32    f32IntegralX1;
    register Frac32    f32IntegralX2;
    register Frac32    f32Out;
    register Frac32    f32UpperLimit;
    register Frac32    f32LowerLimit;
    
    register Frac16 f16Alpha;
    register Frac16 f16Beta;
    register Frac16 f16AlphaAbs;
    register Frac16 f16BetaAbs;
    register Frac16 f16DcBusMsrBy2;
    
    register Frac16    f16D;
    register Frac16    f16Q;
    
    register Frac16 f16XSat;
    register Frac16 f16YSat;
    register Frac16 f16ZSat;
    volatile Frac16 f16Save;
    register Frac16 f16Alfa;
    register Frac16 f16Arg2Shift;
    register Frac16 f16ArgShiftTmp;
    register Frac16 f16AlfaShift;
    
    /* Multiplication  f16In * 2 = f16Y for better accuracy is sin calculation into half range */
    f16Y = MLIB_ShL_F16(psFocPMSM -> f16PosElReload,(UWord16)1);
    /* Absolute value */
    f16Y = MLIB_Abs_F16(f16Y);
    /* Sine is calculation into the half and negative range */
    f16X = MLIB_Neg_F16(f16Y);
    /* f16y = f16X^2 */
    f16Y = MLIB_MulSat_F16(f16X, f16X);

    /*------------------------------------------------------------------------
    * x + x(a1 + x^2*(a3 + x^2(a5 + a7 * x^2)))
    *------------------------------------------------------------------------*/
    /* a5 + a7 * x^2 */
    f16Z = MLIB_Mac_F16(f16gflibSinCoef[1],f16gflibSinCoef[0],f16Y);
    /* a3 + x^2(a5 + a7 * x^2) */
    f16Z = MLIB_Mac_F16(f16gflibSinCoef[2],f16Z,f16Y);
    /* a1 + x^2(a3 + x^2(a5 + a7 * x^2)) */
    f16Z = MLIB_Mac_F16(f16gflibSinCoef[3],f16Z,f16Y);
    /* x(a1 + x^2*(a3 + x^2(a5 + a7* x^2))) */
    f16Z = MLIB_MulSat_F16(f16Z,f16X);
    /* x + x(a1 + x^2*(a3 + x^2(a5 + a7* x^2))) */
    f16Z = MLIB_AddSat_F16(f16Z,f16X);

    /* Sign is add into the result */
    /** @remarks Implements DGFLIB00004, DGFLIB00007 */
    psFocPMSM -> sAnglePosElReload.f16Sin =((psFocPMSM -> f16PosElReload > 0) ? MLIB_NegSat_F16(f16Z) : f16Z);
    
   // psFocPMSM -> sAnglePosElReload.f16Cos = GFLIB_Cos(psFocPMSM -> f16PosElReload);

    /* cos(pi * f16In) = sin((0.5 + f16In)*pi) */
    psFocPMSM -> f16PosElReload = MLIB_Add_F16(psFocPMSM -> f16PosElReload, FRAC16_0_5);
    /* Multiplication  f16In * 2 = f16Y for better accuracy is sin calculation into half range */
    f16Y = MLIB_ShL_F16(psFocPMSM -> f16PosElReload,(UWord16)1);
    /* Absolute value */
    f16Y = MLIB_Abs_F16(f16Y);
    /* Sine is calculation into the half and negative range */
    f16X = MLIB_Neg_F16(f16Y);
    /* f16y = f16X^2 */
    f16Y = MLIB_MulSat_F16(f16X, f16X);

    /*------------------------------------------------------------------------
    * x + x(a1 + x^2*(a3 + x^2(a5 + a7 * x^2)))
    *------------------------------------------------------------------------*/
    /* a5 + a7 * x^2 */
    f16Z = MLIB_Mac_F16(f16gflibCosCoef[1],f16gflibCosCoef[0],f16Y);
    /* a3 + x^2(a5 + a7 * x^2) */
    f16Z = MLIB_Mac_F16(f16gflibCosCoef[2],f16Z,f16Y);
    /* a1 + x^2(a3 + x^2(a5 + a7 * x^2)) */
    f16Z = MLIB_Mac_F16(f16gflibCosCoef[3],f16Z,f16Y);
    /* x(a1 + x^2*(a3 + x^2(a5 + a7* x^2))) */
    f16Z = MLIB_MulSat_F16(f16Z,f16X);
    /* x + x(a1 + x^2*(a3 + x^2(a5 + a7* x^2))) */
    f16Z = MLIB_AddSat_F16(f16Z,f16X);

    /* Sign is add into the result */
    /** @remarks Implements DGFLIB00017, DGFLIB00020 */
    psFocPMSM -> sAnglePosElReload.f16Cos =((psFocPMSM -> f16PosElReload > 0) ? MLIB_NegSat_F16(f16Z) : f16Z);
    
    /* 3-phase to 2-phase transformation to stationary ref. frame */
    //GMCLIB_Clark(&psFocPMSM -> sIAlBe, &psFocPMSM -> sIABC, F16);
       
    /* Count orthogonal ALPHA coordinate [iAlpha = iA] */
    psFocPMSM -> sIAlBe.f16Alpha = psFocPMSM -> sIABC.f16A;
    /* Count BETA orthogonal coordinate [iBeta = (iB - iC) * (1/sqrt(3))] */
    psFocPMSM -> sIAlBe.f16Beta = MLIB_SubSat_F16(MLIB_Mul_F16(psFocPMSM -> sIABC.f16B,F16_1_DIVBY_SQRT3),
                                    MLIB_Mul_F16(psFocPMSM -> sIABC.f16C,F16_1_DIVBY_SQRT3));
    /** @remarks Implements DGMCLIB00009 */
   
    /* 2-phase to 2-phase transformation to rotary ref. frame */
    //GMCLIB_Park(&psFocPMSM -> sIDQ, &psFocPMSM -> sAnglePosEl, &psFocPMSM -> sIAlBe, F16);

    f16A    = (psFocPMSM -> sIAlBe.f16Alpha);
    f16B    = (psFocPMSM -> sIAlBe.f16Beta);
    f16Sin  = (psFocPMSM -> sAnglePosEl.f16Sin);
    f16Cos  = (psFocPMSM -> sAnglePosEl.f16Cos);

    f32Arg1 = MLIB_MulSat_F32F16F16(f16Cos,f16A);
    f32Arg2 = MLIB_MulSat_F32F16F16(f16Sin,f16B);

    f32Arg1 = MLIB_AddSat_F32(MLIB_AddSat_F32(f32Arg1,f32Arg2),(Frac32)0x00008000);
    f32Tmp = MLIB_ShR_F32(f32Arg1,(UWord16)16);
    psFocPMSM -> sIDQ.f16D = (Frac16)f32Tmp;

    f32Arg1 = MLIB_MulSat_F32F16F16(f16Cos,f16B);
    f32Arg2 = MLIB_MulSat_F32F16F16(f16Sin,f16A);

    f32Arg2 = MLIB_AddSat_F32(MLIB_SubSat_F32(f32Arg1,f32Arg2),(Frac32)0x00008000);
    psFocPMSM -> sIDQ.f16Q = (Frac16)MLIB_ShR_F32(f32Arg2,(UWord16)16);

    /* D current error calculation */
    psFocPMSM -> sIDQError.f16D = MLIB_SubSat_F16(psFocPMSM -> sIDQReq.f16D, psFocPMSM -> sIDQ.f16D);

    /* Q current error calculation */
    psFocPMSM -> sIDQError.f16Q = MLIB_SubSat_F16(psFocPMSM -> sIDQReq.f16Q, psFocPMSM -> sIDQ.f16Q);    
    
    /*** D - controller limitation calculation ***/
    psFocPMSM -> sIdPiParams.f16UpperLimit = MLIB_Mul_F16(psFocPMSM -> f16DutyCycleLimit, psFocPMSM -> f16UDcBusFilt);
    psFocPMSM -> sIdPiParams.f16LowerLimit = MLIB_Neg_F16(psFocPMSM -> sIdPiParams.f16UpperLimit);    

    /* D current PI controller */  
    //psFocPMSM -> sUDQReq.f16D = GFLIB_ControllerPIpAW(psFocPMSM -> sIDQError.f16D, &psFocPMSM -> sIdPiParams);

    f32Proportional = MLIB_MulSat_F32F16F16(psFocPMSM -> sIdPiParams.f16PropGain, psFocPMSM -> sIDQError.f16D);
    /* Limitation of proportional term applied during calculation, to prevent overflow caused by scaling shift. */
    f32Proportional = MLIB_ShBiSat_F32(f32Proportional, (psFocPMSM -> sIdPiParams.w16PropGainShift));

    /* Calculation of integral term */
    f32IntegralX1 = MLIB_Mul_F32F16F16(psFocPMSM -> sIdPiParams.f16IntegGain, psFocPMSM -> sIDQError.f16D);
    f32IntegralX2 = MLIB_Mul_F32F16F16(psFocPMSM -> sIdPiParams.f16IntegGain, psFocPMSM -> sIdPiParams.f16InK_1);
    f32Integral = MLIB_AddSat_F32(f32IntegralX1, f32IntegralX2);
    f32Integral = MLIB_ShBiSat_F32(f32Integral, (psFocPMSM -> sIdPiParams.w16IntegGainShift));
    f32Integral = MLIB_AddSat_F32(f32Integral, psFocPMSM -> sIdPiParams.f32IntegPartK_1);

    /* Calculation of limits in 32-bit */
    f32UpperLimit = MLIB_ShL_F32((Frac32)(psFocPMSM -> sIdPiParams.f16UpperLimit), (UWord16)16U);
    f32LowerLimit = MLIB_ShL_F32((Frac32)(psFocPMSM -> sIdPiParams.f16LowerLimit), (UWord16)16U);

    /* Limitation of integral term applied during calculation, to prevent overflow caused by scaling shift and to
       limit the integral output within the user defined limits. */
    if (f32Integral >= f32UpperLimit){
      f32Integral = f32UpperLimit;
    }else{
      if(f32Integral <= f32LowerLimit){
        f32Integral = f32LowerLimit;
      }
    }

    /* Storing state value of the integral */
    psFocPMSM -> sIdPiParams.f32IntegPartK_1 = f32Integral;
    /* Calculation of the controller output by adding the proportional and integral terms, saturation is handled
       correctly here. */
    f32Out = MLIB_AddSat_F32(f32Proportional, f32Integral);
    f32Out = MLIB_AddSat_F32(f32Out,(Frac32)0x00008000);

   psFocPMSM -> sIdPiParams.u16LimitFlag = (UWord16)0;
    /* Limitation of resulting PI output (after addition of proportional and integral terms) */
    if (f32Out >= f32UpperLimit){
      f32Out = f32UpperLimit;
      /* Storing of output limitation flag */
      psFocPMSM -> sIdPiParams.u16LimitFlag = (UWord16)1;
    }else{
      if(f32Out <= f32LowerLimit){
        f32Out = f32LowerLimit;
        /* Storing of output limitation flag */
        psFocPMSM -> sIdPiParams.u16LimitFlag = (UWord16)1;
      }
    }

    /* Updating controller input state variables */
    psFocPMSM -> sIdPiParams.f16InK_1 = psFocPMSM -> sIDQError.f16D;

    /** @remarks Implements DGFLIB00308, DGFLIB00311 */
    psFocPMSM -> sUDQReq.f16D =((Frac16)MLIB_ShR_F32(f32Out,(UWord16)16));
 
    /* D current controller saturation flag */
    psFocPMSM -> i16IdPiSatFlag = psFocPMSM -> sIdPiParams.u16LimitFlag;
    
    // GFLIB_Sqrt is not inlined to preserve compatibility all Kinetis (MMCLIB for KV10 uses HW sqrt in the function)
    /*** Q - controller limitation calculation ***/
    psFocPMSM -> sIqPiParams.f16UpperLimit = GFLIB_Sqrt(MLIB_Sub_F16(MLIB_Mul_F16(psFocPMSM -> sIdPiParams.f16UpperLimit,psFocPMSM -> sIdPiParams.f16UpperLimit), \
                                                        MLIB_Mul_F16(psFocPMSM ->sUDQReq.f16D,psFocPMSM ->sUDQReq.f16D)));

    /* Q current PI controller */
    //psFocPMSM -> sUDQReq.f16Q = GFLIB_ControllerPIpAW(psFocPMSM -> sIDQError.f16Q, &psFocPMSM -> sIqPiParams,F16);

    f32Proportional = MLIB_MulSat_F32F16F16(psFocPMSM -> sIqPiParams.f16PropGain, psFocPMSM -> sIDQError.f16Q);
    /* Limitation of proportional term applied during calculation, to prevent overflow caused by scaling shift. */
    f32Proportional = MLIB_ShBiSat_F32(f32Proportional, (psFocPMSM -> sIqPiParams.w16PropGainShift));

    /* Calculation of integral term */
    f32IntegralX1 = MLIB_Mul_F32F16F16(psFocPMSM -> sIqPiParams.f16IntegGain, psFocPMSM -> sIDQError.f16Q);
    f32IntegralX2 = MLIB_Mul_F32F16F16(psFocPMSM -> sIqPiParams.f16IntegGain, psFocPMSM -> sIqPiParams.f16InK_1);
    f32Integral = MLIB_AddSat_F32(f32IntegralX1, f32IntegralX2);
    f32Integral = MLIB_ShBiSat_F32(f32Integral, (psFocPMSM -> sIqPiParams.w16IntegGainShift));
    f32Integral = MLIB_AddSat_F32(f32Integral, psFocPMSM -> sIqPiParams.f32IntegPartK_1);

    /* Calculation of limits in 32-bit */
    f32UpperLimit = MLIB_ShL_F32((Frac32)(psFocPMSM -> sIqPiParams.f16UpperLimit), (UWord16)16U);
    f32LowerLimit = MLIB_ShL_F32((Frac32)(psFocPMSM -> sIqPiParams.f16LowerLimit), (UWord16)16U);

    /* Limitation of integral term applied during calculation, to prevent overflow caused by scaling shift and to
       limit the integral output within the user defined limits. */
    if (f32Integral >= f32UpperLimit){
      f32Integral = f32UpperLimit;
    }else{
      if(f32Integral <= f32LowerLimit){
        f32Integral = f32LowerLimit;
      }
    }

    /* Storing state value of the integral */
    psFocPMSM -> sIqPiParams.f32IntegPartK_1 = f32Integral;
    /* Calculation of the controller output by adding the proportional and integral terms, saturation is handled
       correctly here. */
    f32Out = MLIB_AddSat_F32(f32Proportional, f32Integral);
    f32Out = MLIB_AddSat_F32(f32Out,(Frac32)0x00008000);

    psFocPMSM -> sIqPiParams.u16LimitFlag = (UWord16)0;
    /* Limitation of resulting PI output (after addition of proportional and integral terms) */
    if (f32Out >= f32UpperLimit){
      f32Out = f32UpperLimit;
      /* Storing of output limitation flag */
      psFocPMSM -> sIqPiParams.u16LimitFlag = (UWord16)1;
    }else{
      if(f32Out <= f32LowerLimit){
        f32Out = f32LowerLimit;
        /* Storing of output limitation flag */
        psFocPMSM -> sIqPiParams.u16LimitFlag = (UWord16)1;
      }
    }

    /* Updating controller input state variables */
    psFocPMSM -> sIqPiParams.f16InK_1 = psFocPMSM -> sIDQError.f16Q;

    /** @remarks Implements DGFLIB00308, DGFLIB00311 */
    psFocPMSM -> sUDQReq.f16Q = ((Frac16)MLIB_ShR_F32(f32Out,(UWord16)16));

    /* Q current controller saturation flag */
    psFocPMSM -> i16IqPiSatFlag = psFocPMSM -> sIqPiParams.u16LimitFlag;    
    
    /* 2-phase to 2-phase transformation to stationary ref. frame */
    //GMCLIB_ParkInv(&psFocPMSM -> sUAlBeReq, &psFocPMSM -> sAnglePosEl, &psFocPMSM -> sUDQReq);

    f16D    = (psFocPMSM -> sUDQReq.f16D);
    f16Q    = (psFocPMSM -> sUDQReq.f16Q);
    f16Sin  = (psFocPMSM -> sAnglePosEl.f16Sin);
    f16Cos  = (psFocPMSM -> sAnglePosEl.f16Cos);

    f32Arg1 = MLIB_MulSat_F32F16F16(f16Cos,f16Q);
    f32Arg2 = MLIB_MulSat_F32F16F16(f16Sin,f16D);

    f32Arg2 = MLIB_AddSat_F32(MLIB_AddSat_F32(f32Arg1,f32Arg2),(Frac32)0x00008000);
    f32Tmp = MLIB_ShR_F32(f32Arg2,(UWord16)16);
    psFocPMSM -> sUAlBeReq.f16Beta = (Frac16)f32Tmp;

    f32Arg1 = MLIB_MulSat_F32F16F16(f16Cos,f16D);
    f32Arg2 = MLIB_MulSat_F32F16F16(f16Sin,f16Q);

    f32Arg1 = MLIB_AddSat_F32(MLIB_SubSat_F32(f32Arg1,f32Arg2),(Frac32)0x00008000);
    psFocPMSM -> sUAlBeReq.f16Alpha = (Frac16)MLIB_ShR_F32(f32Arg1,(UWord16)16);
  
    /* DCBus ripple elimination */
    psFocPMSM -> sElimDCBRip.f16ArgDcBusMsr  = psFocPMSM -> f16UDcBusFilt;
    //GMCLIB_ElimDcBusRip(&psFocPMSM -> sUAlBeComp,&psFocPMSM -> sUAlBeReq,&psFocPMSM -> sElimDCBRip) ;   

    f16DcBusMsrBy2 = MLIB_ShR_F16(psFocPMSM -> sElimDCBRip.f16ArgDcBusMsr,(UWord16)1);
    if(f16DcBusMsrBy2 == (Frac16)0){
      psFocPMSM -> sUAlBeComp.f16Alpha = (Frac16)0;
      psFocPMSM -> sUAlBeComp.f16Beta = (Frac16)0;
      /*
      * @violates @ref GMCLIB_ElimDcBusRip_c_REF_2 MISRA 2004 Required Rule 14.7, Return statement
      * before end of function.
      */
    }
    /* NOTE: f16ModIndex can be 0 or positive, which means that there is no
     * danger of saturation (only if both multiplication arguments are -1).
     * Therefore MLIB_Mul_F16 is used instead of MLIB_MulSat_F16.
     */
    f16Alpha = MLIB_Mul_F16(psFocPMSM -> sElimDCBRip.f16ModIndex,psFocPMSM -> sUAlBeReq.f16Alpha);
    f16Beta = MLIB_Mul_F16(psFocPMSM -> sElimDCBRip.f16ModIndex,psFocPMSM -> sUAlBeReq.f16Beta);
    f16AlphaAbs = MLIB_Abs_F16(f16Alpha);
    f16BetaAbs = MLIB_Abs_F16(f16Beta);
    /* Count the Alpha component */
    if(f16AlphaAbs < f16DcBusMsrBy2){
      psFocPMSM -> sUAlBeComp.f16Alpha = MLIB_DivSat_F16(f16Alpha,f16DcBusMsrBy2);
    }else{
      psFocPMSM -> sUAlBeComp.f16Alpha = (psFocPMSM -> sUAlBeReq.f16Alpha < 0) ? INT16_MIN:INT16_MAX;
    }
    /* Count the Beta component */
    if(f16BetaAbs < f16DcBusMsrBy2){
      psFocPMSM -> sUAlBeComp.f16Beta = MLIB_DivSat_F16(f16Beta,f16DcBusMsrBy2);
    }else{
      psFocPMSM -> sUAlBeComp.f16Beta = (psFocPMSM -> sUAlBeReq.f16Beta < 0) ? INT16_MIN:INT16_MAX;
    }
    /** @remarks Implements DGMCLIB00051 */
    
    /* space vector modulation */
    //psFocPMSM -> uw16SectorSVM = GMCLIB_SvmStd(&psFocPMSM -> sDutyABC,&psFocPMSM -> sUAlBeComp); 

    /* Value f16Alfa is for late use, (Sqrt(3) * u(alfa))/2 */
    f16Alfa = MLIB_Mul_F16(F16_SQRT3_DIVBY_2,psFocPMSM -> sUAlBeComp.f16Alpha);

    /* Definition Uref1 of the Invert Clark Transformation */
    /* Definition Uref2 of the Invert Clark Transformation */
    /* Definition Uref3 of the Invert Clark Transformation */
    f16X = psFocPMSM -> sUAlBeComp.f16Beta;
    f16XSat = psFocPMSM -> sUAlBeComp.f16Beta;
    f16Arg2Shift = MLIB_ShR_F16(psFocPMSM -> sUAlBeComp.f16Beta,(UWord16)2);
    f16ArgShiftTmp = MLIB_ShR_F16(psFocPMSM -> sUAlBeComp.f16Beta,(UWord16)1);
    f16AlfaShift = MLIB_ShR_F16(f16Alfa,(UWord16)1);

    f16Y = MLIB_Add_F16(f16Arg2Shift, f16AlfaShift);
    if (f16Y >= (Frac16)0x3FFF){
      f16YSat = (Frac16)0x3FFF;
    }else{
      if (f16Y <= (Frac16)(0xC000U)){
        f16YSat = (Frac16)0xC000U;
      }else{
        f16YSat = MLIB_Add_F16(f16ArgShiftTmp, f16Alfa);
      }
    }

    f16Z = MLIB_Sub_F16(f16Arg2Shift, f16AlfaShift);
    if (f16Z >= (Frac16)0x3FFF){
      f16ZSat = (Frac16)0x3FFF;
    }else{
      if (f16Z <= (Frac16)(0xC000U)){
        f16ZSat = (Frac16)0xC000U;
      }else{
        f16ZSat = MLIB_Sub_F16(f16ArgShiftTmp, f16Alfa);
      }
    }

    /* Sector identification */
    if(f16YSat < 0)
    {
      if(f16ZSat < 0)
      {
        /* Sector = 5 */
  	    f16Save = MLIB_AddSat_F16(0x3FFF, MLIB_ShR_F16(f16X,(UWord16)1));
        f16Save = MLIB_Add_F16(f16Save, (Frac16)0x0001);
        psFocPMSM -> sDutyABC.f16B = f16Save;
        psFocPMSM -> sDutyABC.f16A = MLIB_SubSat_F16(f16Save,f16ZSat);
        psFocPMSM -> sDutyABC.f16C = MLIB_SubSat_F16(psFocPMSM -> sDutyABC.f16A,f16YSat);
        /*
        * @violates @ref GMCLIB_SvmStd_c_REF_2 MISRA 2004 Required Rule 14.7, Return statement
        * before end of function.
        */
        /** @remarks Implements DGMCLIB00075 */
        psFocPMSM -> uw16SectorSVM =((UWord16)0x5);
      }
      else
      {
        if(f16XSat > 0)
        {
          /* Sector = 3 */
      	  f16Save = MLIB_AddSat_F16(0x3FFF,MLIB_SubSat_F16(f16Y,MLIB_ShR_F16(f16X,(UWord16)1)));
          f16Save = MLIB_Add_F16(f16Save, (Frac16)0x0001);
          psFocPMSM -> sDutyABC.f16A = (f16Save < (Frac16)0) ? (Frac16)0 : f16Save;
          psFocPMSM -> sDutyABC.f16C = MLIB_SubSat_F16(f16Save,f16YSat);
          psFocPMSM -> sDutyABC.f16B = MLIB_AddSat_F16(psFocPMSM -> sDutyABC.f16C,f16X);
          /*
          * @violates @ref GMCLIB_SvmStd_c_REF_2 MISRA 2004 Required Rule 14.7, Return statement
          * before end of function.
          */
          /** @remarks Implements DGMCLIB00075 */
          psFocPMSM -> uw16SectorSVM =((UWord16)0x3);
        }
        else
        {
          /* Sector = 4 */
      	  f16Save = MLIB_AddSat_F16(0x3FFF,MLIB_SubSat_F16(MLIB_ShR_F16(f16X,(UWord16)1),f16Z));
          f16Save = MLIB_Add_F16(f16Save, (Frac16)0x0001);
          psFocPMSM -> sDutyABC.f16A = (f16Save < (Frac16)0) ? (Frac16)0 : f16Save;
          psFocPMSM -> sDutyABC.f16B = MLIB_AddSat_F16(f16Save,f16ZSat);
          psFocPMSM -> sDutyABC.f16C = MLIB_SubSat_F16(psFocPMSM -> sDutyABC.f16B,f16X);
          /*
          * @violates @ref GMCLIB_SvmStd_c_REF_2 MISRA 2004 Required Rule 14.7, Return statement
          * before end of function.
          */
          /** @remarks Implements DGMCLIB00075 */
          psFocPMSM -> uw16SectorSVM =((UWord16)0x4);
        }
      }
    }
    else
    {
      if(f16ZSat < 0)
      {
        if(f16XSat > 0)
        {
          /* Sector = 1 */
    	    f16Save = MLIB_SubSat_F16(0x3FFF,f16Y);
          psFocPMSM -> sDutyABC.f16C = (f16Save < (Frac16)0) ? (Frac16)0 : f16Save;
          psFocPMSM -> sDutyABC.f16B = MLIB_AddSat_F16(f16Save,f16X);
          psFocPMSM -> sDutyABC.f16A = MLIB_SubSat_F16(psFocPMSM -> sDutyABC.f16B,MLIB_ShL_F16(f16Z,(UWord16)1));
          /*
          * @violates @ref GMCLIB_SvmStd_c_REF_2 MISRA 2004 Required Rule 14.7, Return statement
          * before end of function.
          */
          /** @remarks Implements DGMCLIB00075 */
          psFocPMSM -> uw16SectorSVM =((UWord16)0x1);
        }
        else
        {
          /* Sector = 6 */
    	    f16Save = MLIB_AddSat_F16(0x3FFF,MLIB_SubSat_F16(MLIB_ShR_F16(f16X,(UWord16)1),f16Y));
          psFocPMSM -> sDutyABC.f16B = (f16Save < (Frac16)0) ? (Frac16)0 : f16Save;
          psFocPMSM -> sDutyABC.f16C = MLIB_SubSat_F16(f16Save,f16X);
          psFocPMSM -> sDutyABC.f16A = MLIB_AddSat_F16(psFocPMSM -> sDutyABC.f16C,f16YSat);
          /*
          * @violates @ref GMCLIB_SvmStd_c_REF_2 MISRA 2004 Required Rule 14.7, Return statement
          * before end of function.
          */
          /** @remarks Implements DGMCLIB00075 */
          psFocPMSM -> uw16SectorSVM =((UWord16)0x6);
        }
      }
      else
      {
        /* Sector = 2 */
  	    f16Save = MLIB_ShR_F16(MLIB_SubSat_F16(0x7FFF, MLIB_AddSat_F16(f16YSat,f16ZSat)),(UWord16)1);
        f16Save = MLIB_Add_F16(f16Save, (Frac16)0x0001);
        psFocPMSM -> sDutyABC.f16C = f16Save;
        psFocPMSM -> sDutyABC.f16A = MLIB_AddSat_F16(f16Save,f16YSat);
        psFocPMSM -> sDutyABC.f16B = MLIB_AddSat_F16(psFocPMSM -> sDutyABC.f16A,f16ZSat);
        /*
        * @violates @ref GMCLIB_SvmStd_c_REF_2 MISRA 2004 Required Rule 14.7, Return statement
        * before end of function.
        */
        /** @remarks Implements DGMCLIB00075 */
        psFocPMSM -> uw16SectorSVM =((UWord16)0x2);
      }
    }
  
    /* End - voltage control */   
}

/***************************************************************************//*!
*
* @brief   PMSM foc speed control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM,
*            - structure of PMSM FOC parameters
*            IN: -> i16LimitFlag - limit flags of D and Q current PI controllers
*         MCS_SPEED_A1_T *psSpeed
*            - structure of PMSM speed parameters
*            IN: -> i16LimitFlag - limit flags of speed PI controllers
*            IN: -> sAlignment.f32Speed - speed of the field
*            IN: -> f16SpeedReq - required speed value
*            IN/OUT: -> f16SpeedRamp - speed ramp
*            IN: -> sAlignment.f32UStep - voltage step to ramp the voltage
*            OUT: -> psFocPMSM -> sDutyABC - duty cycles ABC
*
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMFocCtrlSpeedA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_SPEED_A1_T *psSpeed)
{
    /* Speed saturation flag given by the Q current controller saturation flag and speed controller saturation flag */
    psSpeed -> i16SpeedPiSatFlag = (psSpeed -> sSpeedPiParams.u16LimitFlag | psFocPMSM -> sIqPiParams.u16LimitFlag) \
            & (MLIB_AbsSat_F16(psSpeed -> f16SpeedReq) >= MLIB_AbsSat_F16(psSpeed -> f16SpeedFilt));
    
    /* Speed ramp generation */
    psSpeed -> f16SpeedRamp = (Frac16)MLIB_ShR_F32(GFLIB_Ramp_F32(MLIB_ShL_F32((Frac32)(psSpeed -> f16SpeedReq),16), &psSpeed -> sSpeedRampParams), 16);

    /* Speed error calculation */
    psSpeed -> f16SpeedError = MLIB_SubSat_F16(psSpeed -> f16SpeedRamp, psSpeed -> f16Speed);

    /* Desired current by the speed PI controller */
    psFocPMSM -> sIDQReq.f16Q = GFLIB_ControllerPIpAW(psSpeed -> f16SpeedError, &psSpeed -> sSpeedPiParams);

}

/***************************************************************************//*!
*
* @brief   PMSM 2-step rotor alignment
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN/OUT: -> f16PosElReload - actual rotor position
*          MCS_ALIGNMENT_A1_T *psAlignment
*            - structure of alignment
*            IN: -> uw16CountAlignHalf - half alignment counter
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMAlignmentA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_ALIGNMENT_A1_T *psAlignment)
{
    /* first half duration time is position set to 120 degree */
    if (psAlignment-> uw16TimeHalf>0)
    {    
        psFocPMSM ->f16PosElReload = FRAC16(120.0/180.0);
        psAlignment -> uw16TimeHalf--;
    }
    else
    {
        psFocPMSM ->f16PosElReload    = FRAC16(0.0);
    }

    /* call voltage FOC to calculate PWM duty cycles */
    MCS_PMSMFocCtrlVoltageA1(psFocPMSM);    
}

/***************************************************************************//*!
*
* @brief   PMSM Open Loop Start-up
*          MCS_STARTUP_A1_T *psStartUp
*            - structure of open loop start up parameters
*            IN: -> f32SpeedReq - required speed
*            IN: -> f16SpeedCatchUp - merging speed threshold
*            IN/OUT: -> f16SpeedRampOpenLoop - ramped open loop speed
*            IN/OUT: -> f16RatioMerging - actual merging ration between open loop and estimated position
*            OUT: ->f16PosMerged - actual merged position
*
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMOpenLoopStartUpA1(MCS_PMSM_STARTUP_A1_T *psStartUp)
{  
    /* Open loop startup speed ramp */
    psStartUp -> f16SpeedRampOpenLoop = (Frac16)MLIB_ShR_F32((GFLIB_Ramp_F32(psStartUp -> f32SpeedReq, &psStartUp -> sSpeedRampOpenLoopParams)),16);

    /* generation of open loop position from the required speed */
    psStartUp -> f16PosGen = GFLIB_IntegratorTR(psStartUp -> f16SpeedRampOpenLoop, &psStartUp -> sSpeedIntegrator); 

    /* position merging starts above merging speed threshold*/
    if (MLIB_AbsSat_F16(psStartUp -> f16SpeedRampOpenLoop) >= psStartUp -> f16SpeedCatchUp)  
    {
        /* increment position merging coefficient */
        psStartUp -> f16RatioMerging = MLIB_AddSat_F16(psStartUp -> f16RatioMerging, psStartUp -> f16CoeffMerging);       

        /* merging equation */
        psStartUp -> f16PosMerged = MLIB_Add_F16(psStartUp -> f16PosGen,MLIB_Mul_F16(MLIB_Sub_F16(psStartUp -> f16PosEst, psStartUp -> f16PosGen), psStartUp -> f16RatioMerging));      
    }
    else           
    {
        psStartUp -> f16PosMerged = psStartUp -> f16PosGen;
    }
    
    /* clear open loop flag */
    if(psStartUp -> f16RatioMerging == FRAC16(1.0))
        psStartUp ->bOpenLoop = FALSE;

}

/***************************************************************************//*!
*
* @brief   PMSM scalar control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN/OUT: -> sUDQReq - required values of D/Q voltages
*            IN: f16PosElReload - actual position at PWM reload
*           MCS_PMSM_SCALAR_CTRL_A1_T *psScalarPMSM
*            - structure of scalar control
*            IN: f32FreqCmd - required frequency
*            IN/OUT: f16FreqRamp - ramped frequency value
*            OUT: f16PosElScalar - generated scalar position     
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMScalarCtrlA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_PMSM_SCALAR_CTRL_A1_T *psScalarPMSM)
{

    /* this part of code is executed when scalar control is turned-on */
    /* frequency ramp */
    psScalarPMSM -> f16FreqRamp = (Frac16)MLIB_ShR_F32((GFLIB_Ramp_F32(psScalarPMSM->f32FreqCmd, &psScalarPMSM -> sFreqRampParams)),16);

    /* voltage calculation */
    psScalarPMSM -> sUDQReq.f16Q = (Frac16)(MLIB_ShLSat_F16(MLIB_Mul_F16(psScalarPMSM->f16VHzGain,psScalarPMSM -> f16FreqRamp),\
                                                                                                       psScalarPMSM->f16VHzGainShift));
    psScalarPMSM -> sUDQReq.f16D = 0;

    /* stator voltage angle , used the same integrator as for the open-loop start up*/
    psScalarPMSM -> f16PosElScalar = GFLIB_IntegratorTR(psScalarPMSM -> f16FreqRamp, &psScalarPMSM -> sFreqIntegrator);

    /* pass parameters to FOC structure */
    psFocPMSM -> sUDQReq  = psScalarPMSM -> sUDQReq;
    psFocPMSM -> f16PosElReload = psScalarPMSM -> f16PosElScalar;

    /* call voltage FOC to calculate PWM duty cycles */
    MCS_PMSMFocCtrlVoltageA1(psFocPMSM);
}

/******************************************************************************
* Inline functions
******************************************************************************/
/*
 *######################################################################
 *                           End of File
 *######################################################################
*/


